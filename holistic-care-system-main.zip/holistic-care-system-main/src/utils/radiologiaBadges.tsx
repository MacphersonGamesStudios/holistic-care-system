
import { Badge } from "@/components/ui/badge";

export const getEstadoBadge = (estado: string) => {
  switch (estado) {
    case 'solicitado':
      return <Badge variant="outline" className="bg-blue-100 text-blue-800">Solicitado</Badge>;
    case 'programado':
      return <Badge variant="default" className="bg-orange-100 text-orange-800">Programado</Badge>;
    case 'realizado':
      return <Badge variant="secondary" className="bg-green-100 text-green-800">Realizado</Badge>;
    case 'informado':
      return <Badge variant="default" className="bg-cyan-100 text-cyan-800">Informado</Badge>;
    default:
      return <Badge variant="secondary">{estado}</Badge>;
  }
};

export const getPrioridadBadge = (prioridad: string) => {
  switch (prioridad) {
    case 'urgente':
      return <Badge variant="destructive" className="bg-red-100 text-red-800">Urgente</Badge>;
    case 'alta':
      return <Badge variant="default" className="bg-orange-100 text-orange-800">Alta</Badge>;
    case 'normal':
      return <Badge variant="outline" className="bg-blue-100 text-blue-800">Normal</Badge>;
    case 'baja':
      return <Badge variant="secondary" className="bg-gray-100 text-gray-800">Baja</Badge>;
    default:
      return <Badge variant="secondary">{prioridad}</Badge>;
  }
};
