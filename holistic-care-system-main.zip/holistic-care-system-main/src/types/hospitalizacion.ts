
export interface Hospitalizacion {
  id: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  habitacion: string;
  cama: string;
  fechaIngreso: string;
  fechaAlta?: string;
  medicoResponsable: string;
  estado: 'ingresado' | 'alta' | 'transferido';
  diagnostico: string;
  observaciones?: string;
  tipoIngreso: 'urgencia' | 'programado' | 'traslado';
}
