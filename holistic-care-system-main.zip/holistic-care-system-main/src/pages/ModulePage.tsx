
import React from 'react';
import { useParams } from 'react-router-dom';
import Layout from '../components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const ModulePage = () => {
  const { module } = useParams();

  const getModuleTitle = (module: string) => {
    const titles: { [key: string]: string } = {
      'agenda': 'Agenda Médica',
      'visitas': 'Gestión de Visitas',
      'facturacion': 'Facturación',
      'pacientes': 'Gestión de Pacientes',
      'clientes': 'Clientes/Tutores',
      'contabilidad': 'Contabilidad Diaria',
      'estadisticas': 'Listados Estadísticos',
      'hospitalizacion': 'Gestión de Hospitalización',
      'farmacia': 'Gestión de Farmacia',
      'radiologia': 'Gestión de Radiología',
      'laboratorio': 'Gestión de Laboratorio',
    };
    return titles[module || ''] || 'Módulo';
  };

  const getModuleFeatures = (module: string) => {
    const features: { [key: string]: string[] } = {
      'agenda': [
        'Agenda médica completa',
        'Cita online',
        'Integración con Google Calendar',
        'Conexión con Doctoralia',
        'Recordatorios por WhatsApp',
        'Recordatorios por SMS',
        'Automatización con IA'
      ],
      'visitas': [
        'Historia y curso clínico CIE10',
        'Gestor de imágenes, vídeos y documentos',
        'Editor de informes y documentos',
        'Cuestionarios y protocolos',
        'Gestión completa del historial médico'
      ],
      'facturacion': [
        'Facturación a mutuas',
        'Gestión de cobros',
        'Control de costes de materiales',
        'Contabilidad y control de caja',
        'Integración con Verifactu 2025'
      ],
      'hospitalizacion': [
        'Gestión de camas y habitaciones',
        'Control de ingresos y altas',
        'Seguimiento de pacientes hospitalizados',
        'Gestión de enfermería',
        'Historiales de hospitalización'
      ],
      'farmacia': [
        'Inventario de medicamentos',
        'Control de stock',
        'Receta electrónica privada',
        'Gestión de proveedores',
        'Alertas de caducidad'
      ],
      'radiologia': [
        'Gestión de estudios radiológicos',
        'Almacenamiento de imágenes DICOM',
        'Agenda de estudios',
        'Informes radiológicos',
        'Integración con equipos'
      ],
      'laboratorio': [
        'Gestión de muestras',
        'Resultados de análisis',
        'Control de calidad',
        'Interfaz con analizadores',
        'Informes de laboratorio'
      ]
    };
    return features[module || ''] || [];
  };

  return (
    <Layout>
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            {getModuleTitle(module || '')}
          </h1>
          <p className="text-gray-600">
            Gestione todas las funcionalidades de este módulo desde aquí.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Características del Módulo</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {getModuleFeatures(module || '').map((feature, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-cyan-600 rounded-full"></div>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Estado del Sistema</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Estado del módulo:</span>
                  <span className="text-green-600 font-semibold">Activo</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Última actualización:</span>
                  <span className="text-gray-600">Hoy, 10:30</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Usuarios conectados:</span>
                  <span className="text-blue-600 font-semibold">12</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Panel de Control</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">
              Aquí se desarrollarán las funcionalidades específicas del módulo {getModuleTitle(module || '')}.
            </p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-blue-800">
                <strong>Próximamente:</strong> Este módulo estará completamente funcional con todas las características listadas.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default ModulePage;
