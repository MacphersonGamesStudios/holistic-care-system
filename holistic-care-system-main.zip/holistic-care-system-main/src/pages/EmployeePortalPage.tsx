
import React from 'react';
import Layout from '../components/Layout';
import EmployeePortal from '../components/EmployeePortal';

const EmployeePortalPage = () => {
  return (
    <Layout>
      <EmployeePortal />
    </Layout>
  );
};

export default EmployeePortalPage;
