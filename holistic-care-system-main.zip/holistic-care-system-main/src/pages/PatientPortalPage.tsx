
import React from 'react';
import Layout from '../components/Layout';
import PatientPortal from '../components/PatientPortal';
import { usePatientAuth } from '../hooks/usePatientAuth';

const PatientPortalPage = () => {
  const { patientUser, loading } = usePatientAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-cyan-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Verificando acceso...</p>
        </div>
      </div>
    );
  }

  if (!patientUser) {
    return null;
  }

  return (
    <Layout>
      <PatientPortal />
    </Layout>
  );
};

export default PatientPortalPage;
