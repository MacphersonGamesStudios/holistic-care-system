
import LoginForm from "../components/LoginForm";

const Index = () => {
  return <LoginForm />;
};

export default Index;
