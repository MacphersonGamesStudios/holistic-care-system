
import { useState, useEffect } from 'react';
import { toast } from "@/hooks/use-toast";

export interface Medicamento {
  id: string;
  nombre: string;
  principioActivo: string;
  laboratorio: string;
  presentacion: string;
  stock: number;
  stockMinimo: number;
  precio: number;
  fechaCaducidad: string;
  lote: string;
  categoria: string;
  prescripcion: boolean;
}

export const useFarmaciaData = () => {
  const [medicamentos, setMedicamentos] = useState<Medicamento[]>([]);
  const [filteredMedicamentos, setFilteredMedicamentos] = useState<Medicamento[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoriaFilter, setCategoriaFilter] = useState('todas');
  const [stockFilter, setStockFilter] = useState('todos');

  useEffect(() => {
    const savedMedicamentos = localStorage.getItem('farmacia-medicamentos');
    if (savedMedicamentos) {
      const medicamentosData = JSON.parse(savedMedicamentos);
      setMedicamentos(medicamentosData);
      setFilteredMedicamentos(medicamentosData);
    } else {
      // Datos de ejemplo iniciales
      const medicamentosEjemplo: Medicamento[] = [
        {
          id: '1',
          nombre: 'Paracetamol 500mg',
          principioActivo: 'Paracetamol',
          laboratorio: 'Cinfa',
          presentacion: 'Comprimidos x20',
          stock: 150,
          stockMinimo: 50,
          precio: 2.45,
          fechaCaducidad: '2025-12-31',
          lote: 'LOT001',
          categoria: 'Analgésicos',
          prescripcion: false
        },
        {
          id: '2',
          nombre: 'Amoxicilina 750mg',
          principioActivo: 'Amoxicilina',
          laboratorio: 'Normon',
          presentacion: 'Cápsulas x14',
          stock: 25,
          stockMinimo: 30,
          precio: 8.95,
          fechaCaducidad: '2025-08-15',
          lote: 'LOT002',
          categoria: 'Antibióticos',
          prescripcion: true
        },
        {
          id: '3',
          nombre: 'Ibuprofeno 600mg',
          principioActivo: 'Ibuprofeno',
          laboratorio: 'Kern Pharma',
          presentacion: 'Comprimidos x30',
          stock: 8,
          stockMinimo: 25,
          precio: 3.20,
          fechaCaducidad: '2024-06-30',
          lote: 'LOT003',
          categoria: 'Antiinflamatorios',
          prescripcion: true
        }
      ];
      setMedicamentos(medicamentosEjemplo);
      setFilteredMedicamentos(medicamentosEjemplo);
      localStorage.setItem('farmacia-medicamentos', JSON.stringify(medicamentosEjemplo));
    }
  }, []);

  useEffect(() => {
    let filtered = medicamentos;

    if (searchTerm) {
      filtered = filtered.filter(m => 
        m.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.principioActivo.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.laboratorio.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (categoriaFilter !== 'todas') {
      filtered = filtered.filter(m => m.categoria === categoriaFilter);
    }

    if (stockFilter === 'bajo') {
      filtered = filtered.filter(m => m.stock <= m.stockMinimo);
    } else if (stockFilter === 'critico') {
      filtered = filtered.filter(m => m.stock < m.stockMinimo * 0.5);
    }

    setFilteredMedicamentos(filtered);
  }, [medicamentos, searchTerm, categoriaFilter, stockFilter]);

  const handleNewMedicamento = (medicamentoData: any) => {
    const newMedicamento: Medicamento = {
      id: Date.now().toString(),
      ...medicamentoData
    };

    const updatedMedicamentos = [...medicamentos, newMedicamento];
    setMedicamentos(updatedMedicamentos);
    localStorage.setItem('farmacia-medicamentos', JSON.stringify(updatedMedicamentos));
    
    toast({
      title: "Medicamento registrado",
      description: `${medicamentoData.nombre} ha sido registrado correctamente`,
    });
  };

  const handleEditMedicamento = (selectedMedicamento: Medicamento, medicamentoData: any) => {
    const updatedMedicamentos = medicamentos.map(m => 
      m.id === selectedMedicamento.id ? { ...m, ...medicamentoData } : m
    );
    
    setMedicamentos(updatedMedicamentos);
    localStorage.setItem('farmacia-medicamentos', JSON.stringify(updatedMedicamentos));
    
    toast({
      title: "Medicamento actualizado",
      description: `${medicamentoData.nombre} ha sido actualizado`,
    });
  };

  const handleVentaMedicamento = (selectedMedicamento: Medicamento, cantidad: number) => {
    if (selectedMedicamento.stock >= cantidad) {
      const updatedMedicamentos = medicamentos.map(m => 
        m.id === selectedMedicamento.id ? { ...m, stock: m.stock - cantidad } : m
      );
      
      setMedicamentos(updatedMedicamentos);
      localStorage.setItem('farmacia-medicamentos', JSON.stringify(updatedMedicamentos));
      
      toast({
        title: "Venta registrada",
        description: `Se vendieron ${cantidad} unidades de ${selectedMedicamento.nombre}`,
      });
    } else {
      toast({
        title: "Error en la venta",
        description: "No hay suficiente stock disponible",
        variant: "destructive"
      });
    }
  };

  return {
    medicamentos,
    filteredMedicamentos,
    searchTerm,
    setSearchTerm,
    categoriaFilter,
    setCategoriaFilter,
    stockFilter,
    setStockFilter,
    handleNewMedicamento,
    handleEditMedicamento,
    handleVentaMedicamento
  };
};
