
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

export const usePatientAuth = () => {
  const [patientUser, setPatientUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = () => {
      const user = localStorage.getItem('patientUser');
      if (user) {
        setPatientUser(JSON.parse(user));
      } else {
        navigate('/patient-login');
      }
      setLoading(false);
    };

    checkAuth();
  }, [navigate]);

  const logout = () => {
    localStorage.removeItem('patientUser');
    navigate('/patient-login');
  };

  return { patientUser, loading, logout };
};
