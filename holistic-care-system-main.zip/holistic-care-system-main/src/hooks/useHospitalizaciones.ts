
import { useState, useEffect } from 'react';
import { toast } from "@/hooks/use-toast";
import { Hospitalizacion } from '../types/hospitalizacion';

export const useHospitalizaciones = () => {
  const [hospitalizaciones, setHospitalizaciones] = useState<Hospitalizacion[]>([]);

  useEffect(() => {
    const savedHospitalizaciones = localStorage.getItem('hospitalHospitalizaciones');
    if (savedHospitalizaciones) {
      const data = JSON.parse(savedHospitalizaciones);
      setHospitalizaciones(data);
    } else {
      // Datos de ejemplo
      const ejemploData: Hospitalizacion[] = [
        {
          id: '1',
          pacienteId: '1',
          pacienteNombre: 'García López, Juan Carlos',
          numeroHistoria: 'HST001',
          habitacion: '101',
          cama: 'A',
          fechaIngreso: '2024-05-20',
          medicoResponsable: 'Dr. Martínez',
          estado: 'ingresado',
          diagnostico: 'Neumonía',
          tipoIngreso: 'urgencia'
        },
        {
          id: '2',
          pacienteId: '2',
          pacienteNombre: 'Rodríguez Pérez, María Isabel',
          numeroHistoria: 'HST002',
          habitacion: '102',
          cama: 'B',
          fechaIngreso: '2024-05-18',
          fechaAlta: '2024-05-22',
          medicoResponsable: 'Dra. González',
          estado: 'alta',
          diagnostico: 'Cirugía programada',
          tipoIngreso: 'programado'
        }
      ];
      setHospitalizaciones(ejemploData);
      localStorage.setItem('hospitalHospitalizaciones', JSON.stringify(ejemploData));
    }
  }, []);

  const handleNewHospitalizacion = (hospitalizacionData: any) => {
    const newHospitalizacion: Hospitalizacion = {
      id: Date.now().toString(),
      ...hospitalizacionData,
      fechaIngreso: hospitalizacionData.fechaIngreso || new Date().toISOString().split('T')[0],
      estado: 'ingresado'
    };

    const updatedHospitalizaciones = [...hospitalizaciones, newHospitalizacion];
    setHospitalizaciones(updatedHospitalizaciones);
    localStorage.setItem('hospitalHospitalizaciones', JSON.stringify(updatedHospitalizaciones));
    
    toast({
      title: "Hospitalización registrada",
      description: `Se ha registrado el ingreso de ${hospitalizacionData.pacienteNombre}`,
    });
  };

  const handleUpdateHospitalizacion = (id: string, data: Partial<Hospitalizacion>) => {
    const updatedHospitalizaciones = hospitalizaciones.map(h => 
      h.id === id ? { ...h, ...data } : h
    );
    
    setHospitalizaciones(updatedHospitalizaciones);
    localStorage.setItem('hospitalHospitalizaciones', JSON.stringify(updatedHospitalizaciones));
    
    toast({
      title: "Hospitalización actualizada",
      description: "Los datos se han actualizado correctamente",
    });
  };

  const handleDarAlta = (hospitalizacion: Hospitalizacion) => {
    const updatedHospitalizaciones = hospitalizaciones.map(h => 
      h.id === hospitalizacion.id 
        ? { ...h, estado: 'alta' as const, fechaAlta: new Date().toISOString().split('T')[0] }
        : h
    );
    
    setHospitalizaciones(updatedHospitalizaciones);
    localStorage.setItem('hospitalHospitalizaciones', JSON.stringify(updatedHospitalizaciones));
    
    toast({
      title: "Alta registrada",
      description: `Se ha dado de alta a ${hospitalizacion.pacienteNombre}`,
    });
  };

  return {
    hospitalizaciones,
    handleNewHospitalizacion,
    handleUpdateHospitalizacion,
    handleDarAlta
  };
};
