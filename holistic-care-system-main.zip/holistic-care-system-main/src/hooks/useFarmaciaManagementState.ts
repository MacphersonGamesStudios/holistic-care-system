
import { useState } from 'react';
import { Medicamento } from './useFarmaciaData';

export const useFarmaciaManagementState = () => {
  const [showNewMedicamentoDialog, setShowNewMedicamentoDialog] = useState(false);
  const [showEditMedicamentoDialog, setShowEditMedicamentoDialog] = useState(false);
  const [showViewMedicamentoDialog, setShowViewMedicamentoDialog] = useState(false);
  const [showVentaDialog, setShowVentaDialog] = useState(false);
  const [selectedMedicamento, setSelectedMedicamento] = useState<Medicamento | null>(null);

  const handleViewMedicamento = (medicamento: Medicamento) => {
    setSelectedMedicamento(medicamento);
    setShowViewMedicamentoDialog(true);
  };

  const handleEditClick = (medicamento: Medicamento) => {
    setSelectedMedicamento(medicamento);
    setShowEditMedicamentoDialog(true);
  };

  const handleVentaClick = (medicamento: Medicamento) => {
    setSelectedMedicamento(medicamento);
    setShowVentaDialog(true);
  };

  const handleNuevaVenta = () => {
    // Implementar lógica para nueva venta general
    console.log('Nueva venta general');
  };

  return {
    showNewMedicamentoDialog,
    setShowNewMedicamentoDialog,
    showEditMedicamentoDialog,
    setShowEditMedicamentoDialog,
    showViewMedicamentoDialog,
    setShowViewMedicamentoDialog,
    showVentaDialog,
    setShowVentaDialog,
    selectedMedicamento,
    setSelectedMedicamento,
    handleViewMedicamento,
    handleEditClick,
    handleVentaClick,
    handleNuevaVenta,
  };
};
