
import { useState, useEffect } from 'react';
import { toast } from "@/hooks/use-toast";

interface Paciente {
  id: string;
  numeroHistoria: string;
  nombre: string;
  apellidos: string;
  dni: string;
  fechaNacimiento: string;
  sexo: string;
  telefono: string;
  email: string;
  fechaAlta: string;
  activo: boolean;
  foto?: string;
  direccion?: string;
  codigoPostal?: string;
  provincia?: string;
  poblacion?: string;
  observaciones?: string;
}

export const usePacientesData = () => {
  const [pacientes, setPacientes] = useState<Paciente[]>([]);
  const [filteredPacientes, setFilteredPacientes] = useState<Paciente[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedState, setSelectedState] = useState('activos');
  const [ocultarSinHistoria, setOcultarSinHistoria] = useState(false);
  const [clienteTutor, setClienteTutor] = useState('');

  const handleOcultarSinHistoriaChange = (checked: boolean | "indeterminate") => {
    setOcultarSinHistoria(checked === true);
  };

  useEffect(() => {
    const savedPacientes = localStorage.getItem('hospitalPatients');
    if (savedPacientes) {
      const pacientesData = JSON.parse(savedPacientes);
      setPacientes(pacientesData);
      setFilteredPacientes(pacientesData);
    }
  }, []);

  useEffect(() => {
    let filtered = pacientes;

    // Filtrar por estado
    if (selectedState === 'activos') {
      filtered = filtered.filter(p => p.activo);
    } else if (selectedState === 'inactivos') {
      filtered = filtered.filter(p => !p.activo);
    }

    // Filtrar por búsqueda
    if (searchTerm) {
      filtered = filtered.filter(p => 
        p.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.apellidos.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.dni.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.numeroHistoria.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filtrar por cliente/tutor
    if (clienteTutor) {
      filtered = filtered.filter(p => 
        p.nombre.toLowerCase().includes(clienteTutor.toLowerCase()) ||
        p.apellidos.toLowerCase().includes(clienteTutor.toLowerCase())
      );
    }

    setFilteredPacientes(filtered);
  }, [pacientes, searchTerm, selectedState, clienteTutor, ocultarSinHistoria]);

  const handleNewPatient = (pacienteData: any) => {
    const newPaciente: Paciente = {
      id: Date.now().toString(),
      numeroHistoria: pacienteData.numeroHistoria || `HST${Date.now()}`,
      ...pacienteData,
      fechaAlta: new Date().toLocaleDateString(),
      activo: true
    };

    const updatedPacientes = [...pacientes, newPaciente];
    setPacientes(updatedPacientes);
    localStorage.setItem('hospitalPatients', JSON.stringify(updatedPacientes));
    
    toast({
      title: "Paciente registrado",
      description: `${pacienteData.nombre} ${pacienteData.apellidos} ha sido registrado correctamente`,
    });
  };

  const handleEditPatient = (selectedPaciente: Paciente, pacienteData: any) => {
    const updatedPacientes = pacientes.map(p => 
      p.id === selectedPaciente.id ? { ...p, ...pacienteData } : p
    );
    
    setPacientes(updatedPacientes);
    localStorage.setItem('hospitalPatients', JSON.stringify(updatedPacientes));
    
    toast({
      title: "Paciente actualizado",
      description: `Los datos de ${pacienteData.nombre} ${pacienteData.apellidos} han sido actualizados`,
    });
  };

  const handleDeletePatient = (selectedPaciente: Paciente) => {
    const updatedPacientes = pacientes.filter(p => p.id !== selectedPaciente.id);
    setPacientes(updatedPacientes);
    localStorage.setItem('hospitalPatients', JSON.stringify(updatedPacientes));
    
    toast({
      title: "Paciente eliminado",
      description: `${selectedPaciente.nombre} ${selectedPaciente.apellidos} ha sido eliminado del sistema`,
      variant: "destructive",
    });
  };

  return {
    filteredPacientes,
    searchTerm,
    setSearchTerm,
    selectedState,
    setSelectedState,
    ocultarSinHistoria,
    handleOcultarSinHistoriaChange,
    clienteTutor,
    setClienteTutor,
    handleNewPatient,
    handleEditPatient,
    handleDeletePatient
  };
};
