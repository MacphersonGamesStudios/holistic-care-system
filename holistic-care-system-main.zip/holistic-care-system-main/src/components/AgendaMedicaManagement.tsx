
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Plus, Search, User } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";

interface Cita {
  id: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  fecha: string;
  hora: string;
  medico: string;
  especialidad: string;
  motivo: string;
  estado: 'programada' | 'confirmada' | 'atendida' | 'cancelada' | 'no_asistio';
  tipo: 'primera_vez' | 'control' | 'urgencia';
  observaciones?: string;
  telefono: string;
}

const AgendaMedicaManagement = () => {
  const [citas, setCitas] = useState<Cita[]>([]);
  const [filteredCitas, setFilteredCitas] = useState<Cita[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedMedico, setSelectedMedico] = useState('todos');
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewCitaDialog, setShowNewCitaDialog] = useState(false);

  // Datos de ejemplo
  useEffect(() => {
    const savedCitas = localStorage.getItem('hospitalAgenda');
    if (savedCitas) {
      const data = JSON.parse(savedCitas);
      setCitas(data);
      setFilteredCitas(data);
    } else {
      const ejemploCitas: Cita[] = [
        {
          id: '1',
          pacienteId: '1',
          pacienteNombre: 'García López, Juan Carlos',
          numeroHistoria: 'HST001',
          fecha: new Date().toISOString().split('T')[0],
          hora: '09:00',
          medico: 'Dr. Martínez',
          especialidad: 'Cardiología',
          motivo: 'Control rutinario',
          estado: 'confirmada',
          tipo: 'control',
          telefono: '555-0123'
        },
        {
          id: '2',
          pacienteId: '2',
          pacienteNombre: 'Rodríguez Pérez, María Isabel',
          numeroHistoria: 'HST002',
          fecha: new Date().toISOString().split('T')[0],
          hora: '10:30',
          medico: 'Dra. González',
          especialidad: 'Medicina Interna',
          motivo: 'Primera consulta',
          estado: 'programada',
          tipo: 'primera_vez',
          telefono: '555-0456'
        }
      ];
      setCitas(ejemploCitas);
      setFilteredCitas(ejemploCitas);
      localStorage.setItem('hospitalAgenda', JSON.stringify(ejemploCitas));
    }
  }, []);

  useEffect(() => {
    let filtered = citas;

    if (selectedDate) {
      filtered = filtered.filter(c => c.fecha === selectedDate);
    }

    if (selectedMedico !== 'todos') {
      filtered = filtered.filter(c => c.medico === selectedMedico);
    }

    if (searchTerm) {
      filtered = filtered.filter(c => 
        c.pacienteNombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.numeroHistoria.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.motivo.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredCitas(filtered);
  }, [citas, selectedDate, selectedMedico, searchTerm]);

  const getEstadoBadge = (estado: string) => {
    switch (estado) {
      case 'programada':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Programada</Badge>;
      case 'confirmada':
        return <Badge variant="default" className="bg-green-100 text-green-800">Confirmada</Badge>;
      case 'atendida':
        return <Badge variant="secondary" className="bg-cyan-100 text-cyan-800">Atendida</Badge>;
      case 'cancelada':
        return <Badge variant="destructive" className="bg-red-100 text-red-800">Cancelada</Badge>;
      case 'no_asistio':
        return <Badge variant="outline" className="bg-orange-100 text-orange-800">No asistió</Badge>;
      default:
        return <Badge variant="secondary">{estado}</Badge>;
    }
  };

  const handleUpdateEstado = (citaId: string, nuevoEstado: string) => {
    const updatedCitas = citas.map(c => 
      c.id === citaId ? { ...c, estado: nuevoEstado as any } : c
    );
    
    setCitas(updatedCitas);
    localStorage.setItem('hospitalAgenda', JSON.stringify(updatedCitas));
    
    toast({
      title: "Estado actualizado",
      description: `La cita ha sido marcada como ${nuevoEstado}`,
    });
  };

  const estadisticas = {
    programadas: citas.filter(c => c.estado === 'programada').length,
    confirmadas: citas.filter(c => c.estado === 'confirmada').length,
    atendidas: citas.filter(c => c.estado === 'atendida').length,
    canceladas: citas.filter(c => c.estado === 'cancelada').length,
    hoy: citas.filter(c => c.fecha === new Date().toISOString().split('T')[0]).length
  };

  return (
    <div className="p-6 space-y-6">
      <div className="text-sm text-gray-600 mb-4">
        <span className="text-cyan-600">Gestión médica</span> / <span>Agenda</span>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-gray-800">Agenda Médica</h1>
          <Dialog open={showNewCitaDialog} onOpenChange={setShowNewCitaDialog}>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
                <Plus size={16} />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Nueva Cita</DialogTitle>
              </DialogHeader>
              <div className="text-center py-8 text-gray-500">
                Formulario de nueva cita (pendiente de implementar)
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Programadas</CardTitle>
            <Calendar className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.programadas}</div>
            <p className="text-xs text-muted-foreground">Pendientes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Confirmadas</CardTitle>
            <Clock className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.confirmadas}</div>
            <p className="text-xs text-muted-foreground">Confirmadas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Atendidas</CardTitle>
            <User className="h-4 w-4 text-cyan-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.atendidas}</div>
            <p className="text-xs text-muted-foreground">Completadas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Canceladas</CardTitle>
            <Clock className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.canceladas}</div>
            <p className="text-xs text-muted-foreground">Canceladas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Hoy</CardTitle>
            <Calendar className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.hoy}</div>
            <p className="text-xs text-muted-foreground">Citas de hoy</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="fecha">Fecha</Label>
              <Input
                id="fecha"
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="medico">Médico</Label>
              <Select value={selectedMedico} onValueChange={setSelectedMedico}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos los médicos</SelectItem>
                  <SelectItem value="Dr. Martínez">Dr. Martínez</SelectItem>
                  <SelectItem value="Dra. González">Dra. González</SelectItem>
                  <SelectItem value="Dr. López">Dr. López</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="buscar">Buscar</Label>
              <div className="relative mt-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="buscar"
                  placeholder="Buscar paciente..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="flex items-end">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => {
                  setSearchTerm('');
                  setSelectedMedico('todos');
                  setSelectedDate(new Date().toISOString().split('T')[0]);
                }}
              >
                Limpiar filtros
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de citas */}
      <Card>
        <CardContent className="p-0">
          <div className="space-y-2 p-4">
            {filteredCitas.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No se encontraron citas para los filtros seleccionados
              </div>
            ) : (
              filteredCitas.map((cita) => (
                <div key={cita.id} className="border rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="text-lg font-medium text-cyan-600">
                        {cita.hora}
                      </div>
                      <div>
                        <div className="font-medium">{cita.pacienteNombre}</div>
                        <div className="text-sm text-gray-500">
                          {cita.numeroHistoria} • {cita.telefono}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm font-medium">{cita.medico}</div>
                        <div className="text-sm text-gray-500">{cita.especialidad}</div>
                      </div>
                      <div>
                        <div className="text-sm">{cita.motivo}</div>
                        <Badge variant="outline" className="text-xs mt-1">
                          {cita.tipo.replace('_', ' ')}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getEstadoBadge(cita.estado)}
                      <Select 
                        value={cita.estado} 
                        onValueChange={(value) => handleUpdateEstado(cita.id, value)}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="programada">Programada</SelectItem>
                          <SelectItem value="confirmada">Confirmada</SelectItem>
                          <SelectItem value="atendida">Atendida</SelectItem>
                          <SelectItem value="cancelada">Cancelada</SelectItem>
                          <SelectItem value="no_asistio">No asistió</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AgendaMedicaManagement;
