
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface EstudioRadiologico {
  id: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  tipoEstudio: string;
  fechaSolicitud: string;
  fechaRealizacion?: string;
  medicoSolicitante: string;
  radiologo?: string;
  estado: 'solicitado' | 'programado' | 'realizado' | 'informado';
  prioridad: 'baja' | 'normal' | 'alta' | 'urgente';
  indicacion: string;
  hallazgos?: string;
  conclusion?: string;
  observaciones?: string;
}

interface EditarEstudioFormProps {
  estudio: EstudioRadiologico;
  onSave: (data: Partial<EstudioRadiologico>) => void;
  onCancel: () => void;
}

const EditarEstudioForm = ({ estudio, onSave, onCancel }: EditarEstudioFormProps) => {
  const [formData, setFormData] = useState({
    tipoEstudio: estudio.tipoEstudio,
    fechaRealizacion: estudio.fechaRealizacion || '',
    radiologo: estudio.radiologo || '',
    estado: estudio.estado,
    prioridad: estudio.prioridad,
    indicacion: estudio.indicacion,
    hallazgos: estudio.hallazgos || '',
    conclusion: estudio.conclusion || '',
    observaciones: estudio.observaciones || ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Editar Estudio Radiológico - {estudio.pacienteNombre}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="tipoEstudio">Tipo de Estudio</Label>
              <Select value={formData.tipoEstudio} onValueChange={(value) => setFormData({ ...formData, tipoEstudio: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Radiografía de Tórax">Radiografía de Tórax</SelectItem>
                  <SelectItem value="Radiografía de Abdomen">Radiografía de Abdomen</SelectItem>
                  <SelectItem value="Tomografía de Tórax">Tomografía de Tórax</SelectItem>
                  <SelectItem value="Tomografía de Abdomen">Tomografía de Abdomen</SelectItem>
                  <SelectItem value="Resonancia Magnética">Resonancia Magnética</SelectItem>
                  <SelectItem value="Ecografía Abdominal">Ecografía Abdominal</SelectItem>
                  <SelectItem value="Ecografía Pélvica">Ecografía Pélvica</SelectItem>
                  <SelectItem value="Mamografía">Mamografía</SelectItem>
                  <SelectItem value="Densitometría Ósea">Densitometría Ósea</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="fechaRealizacion">Fecha de Realización</Label>
              <Input
                id="fechaRealizacion"
                type="date"
                value={formData.fechaRealizacion}
                onChange={(e) => setFormData({ ...formData, fechaRealizacion: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="radiologo">Radiólogo</Label>
              <Input
                id="radiologo"
                value={formData.radiologo}
                onChange={(e) => setFormData({ ...formData, radiologo: e.target.value })}
                placeholder="Dr. Apellido"
              />
            </div>

            <div>
              <Label htmlFor="estado">Estado</Label>
              <Select value={formData.estado} onValueChange={(value: 'solicitado' | 'programado' | 'realizado' | 'informado') => setFormData({ ...formData, estado: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="solicitado">Solicitado</SelectItem>
                  <SelectItem value="programado">Programado</SelectItem>
                  <SelectItem value="realizado">Realizado</SelectItem>
                  <SelectItem value="informado">Informado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="prioridad">Prioridad</Label>
              <Select value={formData.prioridad} onValueChange={(value: 'baja' | 'normal' | 'alta' | 'urgente') => setFormData({ ...formData, prioridad: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="baja">Baja</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="alta">Alta</SelectItem>
                  <SelectItem value="urgente">Urgente</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="indicacion">Indicación Clínica</Label>
            <Textarea
              id="indicacion"
              value={formData.indicacion}
              onChange={(e) => setFormData({ ...formData, indicacion: e.target.value })}
              rows={2}
            />
          </div>

          <div>
            <Label htmlFor="hallazgos">Hallazgos</Label>
            <Textarea
              id="hallazgos"
              value={formData.hallazgos}
              onChange={(e) => setFormData({ ...formData, hallazgos: e.target.value })}
              placeholder="Describir los hallazgos radiológicos"
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="conclusion">Conclusión</Label>
            <Textarea
              id="conclusion"
              value={formData.conclusion}
              onChange={(e) => setFormData({ ...formData, conclusion: e.target.value })}
              placeholder="Conclusión diagnóstica"
              rows={2}
            />
          </div>

          <div>
            <Label htmlFor="observaciones">Observaciones</Label>
            <Textarea
              id="observaciones"
              value={formData.observaciones}
              onChange={(e) => setFormData({ ...formData, observaciones: e.target.value })}
              placeholder="Observaciones adicionales"
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-cyan-600 hover:bg-cyan-700">
              Guardar Cambios
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default EditarEstudioForm;
