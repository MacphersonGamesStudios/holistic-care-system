import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, User, Stethoscope, Pill, TestTube } from "lucide-react";
import { Hospitalizacion } from '../types/hospitalizacion';

interface HistoriaClinicaModalProps {
  hospitalizacion: Hospitalizacion;
  onClose: () => void;
}

const HistoriaClinicaModal = ({ hospitalizacion, onClose }: HistoriaClinicaModalProps) => {
  // Datos de ejemplo para la historia clínica
  const historiaClinica = {
    antecedentesMedicos: [
      'Hipertensión arterial (2015)',
      'Diabetes tipo 2 (2018)',
      'Alergia a penicilina'
    ],
    medicamentosActuales: [
      'Metformina 850mg - 2 veces al día',
      'Enalapril 10mg - 1 vez al día',
      'Aspirina 100mg - 1 vez al día'
    ],
    examenes: [
      {
        fecha: '2024-05-20',
        tipo: 'Radiografía de tórax',
        resultado: 'Infiltrado pulmonar en lóbulo inferior derecho'
      },
      {
        fecha: '2024-05-20',
        tipo: 'Hemograma completo',
        resultado: 'Leucocitosis 15,000/mm³'
      },
      {
        fecha: '2024-05-21',
        tipo: 'Gases arteriales',
        resultado: 'PaO2: 75 mmHg, PCO2: 35 mmHg'
      }
    ],
    evoluciones: [
      {
        fecha: '2024-05-20',
        medico: 'Dr. Martínez',
        nota: 'Paciente ingresa por cuadro de disnea y tos productiva. Se inicia tratamiento antibiótico.'
      },
      {
        fecha: '2024-05-21',
        medico: 'Dr. Martínez',
        nota: 'Mejoría clínica. Disminución de la disnea. Continúa tratamiento.'
      },
      {
        fecha: '2024-05-22',
        medico: 'Dr. Martínez',
        nota: 'Paciente estable, afebril. Se considera alta en las próximas 24 horas.'
      }
    ]
  };

  return (
    <div className="space-y-6 max-h-[80vh] overflow-y-auto">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">Historia Clínica</h2>
        <Button variant="outline" onClick={onClose}>Cerrar</Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5 text-cyan-600" />
            Datos del Paciente
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <span className="text-sm font-medium text-gray-600">Nombre:</span>
              <p className="text-cyan-600 font-medium">{hospitalizacion.pacienteNombre}</p>
            </div>
            <div>
              <span className="text-sm font-medium text-gray-600">Historia:</span>
              <p className="font-mono">{hospitalizacion.numeroHistoria}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Stethoscope className="h-5 w-5 text-cyan-600" />
            Antecedentes Médicos
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {historiaClinica.antecedentesMedicos.map((antecedente, index) => (
              <li key={index} className="flex items-center gap-2">
                <div className="w-2 h-2 bg-cyan-600 rounded-full"></div>
                <span>{antecedente}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Pill className="h-5 w-5 text-cyan-600" />
            Medicamentos Actuales
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {historiaClinica.medicamentosActuales.map((medicamento, index) => (
              <li key={index} className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                <span>{medicamento}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TestTube className="h-5 w-5 text-cyan-600" />
            Exámenes Realizados
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {historiaClinica.examenes.map((examen, index) => (
              <div key={index} className="border-l-4 border-cyan-600 pl-4">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline">{examen.fecha}</Badge>
                  <span className="font-medium">{examen.tipo}</span>
                </div>
                <p className="text-gray-700">{examen.resultado}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-cyan-600" />
            Evolución Médica
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {historiaClinica.evoluciones.map((evolucion, index) => (
              <div key={index} className="border-l-4 border-blue-600 pl-4">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline">{evolucion.fecha}</Badge>
                  <span className="font-medium text-blue-600">{evolucion.medico}</span>
                </div>
                <p className="text-gray-700">{evolucion.nota}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default HistoriaClinicaModal;
