
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Package, AlertTriangle, Pill } from "lucide-react";
import { Medicamento } from '@/hooks/useFarmaciaData';

interface FarmaciaStatsCardsProps {
  medicamentos: Medicamento[];
}

const FarmaciaStatsCards = ({ medicamentos }: FarmaciaStatsCardsProps) => {
  const medicamentosBajoStock = medicamentos.filter(m => m.stock <= m.stockMinimo).length;
  const medicamentosCriticos = medicamentos.filter(m => m.stock < m.stockMinimo * 0.5).length;
  const valorInventario = medicamentos.reduce((total, m) => total + (m.stock * m.precio), 0);

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2">
            <Package className="text-blue-600" size={20} />
            <div>
              <div className="text-2xl font-bold text-blue-600">{medicamentos.length}</div>
              <div className="text-sm text-gray-600">Medicamentos</div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="text-orange-600" size={20} />
            <div>
              <div className="text-2xl font-bold text-orange-600">{medicamentosBajoStock}</div>
              <div className="text-sm text-gray-600">Stock Bajo</div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="text-red-600" size={20} />
            <div>
              <div className="text-2xl font-bold text-red-600">{medicamentosCriticos}</div>
              <div className="text-sm text-gray-600">Stock Crítico</div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2">
            <Pill className="text-green-600" size={20} />
            <div>
              <div className="text-2xl font-bold text-green-600">€{valorInventario.toFixed(2)}</div>
              <div className="text-sm text-gray-600">Valor Inventario</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FarmaciaStatsCards;
