
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Search, X } from "lucide-react";

interface PacientesFiltersProps {
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  selectedState: string;
  setSelectedState: (value: string) => void;
  ocultarSinHistoria: boolean;
  setOcultarSinHistoria: (value: boolean) => void;
  clienteTutor: string;
  setClienteTutor: (value: string) => void;
}

const PacientesFilters = ({
  searchTerm,
  setSearchTerm,
  selectedState,
  setSelectedState,
  ocultarSinHistoria,
  setOcultarSinHistoria,
  clienteTutor,
  setClienteTutor
}: PacientesFiltersProps) => {
  const handleCheckboxChange = (checked: boolean | "indeterminate") => {
    setOcultarSinHistoria(checked === true);
  };

  const clearClienteTutor = () => {
    setClienteTutor('');
  };

  return (
    <Card>
      <CardContent className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Estado</label>
            <Select value={selectedState} onValueChange={setSelectedState}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="activos">Activos</SelectItem>
                <SelectItem value="inactivos">Inactivos</SelectItem>
                <SelectItem value="todos">Todos</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2 pt-6">
            <Checkbox 
              id="ocultar-historia" 
              checked={ocultarSinHistoria}
              onCheckedChange={handleCheckboxChange}
            />
            <label htmlFor="ocultar-historia" className="text-sm text-gray-700">
              Ocultar pacientes sin historia
            </label>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Paciente</label>
            <div className="relative">
              <Input
                placeholder="Buscar paciente..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Cliente/Tutor</label>
            <div className="relative">
              <Input
                placeholder="Buscar cliente/tutor..."
                value={clienteTutor}
                onChange={(e) => setClienteTutor(e.target.value)}
              />
              {clienteTutor && (
                <button
                  onClick={clearClienteTutor}
                  className="absolute right-3 top-3 text-cyan-500 hover:text-cyan-700"
                >
                  <X size={16} />
                </button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PacientesFilters;
