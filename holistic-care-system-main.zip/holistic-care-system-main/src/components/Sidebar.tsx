
import React from 'react';
import { cn } from "@/lib/utils";
import { Calendar, Users, FileText, DollarSign, Settings, Database, Heart, Pill, Image, TestTube } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";

interface SidebarProps {
  className?: string;
}

const Sidebar = ({ className }: SidebarProps) => {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    {
      icon: Heart,
      label: "Gestión médica",
      path: "/dashboard",
      color: "text-cyan-600"
    },
    {
      icon: Calendar,
      label: "Agenda",
      path: "/agenda",
      color: "text-cyan-600"
    },
    {
      icon: Users,
      label: "Visitas",
      path: "/visitas",
      color: "text-cyan-600"
    },
    {
      icon: FileText,
      label: "Facturación",
      path: "/facturacion",
      color: "text-cyan-600"
    },
    {
      icon: Users,
      label: "Liquidaciones",
      path: "/liquidaciones",
      color: "text-cyan-600"
    },
    {
      icon: DollarSign,
      label: "Presupuestos",
      path: "/presupuestos",
      color: "text-cyan-600"
    },
    {
      icon: Database,
      label: "Archivo",
      path: "/archivo",
      color: "text-cyan-600"
    },
    {
      icon: Settings,
      label: "Herramientas",
      path: "/herramientas",
      color: "text-cyan-600"
    },
    {
      icon: Users,
      label: "Comunicación pacientes",
      path: "/comunicacion",
      color: "text-cyan-600"
    },
    {
      icon: TestTube,
      label: "Listados Estadísticos",
      path: "/estadisticas",
      color: "text-cyan-600"
    },
    {
      icon: Heart,
      label: "Hospitalización",
      path: "/hospitalizacion",
      color: "text-cyan-600"
    },
    {
      icon: Pill,
      label: "Farmacia",
      path: "/farmacia",
      color: "text-cyan-600"
    },
    {
      icon: Image,
      label: "Radiología",
      path: "/radiologia",
      color: "text-cyan-600"
    },
    {
      icon: TestTube,
      label: "Laboratorio",
      path: "/laboratorio",
      color: "text-cyan-600"
    }
  ];

  return (
    <div className={cn("bg-cyan-600 text-white w-16 min-h-screen fixed left-0 top-0 z-50 flex flex-col", className)}>
      {/* Logo */}
      <div className="p-3 border-b border-cyan-500">
        <div className="bg-white text-cyan-600 px-2 py-1 rounded text-xs font-bold text-center">
          DASI
        </div>
      </div>

      {/* Menu Items */}
      <div className="flex-1 py-4">
        {menuItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <button
              key={index}
              onClick={() => navigate(item.path)}
              className={cn(
                "w-full p-3 flex flex-col items-center gap-1 hover:bg-cyan-500 transition-colors relative group",
                isActive && "bg-cyan-500"
              )}
            >
              <Icon size={20} />
              <span className="text-xs leading-tight text-center">{item.label}</span>
              
              {/* Tooltip */}
              <div className="absolute left-full ml-2 px-2 py-1 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50">
                {item.label}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default Sidebar;
