
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import HospitalizacionTable from './HospitalizacionTable';
import NuevaHospitalizacionForm from './NuevaHospitalizacionForm';
import HospitalizacionStatsCards from './HospitalizacionStatsCards';
import HospitalizacionFilters from './HospitalizacionFilters';
import { useHospitalizaciones } from '../hooks/useHospitalizaciones';
import { Hospitalizacion } from '../types/hospitalizacion';

const HospitalizacionManagement = () => {
  const {
    hospitalizaciones,
    handleNewHospitalizacion,
    handleUpdateHospitalizacion,
    handleDarAlta
  } = useHospitalizaciones();

  const [filteredHospitalizaciones, setFilteredHospitalizaciones] = useState<Hospitalizacion[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEstado, setSelectedEstado] = useState('todos');
  const [selectedHabitacion, setSelectedHabitacion] = useState('todas');
  const [showNewHospitalizacionDialog, setShowNewHospitalizacionDialog] = useState(false);

  useEffect(() => {
    let filtered = hospitalizaciones;

    // Filtrar por estado
    if (selectedEstado !== 'todos') {
      filtered = filtered.filter(h => h.estado === selectedEstado);
    }

    // Filtrar por habitación
    if (selectedHabitacion !== 'todas') {
      filtered = filtered.filter(h => h.habitacion === selectedHabitacion);
    }

    // Filtrar por búsqueda
    if (searchTerm) {
      filtered = filtered.filter(h => 
        h.pacienteNombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
        h.numeroHistoria.toLowerCase().includes(searchTerm.toLowerCase()) ||
        h.habitacion.toLowerCase().includes(searchTerm.toLowerCase()) ||
        h.medicoResponsable.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredHospitalizaciones(filtered);
  }, [hospitalizaciones, searchTerm, selectedEstado, selectedHabitacion]);

  const handleClearFilters = () => {
    setSearchTerm('');
    setSelectedEstado('todos');
    setSelectedHabitacion('todas');
  };

  const onSaveHospitalizacion = (data: any) => {
    handleNewHospitalizacion(data);
    setShowNewHospitalizacionDialog(false);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Breadcrumb */}
      <div className="text-sm text-gray-600 mb-4">
        <span className="text-cyan-600">Gestión médica</span> / <span>Hospitalización</span>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Hospitalización</h1>
          <Dialog open={showNewHospitalizacionDialog} onOpenChange={setShowNewHospitalizacionDialog}>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
                <Plus size={16} />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Nueva Hospitalización</DialogTitle>
              </DialogHeader>
              <NuevaHospitalizacionForm 
                onSave={onSaveHospitalizacion} 
                onCancel={() => setShowNewHospitalizacionDialog(false)} 
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <HospitalizacionStatsCards hospitalizaciones={hospitalizaciones} />

      {/* Filters */}
      <HospitalizacionFilters
        searchTerm={searchTerm}
        selectedEstado={selectedEstado}
        selectedHabitacion={selectedHabitacion}
        onSearchChange={setSearchTerm}
        onEstadoChange={setSelectedEstado}
        onHabitacionChange={setSelectedHabitacion}
        onClearFilters={handleClearFilters}
      />

      {/* Hospitalizaciones Table */}
      <HospitalizacionTable 
        hospitalizaciones={filteredHospitalizaciones}
        onDarAlta={handleDarAlta}
        onUpdate={handleUpdateHospitalizacion}
      />
    </div>
  );
};

export default HospitalizacionManagement;
