
import React from 'react';
import { useNavigate } from 'react-router-dom';
import ModuleCard from './ModuleCard';
import { 
  FileText, 
  TestTube, 
  Pill, 
  Calendar,
  Heart,
  Image,
  User,
  Download
} from 'lucide-react';

const PatientPortal = () => {
  const navigate = useNavigate();

  const patientModules = [
    {
      title: "Mis Citas",
      icon: Calendar,
      color: "bg-gradient-to-br from-blue-500 to-blue-600",
      path: "/patient/citas"
    },
    {
      title: "Mis Informes",
      icon: FileText,
      color: "bg-gradient-to-br from-green-500 to-green-600",
      path: "/patient/informes"
    },
    {
      title: "Resultados de Laboratorio",
      icon: TestTube,
      color: "bg-gradient-to-br from-purple-500 to-purple-600",
      path: "/patient/laboratorio"
    },
    {
      title: "Mis Recetas",
      icon: Pill,
      color: "bg-gradient-to-br from-orange-500 to-orange-600",
      path: "/patient/recetas"
    },
    {
      title: "Radiografías",
      icon: Image,
      color: "bg-gradient-to-br from-yellow-500 to-yellow-600",
      path: "/patient/radiografias"
    },
    {
      title: "Historia Clínica",
      icon: Heart,
      color: "bg-gradient-to-br from-red-500 to-red-600",
      path: "/patient/historia"
    },
    {
      title: "Mi Perfil",
      icon: User,
      color: "bg-gradient-to-br from-gray-500 to-gray-600",
      path: "/patient/perfil"
    },
    {
      title: "Descargas",
      icon: Download,
      color: "bg-gradient-to-br from-teal-500 to-teal-600",
      path: "/patient/descargas"
    }
  ];

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-800">Portal del Paciente</h1>
        <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
          <span className="text-gray-600 text-sm">?</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {patientModules.map((module, index) => (
          <ModuleCard
            key={index}
            title={module.title}
            icon={module.icon}
            color={module.color}
            onClick={() => navigate(module.path)}
          />
        ))}
      </div>
    </div>
  );
};

export default PatientPortal;
