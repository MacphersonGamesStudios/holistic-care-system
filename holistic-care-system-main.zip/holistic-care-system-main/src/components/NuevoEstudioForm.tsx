
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface NuevoEstudioFormProps {
  onSave: (data: any) => void;
  onCancel: () => void;
}

const NuevoEstudioForm = ({ onSave, onCancel }: NuevoEstudioFormProps) => {
  const [formData, setFormData] = useState({
    pacienteNombre: '',
    numeroHistoria: '',
    tipoEstudio: '',
    medicoSolicitante: '',
    prioridad: 'normal',
    indicacion: '',
    observaciones: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.pacienteNombre || !formData.numeroHistoria || !formData.tipoEstudio || !formData.medicoSolicitante || !formData.indicacion) {
      alert('Por favor complete todos los campos obligatorios');
      return;
    }
    onSave(formData);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Solicitar Nuevo Estudio Radiológico</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="pacienteNombre">Nombre del Paciente *</Label>
              <Input
                id="pacienteNombre"
                value={formData.pacienteNombre}
                onChange={(e) => setFormData({ ...formData, pacienteNombre: e.target.value })}
                placeholder="Apellidos, Nombres"
                required
              />
            </div>

            <div>
              <Label htmlFor="numeroHistoria">Número de Historia *</Label>
              <Input
                id="numeroHistoria"
                value={formData.numeroHistoria}
                onChange={(e) => setFormData({ ...formData, numeroHistoria: e.target.value })}
                placeholder="HST001"
                required
              />
            </div>

            <div>
              <Label htmlFor="tipoEstudio">Tipo de Estudio *</Label>
              <Select value={formData.tipoEstudio} onValueChange={(value) => setFormData({ ...formData, tipoEstudio: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar estudio" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Radiografía de Tórax">Radiografía de Tórax</SelectItem>
                  <SelectItem value="Radiografía de Abdomen">Radiografía de Abdomen</SelectItem>
                  <SelectItem value="Tomografía de Tórax">Tomografía de Tórax</SelectItem>
                  <SelectItem value="Tomografía de Abdomen">Tomografía de Abdomen</SelectItem>
                  <SelectItem value="Resonancia Magnética">Resonancia Magnética</SelectItem>
                  <SelectItem value="Ecografía Abdominal">Ecografía Abdominal</SelectItem>
                  <SelectItem value="Ecografía Pélvica">Ecografía Pélvica</SelectItem>
                  <SelectItem value="Mamografía">Mamografía</SelectItem>
                  <SelectItem value="Densitometría Ósea">Densitometría Ósea</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="medicoSolicitante">Médico Solicitante *</Label>
              <Input
                id="medicoSolicitante"
                value={formData.medicoSolicitante}
                onChange={(e) => setFormData({ ...formData, medicoSolicitante: e.target.value })}
                placeholder="Dr. Apellido"
                required
              />
            </div>

            <div>
              <Label htmlFor="prioridad">Prioridad</Label>
              <Select value={formData.prioridad} onValueChange={(value) => setFormData({ ...formData, prioridad: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="baja">Baja</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="alta">Alta</SelectItem>
                  <SelectItem value="urgente">Urgente</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="indicacion">Indicación Clínica *</Label>
            <Textarea
              id="indicacion"
              value={formData.indicacion}
              onChange={(e) => setFormData({ ...formData, indicacion: e.target.value })}
              placeholder="Describir la indicación médica para el estudio"
              rows={3}
              required
            />
          </div>

          <div>
            <Label htmlFor="observaciones">Observaciones</Label>
            <Textarea
              id="observaciones"
              value={formData.observaciones}
              onChange={(e) => setFormData({ ...formData, observaciones: e.target.value })}
              placeholder="Observaciones adicionales (opcional)"
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-cyan-600 hover:bg-cyan-700">
              Solicitar Estudio
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default NuevoEstudioForm;
