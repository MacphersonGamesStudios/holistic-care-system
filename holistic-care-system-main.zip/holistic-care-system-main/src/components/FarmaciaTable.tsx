
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, Edit, ShoppingCart } from "lucide-react";
import { Medicamento } from '@/hooks/useFarmaciaData';

interface FarmaciaTableProps {
  medicamentos: Medicamento[];
  onView: (medicamento: Medicamento) => void;
  onEdit: (medicamento: Medicamento) => void;
  onVenta: (medicamento: Medicamento) => void;
}

const FarmaciaTable = ({ medicamentos, onView, onEdit, onVenta }: FarmaciaTableProps) => {
  const getStockBadge = (medicamento: Medicamento) => {
    if (medicamento.stock <= medicamento.stockMinimo * 0.5) {
      return <Badge variant="destructive">Stock Crítico</Badge>;
    } else if (medicamento.stock <= medicamento.stockMinimo) {
      return <Badge variant="secondary" className="bg-orange-100 text-orange-800">Stock Bajo</Badge>;
    } else {
      return <Badge variant="secondary" className="bg-green-100 text-green-800">Stock Normal</Badge>;
    }
  };

  return (
    <Card>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow className="bg-cyan-600 hover:bg-cyan-600">
              <TableHead className="text-white font-semibold">Medicamento</TableHead>
              <TableHead className="text-white font-semibold">Laboratorio</TableHead>
              <TableHead className="text-white font-semibold">Stock</TableHead>
              <TableHead className="text-white font-semibold">Estado</TableHead>
              <TableHead className="text-white font-semibold">Precio</TableHead>
              <TableHead className="text-white font-semibold">Caducidad</TableHead>
              <TableHead className="text-white font-semibold">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {medicamentos.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                  No se encontraron medicamentos
                </TableCell>
              </TableRow>
            ) : (
              medicamentos.map((medicamento) => (
                <TableRow key={medicamento.id} className="hover:bg-gray-50">
                  <TableCell>
                    <div>
                      <div className="font-medium text-cyan-600">{medicamento.nombre}</div>
                      <div className="text-sm text-gray-600">{medicamento.principioActivo}</div>
                      <div className="text-xs text-gray-500">{medicamento.presentacion}</div>
                      {medicamento.prescripcion && (
                        <Badge variant="outline" className="mt-1 text-xs">Con receta</Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>{medicamento.laboratorio}</TableCell>
                  <TableCell>
                    <div className="font-mono">
                      <div>{medicamento.stock} uds</div>
                      <div className="text-xs text-gray-500">Min: {medicamento.stockMinimo}</div>
                    </div>
                  </TableCell>
                  <TableCell>{getStockBadge(medicamento)}</TableCell>
                  <TableCell className="font-mono">€{medicamento.precio.toFixed(2)}</TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{medicamento.fechaCaducidad}</div>
                      <div className="text-xs text-gray-500">Lote: {medicamento.lote}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Ver detalles" onClick={() => onView(medicamento)}>
                        <Eye size={16} className="text-gray-600" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Editar" onClick={() => onEdit(medicamento)}>
                        <Edit size={16} className="text-gray-600" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Vender" onClick={() => onVenta(medicamento)}>
                        <ShoppingCart size={16} className="text-green-600" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default FarmaciaTable;
