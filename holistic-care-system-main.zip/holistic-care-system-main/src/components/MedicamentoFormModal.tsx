
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface MedicamentoFormData {
  nombre: string;
  principioActivo: string;
  laboratorio: string;
  presentacion: string;
  stock: string;
  stockMinimo: string;
  precio: string;
  fechaCaducidad: string;
  lote: string;
  categoria: string;
  prescripcion: boolean;
}

interface MedicamentoFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  title: string;
  editData?: any;
}

const MedicamentoFormModal = ({
  isOpen,
  onClose,
  onSubmit,
  title,
  editData
}: MedicamentoFormModalProps) => {
  const [formData, setFormData] = useState<MedicamentoFormData>({
    nombre: '',
    principioActivo: '',
    laboratorio: '',
    presentacion: '',
    stock: '',
    stockMinimo: '',
    precio: '',
    fechaCaducidad: '',
    lote: '',
    categoria: '',
    prescripcion: false
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = () => {
    onSubmit({
      ...formData,
      stock: parseInt(formData.stock),
      stockMinimo: parseInt(formData.stockMinimo),
      precio: parseFloat(formData.precio)
    });
    onClose();
    if (!editData) {
      setFormData({
        nombre: '',
        principioActivo: '',
        laboratorio: '',
        presentacion: '',
        stock: '',
        stockMinimo: '',
        precio: '',
        fechaCaducidad: '',
        lote: '',
        categoria: '',
        prescripcion: false
      });
    }
  };

  useEffect(() => {
    if (editData && isOpen) {
      setFormData({
        nombre: editData.nombre,
        principioActivo: editData.principioActivo,
        laboratorio: editData.laboratorio,
        presentacion: editData.presentacion,
        stock: editData.stock.toString(),
        stockMinimo: editData.stockMinimo.toString(),
        precio: editData.precio.toString(),
        fechaCaducidad: editData.fechaCaducidad,
        lote: editData.lote,
        categoria: editData.categoria,
        prescripcion: editData.prescripcion
      });
    }
  }, [editData, isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="nombre">Nombre del medicamento</Label>
            <Input
              id="nombre"
              value={formData.nombre}
              onChange={(e) => handleInputChange('nombre', e.target.value)}
              placeholder="Ej: Paracetamol 500mg"
            />
          </div>
          <div>
            <Label htmlFor="principioActivo">Principio activo</Label>
            <Input
              id="principioActivo"
              value={formData.principioActivo}
              onChange={(e) => handleInputChange('principioActivo', e.target.value)}
              placeholder="Ej: Paracetamol"
            />
          </div>
          <div>
            <Label htmlFor="laboratorio">Laboratorio</Label>
            <Input
              id="laboratorio"
              value={formData.laboratorio}
              onChange={(e) => handleInputChange('laboratorio', e.target.value)}
              placeholder="Ej: Cinfa"
            />
          </div>
          <div>
            <Label htmlFor="presentacion">Presentación</Label>
            <Input
              id="presentacion"
              value={formData.presentacion}
              onChange={(e) => handleInputChange('presentacion', e.target.value)}
              placeholder="Ej: Comprimidos x20"
            />
          </div>
          <div>
            <Label htmlFor="stock">Stock actual</Label>
            <Input
              id="stock"
              type="number"
              value={formData.stock}
              onChange={(e) => handleInputChange('stock', e.target.value)}
              placeholder="0"
            />
          </div>
          <div>
            <Label htmlFor="stockMinimo">Stock mínimo</Label>
            <Input
              id="stockMinimo"
              type="number"
              value={formData.stockMinimo}
              onChange={(e) => handleInputChange('stockMinimo', e.target.value)}
              placeholder="0"
            />
          </div>
          <div>
            <Label htmlFor="precio">Precio (€)</Label>
            <Input
              id="precio"
              type="number"
              step="0.01"
              value={formData.precio}
              onChange={(e) => handleInputChange('precio', e.target.value)}
              placeholder="0.00"
            />
          </div>
          <div>
            <Label htmlFor="categoria">Categoría</Label>
            <Select value={formData.categoria} onValueChange={(value) => handleInputChange('categoria', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar categoría" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Analgésicos">Analgésicos</SelectItem>
                <SelectItem value="Antibióticos">Antibióticos</SelectItem>
                <SelectItem value="Antiinflamatorios">Antiinflamatorios</SelectItem>
                <SelectItem value="Cardiovasculares">Cardiovasculares</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="fechaCaducidad">Fecha de caducidad</Label>
            <Input
              id="fechaCaducidad"
              type="date"
              value={formData.fechaCaducidad}
              onChange={(e) => handleInputChange('fechaCaducidad', e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="lote">Lote</Label>
            <Input
              id="lote"
              value={formData.lote}
              onChange={(e) => handleInputChange('lote', e.target.value)}
              placeholder="Ej: LOT001"
            />
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="prescripcion"
            checked={formData.prescripcion}
            onChange={(e) => handleInputChange('prescripcion', e.target.checked)}
          />
          <Label htmlFor="prescripcion">Requiere prescripción médica</Label>
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} className="bg-cyan-600 hover:bg-cyan-700">
            {editData ? 'Actualizar' : 'Guardar'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default MedicamentoFormModal;
