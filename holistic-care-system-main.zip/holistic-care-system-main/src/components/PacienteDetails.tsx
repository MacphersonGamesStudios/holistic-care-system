
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface Paciente {
  id: string;
  numeroHistoria: string;
  nombre: string;
  apellidos: string;
  dni: string;
  fechaNacimiento: string;
  sexo: string;
  telefono: string;
  email: string;
  fechaAlta: string;
  activo: boolean;
  foto?: string;
  direccion?: string;
  codigoPostal?: string;
  provincia?: string;
  poblacion?: string;
  observaciones?: string;
}

interface PacienteDetailsProps {
  paciente: Paciente;
  onEdit: () => void;
  onClose: () => void;
}

const PacienteDetails = ({ paciente, onEdit, onClose }: PacienteDetailsProps) => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Detalles del Paciente</h2>
        <div className="flex gap-2">
          <Button onClick={onEdit} className="bg-cyan-600 hover:bg-cyan-700">
            Editar
          </Button>
          <Button variant="outline" onClick={onClose}>
            Cerrar
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Photo and basic info */}
        <Card>
          <CardHeader>
            <CardTitle>Información Básica</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col items-center space-y-4">
              <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center overflow-hidden">
                {paciente.foto ? (
                  <img src={paciente.foto} alt="Paciente" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-gray-400 text-2xl">👤</span>
                )}
              </div>
              <div className="text-center">
                <h3 className="font-semibold text-lg">{paciente.nombre} {paciente.apellidos}</h3>
                <p className="text-gray-600">{paciente.dni}</p>
              </div>
            </div>
            
            <div className="space-y-2">
              <div>
                <span className="font-medium">Historia:</span> {paciente.numeroHistoria}
              </div>
              <div>
                <span className="font-medium">Sexo:</span> {paciente.sexo}
              </div>
              <div>
                <span className="font-medium">Fecha de nacimiento:</span> {paciente.fechaNacimiento}
              </div>
              <div>
                <span className="font-medium">Estado:</span>{' '}
                <Badge variant={paciente.activo ? 'default' : 'secondary'}>
                  {paciente.activo ? 'Activo' : 'Inactivo'}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact info */}
        <Card>
          <CardHeader>
            <CardTitle>Información de Contacto</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <span className="font-medium">Email:</span>
              <p className="text-gray-600">{paciente.email || 'No especificado'}</p>
            </div>
            <div>
              <span className="font-medium">Teléfono:</span>
              <p className="text-gray-600">{paciente.telefono || 'No especificado'}</p>
            </div>
            <div>
              <span className="font-medium">Dirección:</span>
              <p className="text-gray-600">{paciente.direccion || 'No especificada'}</p>
            </div>
            <div>
              <span className="font-medium">Código Postal:</span>
              <p className="text-gray-600">{paciente.codigoPostal || 'No especificado'}</p>
            </div>
            <div>
              <span className="font-medium">Provincia:</span>
              <p className="text-gray-600">{paciente.provincia || 'No especificada'}</p>
            </div>
            <div>
              <span className="font-medium">Población:</span>
              <p className="text-gray-600">{paciente.poblacion || 'No especificada'}</p>
            </div>
          </CardContent>
        </Card>

        {/* Additional info */}
        <Card>
          <CardHeader>
            <CardTitle>Información Adicional</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <span className="font-medium">Fecha de alta:</span>
              <p className="text-gray-600">{paciente.fechaAlta}</p>
            </div>
            {paciente.observaciones && (
              <div>
                <span className="font-medium">Observaciones:</span>
                <p className="text-gray-600 mt-1">{paciente.observaciones}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PacienteDetails;
