
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Eye, EyeOff, UserPlus, Users, User } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";

const LoginForm = () => {
  const [usuario, setUsuario] = useState('');
  const [contrasena, setContrasena] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!usuario || !contrasena) {
      toast({
        title: "Error de acceso",
        description: "Por favor, complete todos los campos",
        variant: "destructive",
      });
      return;
    }

    // Autenticación específica para el administrador del Hospital Macpherson
    if (usuario === 'hospitalmacpherson@groupmacpherson.com' || usuario === 'admin') {
      localStorage.setItem('hospitalUser', JSON.stringify({
        username: 'Administrador Hospital',
        email: 'hospitalmacpherson@groupmacpherson.com',
        role: 'super_admin',
        hospital: 'Hospital Macpherson',
        permissions: ['all']
      }));

      toast({
        title: "Acceso exitoso",
        description: `Bienvenido Administrador del Hospital Macpherson`,
      });

      navigate('/admin');
      return;
    }

    // Verificar en usuarios registrados localmente
    const registeredUsers = JSON.parse(localStorage.getItem('hospitalUsers') || '[]');
    const user = registeredUsers.find((u: any) => 
      u.email === usuario && u.activo
    );

    if (user) {
      localStorage.setItem('hospitalUser', JSON.stringify({
        id: user.id,
        username: `${user.nombre} ${user.apellidos}`,
        email: user.email,
        role: user.tipoUsuario,
        hospital: 'Hospital Macpherson'
      }));

      toast({
        title: "Acceso exitoso",
        description: `Bienvenido ${user.nombre} ${user.apellidos}`,
      });

      navigate('/dashboard');
      return;
    }

    // Login de administrador por defecto
    if (usuario === 'admin' && contrasena === 'admin') {
      localStorage.setItem('hospitalUser', JSON.stringify({
        username: 'Administrador',
        email: 'admin@hospital.com',
        role: 'admin',
        hospital: 'Hospital Macpherson'
      }));

      toast({
        title: "Acceso exitoso",
        description: `Bienvenido Administrador`,
      });

      navigate('/dashboard');
      return;
    }

    toast({
      title: "Error de acceso",
      description: "Usuario o contraseña incorrectos",
      variant: "destructive",
    });
  };

  return (
    <div className="min-h-screen hospital-gradient flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-white/95 backdrop-blur-sm shadow-xl">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <div className="bg-cyan-600 text-white px-4 py-2 rounded-md inline-flex items-center gap-2 mb-4">
              <span className="font-bold">DASI</span>
              <span className="bg-white text-cyan-600 px-2 py-1 rounded text-sm font-semibold">eCLINIC</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Sistema de Gestión Hospitalaria</h1>
            <p className="text-gray-600">Ingrese sus credenciales para acceder</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <Input
                type="text"
                placeholder="Usuario o Email"
                value={usuario}
                onChange={(e) => setUsuario(e.target.value)}
                className="w-full h-12 text-base border-gray-300 focus:border-cyan-500"
              />
            </div>

            <div className="relative">
              <Input
                type={showPassword ? "text" : "password"}
                placeholder="Contraseña"
                value={contrasena}
                onChange={(e) => setContrasena(e.target.value)}
                className="w-full h-12 text-base border-gray-300 focus:border-cyan-500 pr-12"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 bg-cyan-600 hover:bg-cyan-700 text-white font-semibold text-base"
            >
              Acceder
            </Button>
          </form>

          <div className="mt-8 space-y-4">
            <div className="text-center">
              <p className="text-sm text-gray-600 mb-4">¿No tienes cuenta?</p>
              <div className="grid grid-cols-1 gap-3">
                <Button
                  onClick={() => navigate('/register')}
                  variant="outline"
                  className="w-full h-12 border-cyan-600 text-cyan-600 hover:bg-cyan-50 flex items-center gap-2"
                >
                  <UserPlus size={20} />
                  Registrarse como Personal
                </Button>
                
                <Button
                  onClick={() => navigate('/register-patient')}
                  variant="outline"
                  className="w-full h-12 border-green-600 text-green-600 hover:bg-green-50 flex items-center gap-2"
                >
                  <Users size={20} />
                  Registrarse como Paciente
                </Button>
              </div>
            </div>

            <div className="text-center">
              <div className="border-t pt-4">
                <p className="text-sm text-gray-600 mb-3">¿Eres paciente registrado?</p>
                <Button
                  onClick={() => navigate('/patient-login')}
                  variant="outline"
                  className="w-full h-12 border-green-600 text-green-600 hover:bg-green-50 flex items-center gap-2"
                >
                  <User size={20} />
                  Acceder como Paciente
                </Button>
              </div>
            </div>

            <div className="text-center space-y-2 text-sm border-t pt-4">
              <a href="#" className="text-cyan-600 hover:text-cyan-700 block">Recuperar contraseña</a>
              <a href="#" className="text-cyan-600 hover:text-cyan-700 block">Visita nuestra web</a>
              <div className="text-xs text-gray-500 mt-4">
                <p>Administrador: hospitalmacpherson@groupmacpherson.com</p>
                <p>Usuario demo: admin / admin</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LoginForm;
