
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Search, ShoppingCart } from "lucide-react";

interface FarmaciaFiltersProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  categoriaFilter: string;
  setCategoriaFilter: (categoria: string) => void;
  stockFilter: string;
  setStockFilter: (stock: string) => void;
  onNuevaVenta: () => void;
}

const FarmaciaFilters = ({ 
  searchTerm, 
  setSearchTerm, 
  categoriaFilter, 
  setCategoriaFilter, 
  stockFilter, 
  setStockFilter,
  onNuevaVenta 
}: FarmaciaFiltersProps) => {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Buscar medicamento</label>
            <div className="relative">
              <Input
                placeholder="Buscar por nombre, principio activo..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Categoría</label>
            <Select value={categoriaFilter} onValueChange={setCategoriaFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas las categorías</SelectItem>
                <SelectItem value="Analgésicos">Analgésicos</SelectItem>
                <SelectItem value="Antibióticos">Antibióticos</SelectItem>
                <SelectItem value="Antiinflamatorios">Antiinflamatorios</SelectItem>
                <SelectItem value="Cardiovasculares">Cardiovasculares</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Estado del Stock</label>
            <Select value={stockFilter} onValueChange={setStockFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                <SelectItem value="bajo">Stock Bajo</SelectItem>
                <SelectItem value="critico">Stock Crítico</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-end">
            <Button className="w-full bg-cyan-600 hover:bg-cyan-700" onClick={onNuevaVenta}>
              <ShoppingCart size={16} className="mr-1" />
              Nueva Venta
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FarmaciaFilters;
