
import React from 'react';
import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface ModuleCardProps {
  title: string;
  icon: LucideIcon;
  color: string;
  onClick: () => void;
  className?: string;
}

const ModuleCard = ({ title, icon: Icon, color, onClick, className }: ModuleCardProps) => {
  return (
    <Card 
      className={cn(
        "module-card cursor-pointer overflow-hidden border-0 shadow-lg",
        color,
        className
      )}
      onClick={onClick}
    >
      <div className="p-6 text-white relative h-32">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h3 className="font-semibold text-lg leading-tight">{title}</h3>
            <div className="mt-4 flex items-center gap-2">
              <div className="w-6 h-6 bg-white bg-opacity-30 rounded-full flex items-center justify-center">
                <span className="text-xs">?</span>
              </div>
              <div className="w-6 h-6 bg-white bg-opacity-30 rounded-full"></div>
            </div>
          </div>
          <div className="opacity-30">
            <Icon size={48} />
          </div>
        </div>
        <div className="absolute bottom-4 right-4">
          <div className="w-6 h-6 bg-white bg-opacity-30 rounded-sm flex items-center justify-center">
            <span className="text-white text-sm">›</span>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default ModuleCard;
