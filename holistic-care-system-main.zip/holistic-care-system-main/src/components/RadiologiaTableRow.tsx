
import React from 'react';
import { TableCell, TableRow } from "@/components/ui/table";
import RadiologiaActionButtons from './RadiologiaActionButtons';
import { getEstadoBadge, getPrioridadBadge } from '../utils/radiologiaBadges';

interface EstudioRadiologico {
  id: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  tipoEstudio: string;
  fechaSolicitud: string;
  fechaRealizacion?: string;
  medicoSolicitante: string;
  radiologo?: string;
  estado: 'solicitado' | 'programado' | 'realizado' | 'informado';
  prioridad: 'baja' | 'normal' | 'alta' | 'urgente';
  indicacion: string;
  hallazgos?: string;
  conclusion?: string;
  observaciones?: string;
}

interface RadiologiaTableRowProps {
  estudio: EstudioRadiologico;
  onViewDetails: (estudio: EstudioRadiologico) => void;
  onEdit: (estudio: EstudioRadiologico) => void;
  onViewImages: (estudio: EstudioRadiologico) => void;
  onViewReport: (estudio: EstudioRadiologico) => void;
}

const RadiologiaTableRow = ({
  estudio,
  onViewDetails,
  onEdit,
  onViewImages,
  onViewReport
}: RadiologiaTableRowProps) => {
  return (
    <TableRow className="hover:bg-gray-50">
      <TableCell>
        <div>
          <div className="font-medium text-cyan-600">
            {estudio.pacienteNombre}
          </div>
          <div className="text-sm text-gray-500">
            Historia: {estudio.numeroHistoria}
          </div>
        </div>
      </TableCell>
      <TableCell>
        <div className="text-sm font-medium">{estudio.tipoEstudio}</div>
        {estudio.radiologo && (
          <div className="text-sm text-gray-500">
            Radiólogo: {estudio.radiologo}
          </div>
        )}
      </TableCell>
      <TableCell>
        <div>{estudio.fechaSolicitud}</div>
        {estudio.fechaRealizacion && (
          <div className="text-sm text-gray-500">
            Realizado: {estudio.fechaRealizacion}
          </div>
        )}
      </TableCell>
      <TableCell>
        <div className="text-sm">{estudio.medicoSolicitante}</div>
      </TableCell>
      <TableCell>
        {getEstadoBadge(estudio.estado)}
      </TableCell>
      <TableCell>
        {getPrioridadBadge(estudio.prioridad)}
      </TableCell>
      <TableCell>
        <div className="text-sm max-w-xs truncate">{estudio.indicacion}</div>
      </TableCell>
      <TableCell>
        <RadiologiaActionButtons
          estudio={estudio}
          onViewDetails={onViewDetails}
          onEdit={onEdit}
          onViewImages={onViewImages}
          onViewReport={onViewReport}
        />
      </TableCell>
    </TableRow>
  );
};

export default RadiologiaTableRow;
