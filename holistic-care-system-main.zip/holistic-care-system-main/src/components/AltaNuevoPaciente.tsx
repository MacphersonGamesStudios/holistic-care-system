import React, { useState, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Plus, Upload } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/hooks/use-toast";

interface AltaNuevoPacienteProps {
  onSave: (data: any) => void;
  onCancel: () => void;
  editData?: any;
}

const AltaNuevoPaciente = ({ onSave, onCancel, editData }: AltaNuevoPacienteProps) => {
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(editData?.foto || null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    numeroHistoria: editData?.numeroHistoria || '',
    nombre: editData?.nombre || '',
    primerApellido: editData?.primerApellido || editData?.apellidos?.split(' ')[0] || '',
    segundoApellido: editData?.segundoApellido || editData?.apellidos?.split(' ')[1] || '',
    tipoDocumento: editData?.tipoDocumento || 'DNI',
    numeroDocumento: editData?.dni || '',
    sexo: editData?.sexo || '',
    fechaNacimiento: editData?.fechaNacimiento || '',
    email: editData?.email || '',
    telefono1: editData?.telefono || '',
    telefono2: editData?.telefono2 || '',
    movil: editData?.movil || '',
    direccion1: editData?.direccion || '',
    direccion2: editData?.direccion2 || '',
    procedencia: editData?.procedencia || '',
    codigoPostal: editData?.codigoPostal || '',
    pais: editData?.pais || 'España',
    provincia: editData?.provincia || '',
    poblacion: editData?.poblacion || '',
    otrosDatos: editData?.otrosDatos || '',
    // Opciones
    smsWhatsapp: editData?.smsWhatsapp || false,
    mailing: editData?.mailing || false,
    gcontacts: editData?.gcontacts || false,
    generarFacturas: editData?.generarFacturas || false,
    aceptaRGPD: editData?.aceptaRGPD || false,
    portalPaciente: editData?.portalPaciente || false,
    // Tarifas
    tarifasMutuas: editData?.tarifasMutuas || '',
    tarifaPreferida: editData?.tarifaPreferida || '',
    numeroTarjetaMutua: editData?.numeroTarjetaMutua || '',
    iban: editData?.iban || '',
    formaPago: editData?.formaPago || '',
    observaciones: editData?.observaciones || '',
    alertarObservaciones: editData?.alertarObservaciones || false
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePhotoSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          setSelectedPhoto(result);
          toast({
            title: "Foto seleccionada",
            description: "Se ha cargado la foto del paciente",
          });
        };
        reader.readAsDataURL(file);
      } else {
        toast({
          title: "Error",
          description: "Por favor, seleccione un archivo de imagen válido",
          variant: "destructive",
        });
      }
    }
  };

  const generateHistoryNumber = () => {
    const newNumber = `HST${Date.now()}`;
    setFormData(prev => ({
      ...prev,
      numeroHistoria: newNumber
    }));
    
    toast({
      title: "Número generado",
      description: `Se ha generado el número de historia: ${newNumber}`,
    });
  };

  const handleSubmit = () => {
    if (!formData.nombre || !formData.primerApellido || !formData.numeroDocumento) {
      toast({
        title: "Error",
        description: "Por favor, complete los campos obligatorios (Nombre, Primer apellido, Número de documento)",
        variant: "destructive",
      });
      return;
    }

    const pacienteData = {
      ...editData,
      numeroHistoria: formData.numeroHistoria || `HST${Date.now()}`,
      nombre: formData.nombre,
      apellidos: `${formData.primerApellido} ${formData.segundoApellido}`.trim(),
      dni: formData.numeroDocumento,
      fechaNacimiento: formData.fechaNacimiento,
      sexo: formData.sexo,
      telefono: formData.telefono1,
      email: formData.email,
      direccion: formData.direccion1,
      codigoPostal: formData.codigoPostal,
      foto: selectedPhoto,
      ...formData
    };

    onSave(pacienteData);
  };

  return (
    <div className="space-y-6 max-h-[70vh] overflow-y-auto p-4">
      {/* Header with save button */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">{editData ? 'Editar paciente' : 'Alta nuevo paciente'}</h2>
        <Button onClick={handleSubmit} className="bg-cyan-600 hover:bg-cyan-700">
          {editData ? 'Actualizar' : 'Guardar'}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Patient Photo and Basic Info */}
        <div className="space-y-6">
          {/* Patient Photo */}
          <div className="flex flex-col items-center space-y-4">
            <div className="w-32 h-32 bg-gray-200 rounded-full flex items-center justify-center overflow-hidden">
              {selectedPhoto ? (
                <img src={selectedPhoto} alt="Paciente" className="w-full h-full object-cover" />
              ) : (
                <span className="text-gray-400 text-4xl">👤</span>
              )}
            </div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
            <Button variant="outline" size="sm" onClick={handlePhotoSelect}>
              <Upload className="w-4 h-4 mr-2" />
              {selectedPhoto ? 'Cambiar' : 'Elegir'}
            </Button>
          </div>

          {/* Basic Info */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="nombre">Nombre *</Label>
              <Input
                id="nombre"
                value={formData.nombre}
                onChange={(e) => handleInputChange('nombre', e.target.value)}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="primerApellido">Primer apellido *</Label>
              <Input
                id="primerApellido"
                value={formData.primerApellido}
                onChange={(e) => handleInputChange('primerApellido', e.target.value)}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="segundoApellido">Segundo apellido</Label>
              <Input
                id="segundoApellido"
                value={formData.segundoApellido}
                onChange={(e) => handleInputChange('segundoApellido', e.target.value)}
                className="mt-1"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="tipoDocumento">Tipo de documento</Label>
                <Select value={formData.tipoDocumento} onValueChange={(value) => handleInputChange('tipoDocumento', value)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DNI">DNI</SelectItem>
                    <SelectItem value="NIE">NIE</SelectItem>
                    <SelectItem value="Pasaporte">Pasaporte</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="numeroDocumento">Número de documento</Label>
                <Input
                  id="numeroDocumento"
                  value={formData.numeroDocumento}
                  onChange={(e) => handleInputChange('numeroDocumento', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label>Otros datos</Label>
              <Textarea
                value={formData.otrosDatos}
                onChange={(e) => handleInputChange('otrosDatos', e.target.value)}
                className="mt-1"
                rows={3}
              />
            </div>
          </div>
        </div>

        {/* Middle Column - Contact and Address */}
        <div className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="historia">Historia</Label>
              <div className="flex items-center gap-2 mt-1">
                <Input 
                  id="historia" 
                  value={formData.numeroHistoria}
                  onChange={(e) => handleInputChange('numeroHistoria', e.target.value)}
                  placeholder="Ingrese número de historia"
                />
                <Button size="sm" variant="outline" onClick={generateHistoryNumber}>
                  <span className="text-cyan-600">Auto</span>
                </Button>
              </div>
            </div>

            <div>
              <Label>Sexo</Label>
              <div className="flex items-center gap-4 mt-2">
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="masculino"
                    name="sexo"
                    value="masculino"
                    checked={formData.sexo === 'masculino'}
                    onChange={(e) => handleInputChange('sexo', e.target.value)}
                  />
                  <Label htmlFor="masculino">Masculino</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="femenino"
                    name="sexo"
                    value="femenino"
                    checked={formData.sexo === 'femenino'}
                    onChange={(e) => handleInputChange('sexo', e.target.value)}
                  />
                  <Label htmlFor="femenino">Femenino</Label>
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="fechaNacimiento">Fecha de nacimiento</Label>
              <div className="flex items-center gap-2 mt-1">
                <Input
                  id="fechaNacimiento"
                  type="date"
                  value={formData.fechaNacimiento}
                  onChange={(e) => handleInputChange('fechaNacimiento', e.target.value)}
                />
                <Calendar className="h-4 w-4 text-gray-400" />
              </div>
            </div>

            <div>
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className="mt-1"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <Label htmlFor="telefono1">Teléfono 1</Label>
                <Input
                  id="telefono1"
                  value={formData.telefono1}
                  onChange={(e) => handleInputChange('telefono1', e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="telefono2">Teléfono 2</Label>
                <Input
                  id="telefono2"
                  value={formData.telefono2}
                  onChange={(e) => handleInputChange('telefono2', e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="movil">Móvil</Label>
                <Input
                  id="movil"
                  value={formData.movil}
                  onChange={(e) => handleInputChange('movil', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="direccion1">Dirección 1</Label>
              <Input
                id="direccion1"
                value={formData.direccion1}
                onChange={(e) => handleInputChange('direccion1', e.target.value)}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="direccion2">Dirección 2</Label>
              <Input
                id="direccion2"
                value={formData.direccion2}
                onChange={(e) => handleInputChange('direccion2', e.target.value)}
                className="mt-1"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="procedencia">Procedencia</Label>
                <div className="flex items-center gap-2 mt-1">
                  <Select value={formData.procedencia} onValueChange={(value) => handleInputChange('procedencia', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="particular">Particular</SelectItem>
                      <SelectItem value="seguro">Seguro</SelectItem>
                      <SelectItem value="mutua">Mutua</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button size="sm" variant="outline">
                    <Plus size={16} />
                  </Button>
                </div>
              </div>
              <div>
                <Label htmlFor="codigoPostal">C.P.</Label>
                <Input
                  id="codigoPostal"
                  value={formData.codigoPostal}
                  onChange={(e) => handleInputChange('codigoPostal', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="pais">País</Label>
              <Select value={formData.pais} onValueChange={(value) => handleInputChange('pais', value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="España">España</SelectItem>
                  <SelectItem value="Francia">Francia</SelectItem>
                  <SelectItem value="Portugal">Portugal</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="provincia">Provincia</Label>
              <Select value={formData.provincia} onValueChange={(value) => handleInputChange('provincia', value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Seleccionar provincia" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="madrid">Madrid</SelectItem>
                  <SelectItem value="barcelona">Barcelona</SelectItem>
                  <SelectItem value="valencia">Valencia</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="poblacion">Población</Label>
              <Select value={formData.poblacion} onValueChange={(value) => handleInputChange('poblacion', value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Seleccionar población" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="madrid">Madrid</SelectItem>
                  <SelectItem value="barcelona">Barcelona</SelectItem>
                  <SelectItem value="valencia">Valencia</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Right Column - Options and Billing */}
        <div className="space-y-6">
          <div>
            <Label className="text-base font-semibold">Opciones</Label>
            <div className="space-y-3 mt-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="sms-whatsapp"
                  checked={formData.smsWhatsapp}
                  onCheckedChange={(checked) => handleInputChange('smsWhatsapp', checked)}
                />
                <Label htmlFor="sms-whatsapp">SMS/WhatsApp</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="mailing"
                  checked={formData.mailing}
                  onCheckedChange={(checked) => handleInputChange('mailing', checked)}
                />
                <Label htmlFor="mailing">Mailing</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="gcontacts"
                  checked={formData.gcontacts}
                  onCheckedChange={(checked) => handleInputChange('gcontacts', checked)}
                />
                <Label htmlFor="gcontacts">Gcontacts</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="generar-facturas"
                  checked={formData.generarFacturas}
                  onCheckedChange={(checked) => handleInputChange('generarFacturas', checked)}
                />
                <Label htmlFor="generar-facturas">Generar facturas</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="acepta-rgpd"
                  checked={formData.aceptaRGPD}
                  onCheckedChange={(checked) => handleInputChange('aceptaRGPD', checked)}
                />
                <Label htmlFor="acepta-rgpd">Acepta RGPD</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="portal-paciente"
                  checked={formData.portalPaciente}
                  onCheckedChange={(checked) => handleInputChange('portalPaciente', checked)}
                />
                <Label htmlFor="portal-paciente">Portal del Paciente</Label>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <Label htmlFor="tarifas-mutuas">Tarifas/Mutuas</Label>
              <Input
                id="tarifas-mutuas"
                placeholder="busca tarifa/mutua"
                value={formData.tarifasMutuas}
                onChange={(e) => handleInputChange('tarifasMutuas', e.target.value)}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="tarifa-preferida">Tarifa/mutua preferida</Label>
              <Select value={formData.tarifaPreferida} onValueChange={(value) => handleInputChange('tarifaPreferida', value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="busca tarifa/mutua" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="particular">Particular</SelectItem>
                  <SelectItem value="sanitas">Sanitas</SelectItem>
                  <SelectItem value="adeslas">Adeslas</SelectItem>
                </SelectContent>
              </Select>
              <div className="mt-2">
                <Label htmlFor="numero-tarjeta">Número tarjeta de mutua</Label>
                <Input
                  id="numero-tarjeta"
                  value={formData.numeroTarjetaMutua}
                  onChange={(e) => handleInputChange('numeroTarjetaMutua', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="iban">IBAN</Label>
              <Input
                id="iban"
                value={formData.iban}
                onChange={(e) => handleInputChange('iban', e.target.value)}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="forma-pago">Forma de Pago</Label>
              <Select value={formData.formaPago} onValueChange={(value) => handleInputChange('formaPago', value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Seleccionar forma de pago" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="efectivo">Efectivo</SelectItem>
                  <SelectItem value="tarjeta">Tarjeta</SelectItem>
                  <SelectItem value="transferencia">Transferencia</SelectItem>
                  <SelectItem value="domiciliacion">Domiciliación</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="observaciones">Observaciones</Label>
              <Textarea
                id="observaciones"
                value={formData.observaciones}
                onChange={(e) => handleInputChange('observaciones', e.target.value)}
                className="mt-1"
                rows={4}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="alertar-observaciones"
                checked={formData.alertarObservaciones}
                onCheckedChange={(checked) => handleInputChange('alertarObservaciones', checked)}
              />
              <Label htmlFor="alertar-observaciones">
                Alertar de las observaciones del paciente
              </Label>
            </div>
          </div>
        </div>
      </div>

      {/* Footer buttons */}
      <div className="flex justify-end gap-2 pt-4 border-t">
        <Button variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button onClick={handleSubmit} className="bg-cyan-600 hover:bg-cyan-700">
          {editData ? 'Actualizar' : 'Guardar'}
        </Button>
      </div>
    </div>
  );
};

export default AltaNuevoPaciente;
