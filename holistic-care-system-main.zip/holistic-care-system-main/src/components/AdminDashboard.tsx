
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ModuleCard from './ModuleCard';
import { Card, CardContent } from "@/components/ui/card";
import { 
  Shield, 
  Users, 
  Building, 
  UserCheck,
  Key,
  UserCog
} from 'lucide-react';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [expandedCard, setExpandedCard] = useState<string | null>(null);

  const adminModules = [
    {
      id: "licencias",
      title: "Licencias",
      icon: Shield,
      color: "bg-gradient-to-br from-green-500 to-green-600",
      path: "/admin/licencias",
      submenu: [
        { name: "Licencias", path: "/admin/licencias" },
        { name: "Mis facturas", path: "/admin/mis-facturas" },
        { name: "Perfil del cliente", path: "/admin/perfil-cliente" },
        { name: "Backup General", path: "/admin/backup-general" },
        { name: "Backup Personal", path: "/admin/backup-personal" },
        { name: "Auditoría", path: "/admin/auditoria" }
      ]
    },
    {
      id: "perfil-cliente",
      title: "Perfil del cliente",
      icon: UserCheck,
      color: "bg-gradient-to-br from-purple-500 to-purple-600",
      path: "/admin/perfil-cliente",
      submenu: []
    },
    {
      id: "centros",
      title: "Centros",
      icon: Building,
      color: "bg-gradient-to-br from-gray-500 to-gray-600",
      path: "/admin/centros",
      submenu: []
    },
    {
      id: "perfil-usuario",
      title: "Perfil del usuario",
      icon: UserCog,
      color: "bg-gradient-to-br from-orange-500 to-orange-600",
      path: "/admin/perfil-usuario",
      submenu: []
    },
    {
      id: "usuarios",
      title: "Usuarios",
      icon: Users,
      color: "bg-gradient-to-br from-blue-500 to-blue-600",
      path: "/admin/usuarios",
      submenu: [
        { name: "Usuarios", path: "/admin/usuarios" },
        { name: "Perfil del usuario", path: "/admin/perfil-usuario" },
        { name: "Roles", path: "/admin/roles" },
        { name: "Permisos del usuario", path: "/admin/permisos-del-usuario" },
        { name: "Relaciones confianza", path: "/admin/relaciones-confianza" }
      ]
    },
    {
      id: "roles",
      title: "Roles",
      icon: Key,
      color: "bg-gradient-to-br from-purple-600 to-purple-700",
      path: "/admin/roles",
      submenu: []
    }
  ];

  const handleCardClick = (module: any) => {
    if (module.submenu && module.submenu.length > 0) {
      setExpandedCard(expandedCard === module.id ? null : module.id);
    } else {
      navigate(module.path);
    }
  };

  const handleSubmenuClick = (submenuItem: any) => {
    navigate(submenuItem.path);
    setExpandedCard(null);
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-800">Administrador</h1>
        <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
          <span className="text-gray-600 text-sm">?</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {adminModules.map((module) => (
          <div key={module.id} className="relative">
            <ModuleCard
              title={module.title}
              icon={module.icon}
              color={module.color}
              onClick={() => handleCardClick(module)}
            />
            
            {expandedCard === module.id && module.submenu && module.submenu.length > 0 && (
              <Card className="absolute top-full left-0 w-full mt-2 z-50 bg-white shadow-lg border">
                <CardContent className="p-2">
                  {module.submenu.map((item, index) => (
                    <button
                      key={index}
                      onClick={() => handleSubmenuClick(item)}
                      className="w-full text-left px-3 py-2 text-sm hover:bg-gray-100 rounded transition-colors"
                    >
                      {item.name}
                    </button>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminDashboard;
