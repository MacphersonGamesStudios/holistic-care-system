
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Bell, HelpCircle, Settings, User, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

const Header = () => {
  const navigate = useNavigate();
  const [user] = useState(() => {
    const savedUser = localStorage.getItem('hospitalUser');
    return savedUser ? JSON.parse(savedUser) : { username: 'Usuario', hospital: 'Hospital Macpherson' };
  });

  const handleLogout = () => {
    localStorage.removeItem('hospitalUser');
    navigate('/');
  };

  return (
    <header className="bg-cyan-600 text-white h-16 flex items-center justify-between px-6 fixed top-0 left-16 right-0 z-40">
      <h1 className="text-xl font-semibold">{user.hospital}</h1>

      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" className="text-white hover:bg-cyan-500">
          <HelpCircle size={20} />
        </Button>
        
        <Button variant="ghost" size="icon" className="text-white hover:bg-cyan-500">
          <Bell size={20} />
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="text-white hover:bg-cyan-500 flex items-center gap-2 h-10">
              <Avatar className="w-8 h-8">
                <AvatarFallback className="bg-white text-cyan-600 text-sm">
                  {user.username.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col items-start text-sm">
                <span>{user.hospital}</span>
                <span className="text-xs text-cyan-100">ADMINISTRADOR</span>
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56 bg-white border shadow-lg">
            <DropdownMenuItem className="flex items-center gap-2 text-gray-700">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              ADMINISTRADOR
            </DropdownMenuItem>
            <DropdownMenuItem className="flex items-center gap-2 text-gray-700">
              <User size={16} />
              DOCUMENTOS DEL USUARIO
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              onClick={handleLogout}
              className="flex items-center gap-2 text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <LogOut size={16} />
              CERRAR SESIÓN
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};

export default Header;
