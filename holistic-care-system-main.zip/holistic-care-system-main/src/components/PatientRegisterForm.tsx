
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, User } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";

const PatientRegisterForm = () => {
  const [formData, setFormData] = useState({
    nombre: '',
    apellidos: '',
    dni: '',
    fechaNacimiento: '',
    sexo: '',
    telefono: '',
    email: '',
    password: '',
    confirmPassword: '',
    direccion: '',
    ciudad: '',
    codigoPostal: '',
    seguroMedico: '',
    numeroSeguro: '',
    contactoEmergencia: '',
    telefonoEmergencia: '',
    alergias: '',
    medicamentos: '',
    enfermedadesPrevias: ''
  });
  
  const navigate = useNavigate();

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validaciones básicas
    if (!formData.nombre || !formData.apellidos || !formData.dni || !formData.fechaNacimiento || !formData.email || !formData.password) {
      toast({
        title: "Error de registro",
        description: "Por favor, complete todos los campos obligatorios",
        variant: "destructive",
      });
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Error de registro",
        description: "Las contraseñas no coinciden",
        variant: "destructive",
      });
      return;
    }

    if (formData.password.length < 6) {
      toast({
        title: "Error de registro",
        description: "La contraseña debe tener al menos 6 caracteres",
        variant: "destructive",
      });
      return;
    }

    // Verificar si el DNI o email ya existe
    const existingPatients = JSON.parse(localStorage.getItem('hospitalPatients') || '[]');
    if (existingPatients.find((patient: any) => patient.dni === formData.dni)) {
      toast({
        title: "Error de registro",
        description: "Ya existe un paciente con este DNI",
        variant: "destructive",
      });
      return;
    }

    if (existingPatients.find((patient: any) => patient.email === formData.email)) {
      toast({
        title: "Error de registro",
        description: "Ya existe un paciente con este email",
        variant: "destructive",
      });
      return;
    }

    // Crear nuevo paciente
    const newPatient = {
      id: Date.now().toString(),
      numeroHistoria: `HST${Date.now()}`,
      ...formData,
      fechaRegistro: new Date().toISOString(),
      activo: true
    };

    // Guardar en localStorage
    const updatedPatients = [...existingPatients, newPatient];
    localStorage.setItem('hospitalPatients', JSON.stringify(updatedPatients));

    toast({
      title: "Registro exitoso",
      description: `Paciente ${formData.nombre} ${formData.apellidos} registrado correctamente`,
    });

    // Redirigir al login de pacientes
    navigate('/patient-login');
  };

  return (
    <div className="min-h-screen hospital-gradient flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl bg-white/95 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => navigate('/')}
              className="text-cyan-600 hover:bg-cyan-50"
            >
              <ArrowLeft size={20} />
            </Button>
            <div className="bg-cyan-600 text-white px-4 py-2 rounded-md inline-flex items-center gap-2">
              <span className="font-bold">DASI</span>
              <span className="bg-white text-cyan-600 px-2 py-1 rounded text-sm font-semibold">eCLINIC</span>
            </div>
          </div>
          <CardTitle className="text-2xl text-center text-gray-800 flex items-center justify-center gap-2">
            <User className="text-cyan-600" />
            Registro de Paciente
          </CardTitle>
        </CardHeader>

        <CardContent className="p-8">
          <form onSubmit={handleRegister} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="nombre">Nombre *</Label>
                <Input
                  id="nombre"
                  type="text"
                  value={formData.nombre}
                  onChange={(e) => handleInputChange('nombre', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="apellidos">Apellidos *</Label>
                <Input
                  id="apellidos"
                  type="text"
                  value={formData.apellidos}
                  onChange={(e) => handleInputChange('apellidos', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="dni">DNI/NIE *</Label>
                <Input
                  id="dni"
                  type="text"
                  value={formData.dni}
                  onChange={(e) => handleInputChange('dni', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="fechaNacimiento">Fecha de Nacimiento *</Label>
                <Input
                  id="fechaNacimiento"
                  type="date"
                  value={formData.fechaNacimiento}
                  onChange={(e) => handleInputChange('fechaNacimiento', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="sexo">Sexo</Label>
                <Select value={formData.sexo} onValueChange={(value) => handleInputChange('sexo', value)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Seleccionar" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="masculino">Masculino</SelectItem>
                    <SelectItem value="femenino">Femenino</SelectItem>
                    <SelectItem value="otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="telefono">Teléfono</Label>
                <Input
                  id="telefono"
                  type="tel"
                  value={formData.telefono}
                  onChange={(e) => handleInputChange('telefono', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="direccion">Dirección</Label>
                <Input
                  id="direccion"
                  type="text"
                  value={formData.direccion}
                  onChange={(e) => handleInputChange('direccion', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="password">Contraseña *</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  className="mt-1"
                  placeholder="Mínimo 6 caracteres"
                />
              </div>

              <div>
                <Label htmlFor="confirmPassword">Confirmar Contraseña *</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="ciudad">Ciudad</Label>
                <Input
                  id="ciudad"
                  type="text"
                  value={formData.ciudad}
                  onChange={(e) => handleInputChange('ciudad', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="codigoPostal">Código Postal</Label>
                <Input
                  id="codigoPostal"
                  type="text"
                  value={formData.codigoPostal}
                  onChange={(e) => handleInputChange('codigoPostal', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="seguroMedico">Seguro Médico</Label>
                <Input
                  id="seguroMedico"
                  type="text"
                  value={formData.seguroMedico}
                  onChange={(e) => handleInputChange('seguroMedico', e.target.value)}
                  className="mt-1"
                  placeholder="Ej: Sanitas, Adeslas..."
                />
              </div>

              <div>
                <Label htmlFor="numeroSeguro">Número de Seguro</Label>
                <Input
                  id="numeroSeguro"
                  type="text"
                  value={formData.numeroSeguro}
                  onChange={(e) => handleInputChange('numeroSeguro', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="contactoEmergencia">Contacto de Emergencia</Label>
                <Input
                  id="contactoEmergencia"
                  type="text"
                  value={formData.contactoEmergencia}
                  onChange={(e) => handleInputChange('contactoEmergencia', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="telefonoEmergencia">Teléfono de Emergencia</Label>
                <Input
                  id="telefonoEmergencia"
                  type="tel"
                  value={formData.telefonoEmergencia}
                  onChange={(e) => handleInputChange('telefonoEmergencia', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="alergias">Alergias</Label>
                <Textarea
                  id="alergias"
                  value={formData.alergias}
                  onChange={(e) => handleInputChange('alergias', e.target.value)}
                  className="mt-1"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="medicamentos">Medicamentos Actuales</Label>
                <Textarea
                  id="medicamentos"
                  value={formData.medicamentos}
                  onChange={(e) => handleInputChange('medicamentos', e.target.value)}
                  className="mt-1"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="enfermedadesPrevias">Enfermedades Previas</Label>
                <Textarea
                  id="enfermedadesPrevias"
                  value={formData.enfermedadesPrevias}
                  onChange={(e) => handleInputChange('enfermedadesPrevias', e.target.value)}
                  className="mt-1"
                  rows={3}
                />
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 bg-green-600 hover:bg-green-700 text-white font-semibold text-base"
            >
              Registrar Paciente
            </Button>

            <div className="text-center">
              <Button
                type="button"
                variant="link"
                onClick={() => navigate('/patient-login')}
                className="text-green-600 hover:text-green-700"
              >
                ¿Ya tienes cuenta? Inicia sesión
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default PatientRegisterForm;
