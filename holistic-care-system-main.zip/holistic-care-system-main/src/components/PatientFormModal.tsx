
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import AltaNuevoPaciente from './AltaNuevoPaciente';

interface Paciente {
  id: string;
  numeroHistoria: string;
  nombre: string;
  apellidos: string;
  dni: string;
  fechaNacimiento: string;
  sexo: string;
  telefono: string;
  email: string;
  fechaAlta: string;
  activo: boolean;
  foto?: string;
  direccion?: string;
  codigoPostal?: string;
  provincia?: string;
  poblacion?: string;
  observaciones?: string;
}

interface PatientFormModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: any) => void;
  onCancel: () => void;
  editData?: Paciente | null;
  title: string;
}

const PatientFormModal = ({
  open,
  onOpenChange,
  onSave,
  onCancel,
  editData,
  title
}: PatientFormModalProps) => {
  const handleSave = (data: any) => {
    onSave(data);
    onOpenChange(false);
  };

  const handleCancel = () => {
    onCancel();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <AltaNuevoPaciente 
          onSave={handleSave} 
          onCancel={handleCancel}
          editData={editData}
        />
      </DialogContent>
    </Dialog>
  );
};

export default PatientFormModal;
