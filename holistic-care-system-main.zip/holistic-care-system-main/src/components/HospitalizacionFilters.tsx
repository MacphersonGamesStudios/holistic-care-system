
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";

interface HospitalizacionFiltersProps {
  searchTerm: string;
  selectedEstado: string;
  selectedHabitacion: string;
  onSearchChange: (value: string) => void;
  onEstadoChange: (value: string) => void;
  onHabitacionChange: (value: string) => void;
  onClearFilters: () => void;
}

const HospitalizacionFilters = ({
  searchTerm,
  selectedEstado,
  selectedHabitacion,
  onSearchChange,
  onEstadoChange,
  onHabitacionChange,
  onClearFilters
}: HospitalizacionFiltersProps) => {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <Label htmlFor="buscar">Buscar</Label>
            <div className="relative mt-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                id="buscar"
                placeholder="Buscar por paciente, historia, habitación..."
                value={searchTerm}
                onChange={(e) => onSearchChange(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="estado">Estado</Label>
            <Select value={selectedEstado} onValueChange={onEstadoChange}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                <SelectItem value="ingresado">Ingresados</SelectItem>
                <SelectItem value="alta">Dados de alta</SelectItem>
                <SelectItem value="transferido">Transferidos</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="habitacion">Habitación</Label>
            <Select value={selectedHabitacion} onValueChange={onHabitacionChange}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Todas las habitaciones" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas</SelectItem>
                <SelectItem value="101">101</SelectItem>
                <SelectItem value="102">102</SelectItem>
                <SelectItem value="103">103</SelectItem>
                <SelectItem value="201">201</SelectItem>
                <SelectItem value="202">202</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-end">
            <Button 
              variant="outline" 
              className="w-full"
              onClick={onClearFilters}
            >
              Limpiar filtros
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default HospitalizacionFilters;
