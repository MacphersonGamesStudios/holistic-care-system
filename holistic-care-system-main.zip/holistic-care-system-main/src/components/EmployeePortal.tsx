
import React from 'react';
import { useNavigate } from 'react-router-dom';
import ModuleCard from './ModuleCard';
import { 
  Users, 
  Calendar, 
  FileText, 
  Clock,
  MessageSquare,
  Settings,
  BarChart3,
  Briefcase
} from 'lucide-react';

const EmployeePortal = () => {
  const navigate = useNavigate();

  const employeeModules = [
    {
      title: "Mi Horario",
      icon: Clock,
      color: "bg-gradient-to-br from-blue-500 to-blue-600",
      path: "/employee/horario"
    },
    {
      title: "Mis Pacientes",
      icon: Users,
      color: "bg-gradient-to-br from-green-500 to-green-600",
      path: "/employee/pacientes"
    },
    {
      title: "Agenda Personal",
      icon: Calendar,
      color: "bg-gradient-to-br from-purple-500 to-purple-600",
      path: "/employee/agenda"
    },
    {
      title: "Documentos",
      icon: FileText,
      color: "bg-gradient-to-br from-orange-500 to-orange-600",
      path: "/employee/documentos"
    },
    {
      title: "Comunicaciones",
      icon: MessageSquare,
      color: "bg-gradient-to-br from-pink-500 to-pink-600",
      path: "/employee/comunicaciones"
    },
    {
      title: "Reportes",
      icon: BarChart3,
      color: "bg-gradient-to-br from-indigo-500 to-indigo-600",
      path: "/employee/reportes"
    },
    {
      title: "Mi Perfil",
      icon: Settings,
      color: "bg-gradient-to-br from-gray-500 to-gray-600",
      path: "/employee/perfil"
    },
    {
      title: "Recursos",
      icon: Briefcase,
      color: "bg-gradient-to-br from-teal-500 to-teal-600",
      path: "/employee/recursos"
    }
  ];

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-800">Portal del Empleado</h1>
        <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
          <span className="text-gray-600 text-sm">?</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {employeeModules.map((module, index) => (
          <ModuleCard
            key={index}
            title={module.title}
            icon={module.icon}
            color={module.color}
            onClick={() => navigate(module.path)}
          />
        ))}
      </div>
    </div>
  );
};

export default EmployeePortal;
