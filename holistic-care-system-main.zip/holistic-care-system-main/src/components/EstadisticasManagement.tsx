
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { BarChart3, Download, Filter, Calendar, Users, Activity, TrendingUp } from "lucide-react";

const EstadisticasManagement = () => {
  const [tipoReporte, setTipoReporte] = useState('pacientes');
  const [periodoTiempo, setPeriodoTiempo] = useState('mes');

  // Datos de ejemplo para los gráficos
  const dataPacientes = [
    { mes: 'Ene', nuevos: 12, consultas: 45 },
    { mes: 'Feb', nuevos: 15, consultas: 52 },
    { mes: 'Mar', nuevos: 8, consultas: 38 },
    { mes: 'Abr', nuevos: 18, consultas: 64 },
    { mes: 'May', nuevos: 22, consultas: 71 }
  ];

  const dataEspecialidades = [
    { name: 'Medicina General', value: 45, color: '#0088FE' },
    { name: 'Cardiología', value: 25, color: '#00C49F' },
    { name: 'Pediatría', value: 20, color: '#FFBB28' },
    { name: 'Dermatología', value: 10, color: '#FF8042' }
  ];

  const dataIngresos = [
    { mes: 'Ene', ingresos: 12500 },
    { mes: 'Feb', ingresos: 15200 },
    { mes: 'Mar', ingresos: 11800 },
    { mes: 'Abr', ingresos: 18400 },
    { mes: 'May', ingresos: 21300 }
  ];

  const reportesDisponibles = [
    { id: 'pacientes-mes', nombre: 'Pacientes por mes', tipo: 'pacientes' },
    { id: 'consultas-especialidad', nombre: 'Consultas por especialidad', tipo: 'consultas' },
    { id: 'ingresos-periodo', nombre: 'Ingresos por período', tipo: 'ingresos' },
    { id: 'medicamentos-vendidos', nombre: 'Medicamentos más vendidos', tipo: 'farmacia' },
    { id: 'estudios-radiologicos', nombre: 'Estudios radiológicos', tipo: 'radiologia' }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Breadcrumb */}
      <div className="text-sm text-gray-600 mb-4">
        <span className="text-cyan-600">Gestión médica</span> / <span>Listados Estadísticos</span>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Listados Estadísticos</h1>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Download size={16} className="mr-1" />
            Exportar PDF
          </Button>
          <Button variant="outline" size="sm">
            <Download size={16} className="mr-1" />
            Exportar Excel
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Tipo de Reporte</label>
              <Select value={tipoReporte} onValueChange={setTipoReporte}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pacientes">Pacientes</SelectItem>
                  <SelectItem value="consultas">Consultas</SelectItem>
                  <SelectItem value="ingresos">Ingresos</SelectItem>
                  <SelectItem value="farmacia">Farmacia</SelectItem>
                  <SelectItem value="radiologia">Radiología</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Período</label>
              <Select value={periodoTiempo} onValueChange={setPeriodoTiempo}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="semana">Esta semana</SelectItem>
                  <SelectItem value="mes">Este mes</SelectItem>
                  <SelectItem value="trimestre">Este trimestre</SelectItem>
                  <SelectItem value="año">Este año</SelectItem>
                  <SelectItem value="personalizado">Personalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Fecha Inicio</label>
              <Input type="date" />
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Fecha Fin</label>
              <Input type="date" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="text-blue-600" size={20} />
              <div>
                <div className="text-2xl font-bold text-blue-600">156</div>
                <div className="text-sm text-gray-600">Total Pacientes</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Activity className="text-green-600" size={20} />
              <div>
                <div className="text-2xl font-bold text-green-600">342</div>
                <div className="text-sm text-gray-600">Consultas Mes</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="text-purple-600" size={20} />
              <div>
                <div className="text-2xl font-bold text-purple-600">€21,300</div>
                <div className="text-sm text-gray-600">Ingresos Mes</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="text-orange-600" size={20} />
              <div>
                <div className="text-2xl font-bold text-orange-600">94%</div>
                <div className="text-sm text-gray-600">Satisfacción</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pacientes y Consultas por Mes */}
        <Card>
          <CardHeader>
            <CardTitle>Pacientes y Consultas por Mes</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={dataPacientes}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="mes" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="nuevos" fill="#0ea5e9" name="Nuevos Pacientes" />
                <Bar dataKey="consultas" fill="#06b6d4" name="Consultas" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Distribución por Especialidades */}
        <Card>
          <CardHeader>
            <CardTitle>Distribución por Especialidades</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={dataEspecialidades}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {dataEspecialidades.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Ingresos Mensuales */}
      <Card>
        <CardHeader>
          <CardTitle>Evolución de Ingresos</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={dataIngresos}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="mes" />
              <YAxis />
              <Tooltip formatter={(value) => [`€${value}`, 'Ingresos']} />
              <Line type="monotone" dataKey="ingresos" stroke="#10b981" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Available Reports Table */}
      <Card>
        <CardHeader>
          <CardTitle>Reportes Disponibles</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-cyan-600 hover:bg-cyan-600">
                <TableHead className="text-white font-semibold">Nombre del Reporte</TableHead>
                <TableHead className="text-white font-semibold">Tipo</TableHead>
                <TableHead className="text-white font-semibold">Última Actualización</TableHead>
                <TableHead className="text-white font-semibold">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reportesDisponibles.map((reporte) => (
                <TableRow key={reporte.id} className="hover:bg-gray-50">
                  <TableCell className="font-medium">{reporte.nombre}</TableCell>
                  <TableCell>
                    <span className="capitalize bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                      {reporte.tipo}
                    </span>
                  </TableCell>
                  <TableCell>Hoy, 10:30</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <BarChart3 size={16} className="mr-1" />
                        Ver
                      </Button>
                      <Button size="sm" variant="outline">
                        <Download size={16} className="mr-1" />
                        Descargar
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default EstadisticasManagement;
