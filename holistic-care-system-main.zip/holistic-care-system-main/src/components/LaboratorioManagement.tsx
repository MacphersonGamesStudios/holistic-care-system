
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, TestTube, Clock, CheckCircle, AlertCircle, Eye, Edit, FileText } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface AnalisisLaboratorio {
  id: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  tipoAnalisis: string;
  fechaSolicitud: string;
  fechaExtraccion?: string;
  fechaResultado?: string;
  medicoSolicitante: string;
  estado: 'solicitado' | 'muestra_extraida' | 'en_proceso' | 'completado' | 'informado';
  prioridad: 'baja' | 'normal' | 'alta' | 'urgente';
  observaciones?: string;
  resultados?: string;
}

const LaboratorioManagement = () => {
  const [analisis, setAnalisis] = useState<AnalisisLaboratorio[]>([]);
  const [filteredAnalisis, setFilteredAnalisis] = useState<AnalisisLaboratorio[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [estadoFilter, setEstadoFilter] = useState('todos');
  const [prioridadFilter, setPrioridadFilter] = useState('todas');

  useEffect(() => {
    // Datos de ejemplo
    const analisisEjemplo: AnalisisLaboratorio[] = [
      {
        id: '1',
        pacienteId: 'PAC001',
        pacienteNombre: 'García López, Juan Carlos',
        numeroHistoria: 'HST001',
        tipoAnalisis: 'Hemograma completo',
        fechaSolicitud: '2024-05-26',
        fechaExtraccion: '2024-05-26',
        medicoSolicitante: 'Dr. Martínez',
        estado: 'en_proceso',
        prioridad: 'normal',
        observaciones: 'Paciente en ayunas'
      },
      {
        id: '2',
        pacienteId: 'PAC002',
        pacienteNombre: 'Rodríguez Pérez, María Isabel',
        numeroHistoria: 'HST002',
        tipoAnalisis: 'Bioquímica básica',
        fechaSolicitud: '2024-05-25',
        fechaExtraccion: '2024-05-25',
        fechaResultado: '2024-05-26',
        medicoSolicitante: 'Dra. González',
        estado: 'completado',
        prioridad: 'alta',
        observaciones: 'Control diabético',
        resultados: 'Glucosa: 120 mg/dl, Colesterol: 180 mg/dl'
      },
      {
        id: '3',
        pacienteId: 'PAC003',
        pacienteNombre: 'Fernández López, Ana María',
        numeroHistoria: 'HST003',
        tipoAnalisis: 'Perfil tiroideo',
        fechaSolicitud: '2024-05-26',
        medicoSolicitante: 'Dr. Ruiz',
        estado: 'solicitado',
        prioridad: 'urgente',
        observaciones: 'Sospecha hipertiroidismo'
      }
    ];
    setAnalisis(analisisEjemplo);
    setFilteredAnalisis(analisisEjemplo);
  }, []);

  useEffect(() => {
    let filtered = analisis;

    // Filtrar por búsqueda
    if (searchTerm) {
      filtered = filtered.filter(a => 
        a.pacienteNombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
        a.numeroHistoria.toLowerCase().includes(searchTerm.toLowerCase()) ||
        a.tipoAnalisis.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filtrar por estado
    if (estadoFilter !== 'todos') {
      filtered = filtered.filter(a => a.estado === estadoFilter);
    }

    // Filtrar por prioridad
    if (prioridadFilter !== 'todas') {
      filtered = filtered.filter(a => a.prioridad === prioridadFilter);
    }

    setFilteredAnalisis(filtered);
  }, [analisis, searchTerm, estadoFilter, prioridadFilter]);

  const getEstadoBadge = (estado: string) => {
    switch (estado) {
      case 'solicitado':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Solicitado</Badge>;
      case 'muestra_extraida':
        return <Badge variant="default" className="bg-orange-100 text-orange-800">Muestra Extraída</Badge>;
      case 'en_proceso':
        return <Badge variant="default" className="bg-yellow-100 text-yellow-800">En Proceso</Badge>;
      case 'completado':
        return <Badge variant="secondary" className="bg-green-100 text-green-800">Completado</Badge>;
      case 'informado':
        return <Badge variant="default" className="bg-cyan-100 text-cyan-800">Informado</Badge>;
      default:
        return <Badge variant="secondary">{estado}</Badge>;
    }
  };

  const getPrioridadBadge = (prioridad: string) => {
    switch (prioridad) {
      case 'urgente':
        return <Badge variant="destructive">Urgente</Badge>;
      case 'alta':
        return <Badge variant="default" className="bg-orange-100 text-orange-800">Alta</Badge>;
      case 'normal':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Normal</Badge>;
      case 'baja':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-800">Baja</Badge>;
      default:
        return <Badge variant="secondary">{prioridad}</Badge>;
    }
  };

  const analisisSolicitados = analisis.filter(a => a.estado === 'solicitado').length;
  const analisisEnProceso = analisis.filter(a => a.estado === 'en_proceso').length;
  const analisisCompletados = analisis.filter(a => a.estado === 'completado').length;
  const analisisUrgentes = analisis.filter(a => a.prioridad === 'urgente').length;

  return (
    <div className="p-6 space-y-6">
      {/* Breadcrumb */}
      <div className="text-sm text-gray-600 mb-4">
        <span className="text-cyan-600">Gestión médica</span> / <span>Laboratorio</span>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Laboratorio</h1>
          <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
            <Plus size={16} />
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="text-blue-600" size={20} />
              <div>
                <div className="text-2xl font-bold text-blue-600">{analisisSolicitados}</div>
                <div className="text-sm text-gray-600">Solicitados</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TestTube className="text-orange-600" size={20} />
              <div>
                <div className="text-2xl font-bold text-orange-600">{analisisEnProceso}</div>
                <div className="text-sm text-gray-600">En Proceso</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="text-green-600" size={20} />
              <div>
                <div className="text-2xl font-bold text-green-600">{analisisCompletados}</div>
                <div className="text-sm text-gray-600">Completados</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="text-red-600" size={20} />
              <div>
                <div className="text-2xl font-bold text-red-600">{analisisUrgentes}</div>
                <div className="text-sm text-gray-600">Urgentes</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Buscar</label>
              <div className="relative">
                <Input
                  placeholder="Buscar por paciente, historia, análisis..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Estado</label>
              <Select value={estadoFilter} onValueChange={setEstadoFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos los estados</SelectItem>
                  <SelectItem value="solicitado">Solicitado</SelectItem>
                  <SelectItem value="muestra_extraida">Muestra Extraída</SelectItem>
                  <SelectItem value="en_proceso">En Proceso</SelectItem>
                  <SelectItem value="completado">Completado</SelectItem>
                  <SelectItem value="informado">Informado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Prioridad</label>
              <Select value={prioridadFilter} onValueChange={setPrioridadFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todas">Todas las prioridades</SelectItem>
                  <SelectItem value="urgente">Urgente</SelectItem>
                  <SelectItem value="alta">Alta</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="baja">Baja</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button className="w-full bg-cyan-600 hover:bg-cyan-700">
                <TestTube size={16} className="mr-1" />
                Nuevo Análisis
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Laboratory Analysis Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-cyan-600 hover:bg-cyan-600">
                <TableHead className="text-white font-semibold">Paciente</TableHead>
                <TableHead className="text-white font-semibold">Análisis</TableHead>
                <TableHead className="text-white font-semibold">Médico</TableHead>
                <TableHead className="text-white font-semibold">Fechas</TableHead>
                <TableHead className="text-white font-semibold">Estado</TableHead>
                <TableHead className="text-white font-semibold">Prioridad</TableHead>
                <TableHead className="text-white font-semibold">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAnalisis.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                    No se encontraron análisis de laboratorio
                  </TableCell>
                </TableRow>
              ) : (
                filteredAnalisis.map((analisis) => (
                  <TableRow key={analisis.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div>
                        <div className="font-medium text-cyan-600">{analisis.pacienteNombre}</div>
                        <div className="text-sm text-gray-600">Historia: {analisis.numeroHistoria}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{analisis.tipoAnalisis}</div>
                        {analisis.observaciones && (
                          <div className="text-sm text-gray-600">{analisis.observaciones}</div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{analisis.medicoSolicitante}</TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>Sol: {analisis.fechaSolicitud}</div>
                        {analisis.fechaExtraccion && (
                          <div>Ext: {analisis.fechaExtraccion}</div>
                        )}
                        {analisis.fechaResultado && (
                          <div>Res: {analisis.fechaResultado}</div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{getEstadoBadge(analisis.estado)}</TableCell>
                    <TableCell>{getPrioridadBadge(analisis.prioridad)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Ver detalles">
                          <Eye size={16} className="text-gray-600" />
                        </Button>
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Editar">
                          <Edit size={16} className="text-gray-600" />
                        </Button>
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Ver resultados">
                          <FileText size={16} className="text-green-600" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default LaboratorioManagement;
