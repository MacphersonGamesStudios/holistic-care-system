
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, User, Stethoscope, FileText, Image } from "lucide-react";

interface EstudioRadiologico {
  id: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  tipoEstudio: string;
  fechaSolicitud: string;
  fechaRealizacion?: string;
  medicoSolicitante: string;
  radiologo?: string;
  estado: 'solicitado' | 'programado' | 'realizado' | 'informado';
  prioridad: 'baja' | 'normal' | 'alta' | 'urgente';
  indicacion: string;
  hallazgos?: string;
  conclusion?: string;
  observaciones?: string;
}

interface EstudioRadiologicoDetailsProps {
  estudio: EstudioRadiologico;
  onClose: () => void;
}

const EstudioRadiologicoDetails = ({ estudio, onClose }: EstudioRadiologicoDetailsProps) => {
  const getEstadoBadge = (estado: string) => {
    switch (estado) {
      case 'solicitado':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Solicitado</Badge>;
      case 'programado':
        return <Badge variant="default" className="bg-orange-100 text-orange-800">Programado</Badge>;
      case 'realizado':
        return <Badge variant="secondary" className="bg-green-100 text-green-800">Realizado</Badge>;
      case 'informado':
        return <Badge variant="default" className="bg-cyan-100 text-cyan-800">Informado</Badge>;
      default:
        return <Badge variant="secondary">{estado}</Badge>;
    }
  };

  const getPrioridadBadge = (prioridad: string) => {
    switch (prioridad) {
      case 'urgente':
        return <Badge variant="destructive" className="bg-red-100 text-red-800">Urgente</Badge>;
      case 'alta':
        return <Badge variant="default" className="bg-orange-100 text-orange-800">Alta</Badge>;
      case 'normal':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Normal</Badge>;
      case 'baja':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-800">Baja</Badge>;
      default:
        return <Badge variant="secondary">{prioridad}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">Detalles del Estudio Radiológico</h2>
        <Button variant="outline" onClick={onClose}>Cerrar</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5 text-cyan-600" />
              Información del Paciente
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <label className="text-sm font-medium text-gray-600">Nombre completo</label>
              <p className="text-cyan-600 font-medium">{estudio.pacienteNombre}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Número de historia</label>
              <p className="font-mono">{estudio.numeroHistoria}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Image className="h-5 w-5 text-cyan-600" />
              Información del Estudio
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <label className="text-sm font-medium text-gray-600">Tipo de estudio</label>
              <p className="font-medium">{estudio.tipoEstudio}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Estado</label>
              <div className="mt-1">{getEstadoBadge(estudio.estado)}</div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Prioridad</label>
              <div className="mt-1">{getPrioridadBadge(estudio.prioridad)}</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-cyan-600" />
              Fechas
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <label className="text-sm font-medium text-gray-600">Fecha de solicitud</label>
              <p>{estudio.fechaSolicitud}</p>
            </div>
            {estudio.fechaRealizacion && (
              <div>
                <label className="text-sm font-medium text-gray-600">Fecha de realización</label>
                <p>{estudio.fechaRealizacion}</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Stethoscope className="h-5 w-5 text-cyan-600" />
              Personal Médico
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <label className="text-sm font-medium text-gray-600">Médico solicitante</label>
              <p>{estudio.medicoSolicitante}</p>
            </div>
            {estudio.radiologo && (
              <div>
                <label className="text-sm font-medium text-gray-600">Radiólogo</label>
                <p>{estudio.radiologo}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-cyan-600" />
            Indicación Clínica
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700">{estudio.indicacion}</p>
        </CardContent>
      </Card>

      {(estudio.hallazgos || estudio.conclusion) && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-cyan-600" />
              Informe Radiológico
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {estudio.hallazgos && (
              <div>
                <label className="text-sm font-medium text-gray-600">Hallazgos</label>
                <p className="mt-1 text-gray-700">{estudio.hallazgos}</p>
              </div>
            )}
            {estudio.conclusion && (
              <div>
                <label className="text-sm font-medium text-gray-600">Conclusión</label>
                <p className="mt-1 text-gray-700">{estudio.conclusion}</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {estudio.observaciones && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-cyan-600" />
              Observaciones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700">{estudio.observaciones}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default EstudioRadiologicoDetails;
