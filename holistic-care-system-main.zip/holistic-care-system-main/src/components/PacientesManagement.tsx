
import React, { useState } from 'react';
import { usePacientesData } from '../hooks/usePacientesData';
import PacientesHeader from './PacientesHeader';
import PacientesFilters from './PacientesFilters';
import PacientesTable from './PacientesTable';
import PacientesPagination from './PacientesPagination';
import PacientesModals from './PacientesModals';

interface Paciente {
  id: string;
  numeroHistoria: string;
  nombre: string;
  apellidos: string;
  dni: string;
  fechaNacimiento: string;
  sexo: string;
  telefono: string;
  email: string;
  fechaAlta: string;
  activo: boolean;
  foto?: string;
  direccion?: string;
  codigoPostal?: string;
  provincia?: string;
  poblacion?: string;
  observaciones?: string;
}

const PacientesManagement = () => {
  const {
    filteredPacientes,
    searchTerm,
    setSearchTerm,
    selectedState,
    setSelectedState,
    ocultarSinHistoria,
    handleOcultarSinHistoriaChange,
    clienteTutor,
    setClienteTutor,
    handleNewPatient,
    handleEditPatient,
    handleDeletePatient
  } = usePacientesData();

  const [showNewPatientDialog, setShowNewPatientDialog] = useState(false);
  const [showEditPatientDialog, setShowEditPatientDialog] = useState(false);
  const [showViewPatientDialog, setShowViewPatientDialog] = useState(false);
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);
  const [selectedPaciente, setSelectedPaciente] = useState<Paciente | null>(null);

  const handleViewPatient = (paciente: Paciente) => {
    setSelectedPaciente(paciente);
    setShowViewPatientDialog(true);
  };

  const handleEditClick = (paciente: Paciente) => {
    setSelectedPaciente(paciente);
    setShowEditPatientDialog(true);
  };

  const handleDeleteClick = (paciente: Paciente) => {
    setSelectedPaciente(paciente);
    setShowDeleteAlert(true);
  };

  const onEditPatient = (pacienteData: any) => {
    if (selectedPaciente) {
      handleEditPatient(selectedPaciente, pacienteData);
    }
  };

  const onDeletePatient = () => {
    if (selectedPaciente) {
      handleDeletePatient(selectedPaciente);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <PacientesHeader 
        showNewPatientDialog={showNewPatientDialog}
        setShowNewPatientDialog={setShowNewPatientDialog}
      />

      <PacientesFilters
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        selectedState={selectedState}
        setSelectedState={setSelectedState}
        ocultarSinHistoria={ocultarSinHistoria}
        setOcultarSinHistoria={handleOcultarSinHistoriaChange}
        clienteTutor={clienteTutor}
        setClienteTutor={setClienteTutor}
      />

      <PacientesTable 
        pacientes={filteredPacientes} 
        onEdit={handleEditClick}
        onDelete={handleDeleteClick}
        onView={handleViewPatient}
      />

      <PacientesPagination />

      <PacientesModals
        showNewPatientDialog={showNewPatientDialog}
        setShowNewPatientDialog={setShowNewPatientDialog}
        showEditPatientDialog={showEditPatientDialog}
        setShowEditPatientDialog={setShowEditPatientDialog}
        showViewPatientDialog={showViewPatientDialog}
        setShowViewPatientDialog={setShowViewPatientDialog}
        showDeleteAlert={showDeleteAlert}
        setShowDeleteAlert={setShowDeleteAlert}
        selectedPaciente={selectedPaciente}
        setSelectedPaciente={setSelectedPaciente}
        onNewPatient={handleNewPatient}
        onEditPatient={onEditPatient}
        onDeletePatient={onDeletePatient}
      />
    </div>
  );
};

export default PacientesManagement;
