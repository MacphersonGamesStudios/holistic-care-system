
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Medicamento } from '@/hooks/useFarmaciaData';

interface VentaModalProps {
  isOpen: boolean;
  onClose: () => void;
  medicamento: Medicamento | null;
  onSubmit: (cantidad: number) => void;
}

const VentaModal = ({ isOpen, onClose, medicamento, onSubmit }: VentaModalProps) => {
  const [cantidadVenta, setCantidadVenta] = useState('');

  const handleSubmit = () => {
    const cantidad = parseInt(cantidadVenta);
    if (cantidad > 0) {
      onSubmit(cantidad);
      onClose();
      setCantidadVenta('');
    }
  };

  const handleClose = () => {
    onClose();
    setCantidadVenta('');
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Registrar Venta</DialogTitle>
        </DialogHeader>
        {medicamento && (
          <div className="space-y-4">
            <div>
              <Label className="font-semibold">Medicamento:</Label>
              <p>{medicamento.nombre}</p>
            </div>
            <div>
              <Label className="font-semibold">Stock disponible:</Label>
              <p>{medicamento.stock} unidades</p>
            </div>
            <div>
              <Label htmlFor="cantidad">Cantidad a vender:</Label>
              <Input
                id="cantidad"
                type="number"
                min="1"
                max={medicamento.stock}
                value={cantidadVenta}
                onChange={(e) => setCantidadVenta(e.target.value)}
                placeholder="0"
              />
            </div>
            <div>
              <Label className="font-semibold">Precio unitario:</Label>
              <p>€{medicamento.precio.toFixed(2)}</p>
            </div>
            {cantidadVenta && (
              <div>
                <Label className="font-semibold">Total:</Label>
                <p>€{(parseFloat(cantidadVenta) * medicamento.precio).toFixed(2)}</p>
              </div>
            )}
          </div>
        )}
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={handleClose}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">
            Registrar Venta
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VentaModal;
