import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, User, MapPin, Stethoscope, FileText } from "lucide-react";
import { Hospitalizacion } from '../types/hospitalizacion';

interface HospitalizacionDetailsProps {
  hospitalizacion: Hospitalizacion;
  onClose: () => void;
}

const HospitalizacionDetails = ({ hospitalizacion, onClose }: HospitalizacionDetailsProps) => {
  const getEstadoBadge = (estado: string) => {
    switch (estado) {
      case 'ingresado':
        return <Badge variant="default" className="bg-green-100 text-green-800">Ingresado</Badge>;
      case 'alta':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-800">Alta</Badge>;
      case 'transferido':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Transferido</Badge>;
      default:
        return <Badge variant="secondary">{estado}</Badge>;
    }
  };

  const getTipoIngresoBadge = (tipo: string) => {
    switch (tipo) {
      case 'urgencia':
        return <Badge variant="destructive" className="bg-red-100 text-red-800">Urgencia</Badge>;
      case 'programado':
        return <Badge variant="default" className="bg-blue-100 text-blue-800">Programado</Badge>;
      case 'traslado':
        return <Badge variant="outline" className="bg-orange-100 text-orange-800">Traslado</Badge>;
      default:
        return <Badge variant="secondary">{tipo}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">Detalles de Hospitalización</h2>
        <Button variant="outline" onClick={onClose}>Cerrar</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5 text-cyan-600" />
              Información del Paciente
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <label className="text-sm font-medium text-gray-600">Nombre completo</label>
              <p className="text-cyan-600 font-medium">{hospitalizacion.pacienteNombre}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Número de historia</label>
              <p className="font-mono">{hospitalizacion.numeroHistoria}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-cyan-600" />
              Ubicación
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <label className="text-sm font-medium text-gray-600">Habitación</label>
              <p className="font-mono text-lg">{hospitalizacion.habitacion}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Cama</label>
              <p className="font-mono text-lg">{hospitalizacion.cama}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-cyan-600" />
              Fechas
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <label className="text-sm font-medium text-gray-600">Fecha de ingreso</label>
              <p>{hospitalizacion.fechaIngreso}</p>
            </div>
            {hospitalizacion.fechaAlta && (
              <div>
                <label className="text-sm font-medium text-gray-600">Fecha de alta</label>
                <p>{hospitalizacion.fechaAlta}</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Stethoscope className="h-5 w-5 text-cyan-600" />
              Información Médica
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <label className="text-sm font-medium text-gray-600">Médico responsable</label>
              <p>{hospitalizacion.medicoResponsable}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Estado</label>
              <div className="mt-1">{getEstadoBadge(hospitalizacion.estado)}</div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Tipo de ingreso</label>
              <div className="mt-1">{getTipoIngresoBadge(hospitalizacion.tipoIngreso)}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-cyan-600" />
            Diagnóstico y Observaciones
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <label className="text-sm font-medium text-gray-600">Diagnóstico</label>
            <p className="mt-1">{hospitalizacion.diagnostico}</p>
          </div>
          {hospitalizacion.observaciones && (
            <div>
              <label className="text-sm font-medium text-gray-600">Observaciones</label>
              <p className="mt-1 text-gray-700">{hospitalizacion.observaciones}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default HospitalizacionDetails;
