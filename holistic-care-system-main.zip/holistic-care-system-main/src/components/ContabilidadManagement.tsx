
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Calendar, DollarSign, TrendingUp, TrendingDown, FileText, Download } from "lucide-react";

interface MovimientoDiario {
  id: string;
  fecha: string;
  concepto: string;
  tipo: 'ingreso' | 'gasto';
  categoria: string;
  importe: number;
  metodo: string;
  descripcion: string;
}

const ContabilidadManagement = () => {
  const [fechaSeleccionada, setFechaSeleccionada] = useState(new Date().toISOString().split('T')[0]);
  const [movimientos] = useState<MovimientoDiario[]>([
    {
      id: '1',
      fecha: '2024-05-26',
      concepto: 'Consulta Medicina General',
      tipo: 'ingreso',
      categoria: 'Consultas',
      importe: 75.00,
      metodo: 'Efectivo',
      descripcion: 'Consulta Dr. Martínez'
    },
    {
      id: '2',
      fecha: '2024-05-26',
      concepto: 'Material médico',
      tipo: 'gasto',
      categoria: 'Suministros',
      importe: 125.50,
      metodo: 'Transferencia',
      descripcion: 'Compra material quirúrgico'
    },
    {
      id: '3',
      fecha: '2024-05-26',
      concepto: 'Consulta Cardiología',
      tipo: 'ingreso',
      categoria: 'Consultas',
      importe: 120.00,
      metodo: 'Tarjeta',
      descripcion: 'Consulta especializada'
    }
  ]);

  const movimientosFecha = movimientos.filter(m => m.fecha === fechaSeleccionada);
  const totalIngresos = movimientosFecha.filter(m => m.tipo === 'ingreso').reduce((sum, m) => sum + m.importe, 0);
  const totalGastos = movimientosFecha.filter(m => m.tipo === 'gasto').reduce((sum, m) => sum + m.importe, 0);
  const balanceDiario = totalIngresos - totalGastos;

  return (
    <div className="p-6 space-y-6">
      {/* Breadcrumb */}
      <div className="text-sm text-gray-600 mb-4">
        <span className="text-cyan-600">Gestión médica</span> / <span>Contabilidad diaria</span>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Contabilidad Diaria</h1>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Download size={16} className="mr-1" />
            Exportar
          </Button>
          <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
            <FileText size={16} className="mr-1" />
            Nuevo Movimiento
          </Button>
        </div>
      </div>

      {/* Date Selection */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Calendar size={20} className="text-cyan-600" />
              <label className="text-sm font-medium text-gray-700">Fecha:</label>
            </div>
            <Input
              type="date"
              value={fechaSeleccionada}
              onChange={(e) => setFechaSeleccionada(e.target.value)}
              className="w-auto"
            />
          </div>
        </CardContent>
      </Card>

      {/* Daily Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="text-green-600" size={20} />
              <div>
                <div className="text-2xl font-bold text-green-600">€{totalIngresos.toFixed(2)}</div>
                <div className="text-sm text-gray-600">Ingresos del día</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingDown className="text-red-600" size={20} />
              <div>
                <div className="text-2xl font-bold text-red-600">€{totalGastos.toFixed(2)}</div>
                <div className="text-sm text-gray-600">Gastos del día</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <DollarSign className={`${balanceDiario >= 0 ? 'text-green-600' : 'text-red-600'}`} size={20} />
              <div>
                <div className={`text-2xl font-bold ${balanceDiario >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  €{balanceDiario.toFixed(2)}
                </div>
                <div className="text-sm text-gray-600">Balance del día</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <FileText className="text-blue-600" size={20} />
              <div>
                <div className="text-2xl font-bold text-blue-600">{movimientosFecha.length}</div>
                <div className="text-sm text-gray-600">Movimientos</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Movements Table */}
      <Card>
        <CardHeader>
          <CardTitle>Movimientos del {fechaSeleccionada}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-cyan-600 hover:bg-cyan-600">
                <TableHead className="text-white font-semibold">Hora</TableHead>
                <TableHead className="text-white font-semibold">Concepto</TableHead>
                <TableHead className="text-white font-semibold">Categoría</TableHead>
                <TableHead className="text-white font-semibold">Método</TableHead>
                <TableHead className="text-white font-semibold">Importe</TableHead>
                <TableHead className="text-white font-semibold">Tipo</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {movimientosFecha.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                    No hay movimientos para esta fecha
                  </TableCell>
                </TableRow>
              ) : (
                movimientosFecha.map((movimiento) => (
                  <TableRow key={movimiento.id} className="hover:bg-gray-50">
                    <TableCell className="font-mono text-sm">09:00</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{movimiento.concepto}</div>
                        <div className="text-sm text-gray-600">{movimiento.descripcion}</div>
                      </div>
                    </TableCell>
                    <TableCell>{movimiento.categoria}</TableCell>
                    <TableCell>{movimiento.metodo}</TableCell>
                    <TableCell className="font-mono">
                      <span className={movimiento.tipo === 'ingreso' ? 'text-green-600' : 'text-red-600'}>
                        €{movimiento.importe.toFixed(2)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded text-sm ${
                        movimiento.tipo === 'ingreso' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {movimiento.tipo === 'ingreso' ? 'Ingreso' : 'Gasto'}
                      </span>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default ContabilidadManagement;
