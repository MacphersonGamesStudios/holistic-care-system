
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Edit, Eye, Trash2, Phone, Mail } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Cliente {
  id: string;
  nombre: string;
  apellidos: string;
  dni: string;
  telefono: string;
  email: string;
  direccion: string;
  fechaRegistro: string;
  activo: boolean;
  pacientesAsociados: number;
}

const ClientesManagement = () => {
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [filteredClientes, setFilteredClientes] = useState<Cliente[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedState, setSelectedState] = useState('activos');

  useEffect(() => {
    // Datos de ejemplo
    const clientesEjemplo: Cliente[] = [
      {
        id: '1',
        nombre: 'María',
        apellidos: 'García Rodríguez',
        dni: '12345678A',
        telefono: '666123456',
        email: 'maria.garcia@email.com',
        direccion: 'Calle Mayor 123, Madrid',
        fechaRegistro: '2024-01-15',
        activo: true,
        pacientesAsociados: 2
      },
      {
        id: '2',
        nombre: 'Carlos',
        apellidos: 'López Martínez',
        dni: '87654321B',
        telefono: '677987654',
        email: 'carlos.lopez@email.com',
        direccion: 'Avenida Libertad 45, Barcelona',
        fechaRegistro: '2024-02-20',
        activo: true,
        pacientesAsociados: 1
      }
    ];
    setClientes(clientesEjemplo);
    setFilteredClientes(clientesEjemplo);
  }, []);

  useEffect(() => {
    let filtered = clientes;

    if (selectedState === 'activos') {
      filtered = filtered.filter(c => c.activo);
    } else if (selectedState === 'inactivos') {
      filtered = filtered.filter(c => !c.activo);
    }

    if (searchTerm) {
      filtered = filtered.filter(c => 
        c.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.apellidos.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.dni.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredClientes(filtered);
  }, [clientes, searchTerm, selectedState]);

  return (
    <div className="p-6 space-y-6">
      {/* Breadcrumb */}
      <div className="text-sm text-gray-600 mb-4">
        <span className="text-cyan-600">Gestión médica</span> / <span>Clientes/Tutores</span>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-gray-800">Clientes/Tutores</h1>
          <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
            <Plus size={16} />
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Estado</label>
              <Select value={selectedState} onValueChange={setSelectedState}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="activos">Activos</SelectItem>
                  <SelectItem value="inactivos">Inactivos</SelectItem>
                  <SelectItem value="todos">Todos</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Buscar cliente</label>
              <div className="relative">
                <Input
                  placeholder="Buscar por nombre, apellidos o DNI..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-cyan-600">{clientes.filter(c => c.activo).length}</div>
            <div className="text-sm text-gray-600">Clientes Activos</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-gray-600">{clientes.filter(c => !c.activo).length}</div>
            <div className="text-sm text-gray-600">Clientes Inactivos</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-600">{clientes.reduce((acc, c) => acc + c.pacientesAsociados, 0)}</div>
            <div className="text-sm text-gray-600">Pacientes Asociados</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-blue-600">{clientes.length}</div>
            <div className="text-sm text-gray-600">Total Clientes</div>
          </CardContent>
        </Card>
      </div>

      {/* Clients Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-cyan-600 hover:bg-cyan-600">
                <TableHead className="text-white font-semibold">Cliente</TableHead>
                <TableHead className="text-white font-semibold">DNI</TableHead>
                <TableHead className="text-white font-semibold">Contacto</TableHead>
                <TableHead className="text-white font-semibold">Pacientes</TableHead>
                <TableHead className="text-white font-semibold">Registro</TableHead>
                <TableHead className="text-white font-semibold">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredClientes.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                    No se encontraron clientes
                  </TableCell>
                </TableRow>
              ) : (
                filteredClientes.map((cliente) => (
                  <TableRow key={cliente.id} className="hover:bg-gray-50">
                    <TableCell>
                      <span className="text-cyan-600 font-medium">
                        {cliente.apellidos}, {cliente.nombre}
                      </span>
                    </TableCell>
                    <TableCell className="font-mono text-sm">{cliente.dni}</TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-1 text-sm">
                          <Phone size={12} />
                          {cliente.telefono}
                        </div>
                        <div className="flex items-center gap-1 text-sm">
                          <Mail size={12} />
                          {cliente.email}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                        {cliente.pacientesAsociados}
                      </span>
                    </TableCell>
                    <TableCell>{cliente.fechaRegistro}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Ver cliente">
                          <Eye size={16} className="text-gray-600" />
                        </Button>
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Editar cliente">
                          <Edit size={16} className="text-gray-600" />
                        </Button>
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Eliminar cliente">
                          <Trash2 size={16} className="text-red-600" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default ClientesManagement;
