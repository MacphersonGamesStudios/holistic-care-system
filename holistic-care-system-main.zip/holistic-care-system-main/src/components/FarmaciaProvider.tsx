
import React, { createContext, useContext, ReactNode } from 'react';
import { useFarmaciaData, Medicamento } from '../hooks/useFarmaciaData';

interface FarmaciaContextType {
  medicamentos: Medicamento[];
  filteredMedicamentos: Medicamento[];
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  categoriaFilter: string;
  setCategoriaFilter: (categoria: string) => void;
  stockFilter: string;
  setStockFilter: (stock: string) => void;
  handleNewMedicamento: (medicamentoData: any) => void;
  handleEditMedicamento: (selectedMedicamento: Medicamento, medicamentoData: any) => void;
  handleVentaMedicamento: (selectedMedicamento: Medicamento, cantidad: number) => void;
}

const FarmaciaContext = createContext<FarmaciaContextType | undefined>(undefined);

export const useFarmaciaContext = () => {
  const context = useContext(FarmaciaContext);
  if (!context) {
    throw new Error('useFarmaciaContext must be used within a FarmaciaProvider');
  }
  return context;
};

interface FarmaciaProviderProps {
  children: ReactNode;
}

export const FarmaciaProvider = ({ children }: FarmaciaProviderProps) => {
  const farmaciaData = useFarmaciaData();

  return (
    <FarmaciaContext.Provider value={farmaciaData}>
      {children}
    </FarmaciaContext.Provider>
  );
};
