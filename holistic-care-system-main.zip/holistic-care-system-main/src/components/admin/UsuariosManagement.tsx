
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Eye, EyeOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Usuario {
  id: number;
  nombre: string;
  apellidos: string;
  email: string;
  rol: string;
  centro: string;
  activo: boolean;
  ultimoAcceso: string;
}

const UsuariosManagement = () => {
  const { toast } = useToast();
  const [usuarios, setUsuarios] = useState<Usuario[]>([
    {
      id: 1,
      nombre: "Dr. Juan",
      apellidos: "Pérez García",
      email: "juan.perez@hospital.com",
      rol: "Médico",
      centro: "Hospital Macpherson",
      activo: true,
      ultimoAcceso: "2024-01-15 10:30"
    },
    {
      id: 2,
      nombre: "Dra. María",
      apellidos: "López Fernández", 
      email: "maria.lopez@hospital.com",
      rol: "Administrador",
      centro: "Hospital Macpherson",
      activo: true,
      ultimoAcceso: "2024-01-15 09:15"
    }
  ]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingUsuario, setEditingUsuario] = useState<Usuario | null>(null);
  const [formData, setFormData] = useState({
    nombre: '',
    apellidos: '',
    email: '',
    rol: 'Médico',
    centro: 'Hospital Macpherson',
    activo: true
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingUsuario) {
      setUsuarios(usuarios.map(usuario => 
        usuario.id === editingUsuario.id 
          ? { ...usuario, ...formData, ultimoAcceso: new Date().toLocaleString() }
          : usuario
      ));
      toast({
        title: "Usuario actualizado",
        description: "El usuario ha sido actualizado correctamente.",
      });
    } else {
      const newUsuario: Usuario = {
        id: usuarios.length + 1,
        ...formData,
        ultimoAcceso: "Nunca"
      };
      
      setUsuarios([...usuarios, newUsuario]);
      toast({
        title: "Usuario creado",
        description: "El nuevo usuario ha sido creado correctamente.",
      });
    }
    
    setIsDialogOpen(false);
    setEditingUsuario(null);
    setFormData({
      nombre: '',
      apellidos: '',
      email: '',
      rol: 'Médico',
      centro: 'Hospital Macpherson',
      activo: true
    });
  };

  const handleEdit = (usuario: Usuario) => {
    setEditingUsuario(usuario);
    setFormData({
      nombre: usuario.nombre,
      apellidos: usuario.apellidos,
      email: usuario.email,
      rol: usuario.rol,
      centro: usuario.centro,
      activo: usuario.activo
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    setUsuarios(usuarios.filter(usuario => usuario.id !== id));
    toast({
      title: "Usuario eliminado",
      description: "El usuario ha sido eliminado correctamente.",
      variant: "destructive"
    });
  };

  const toggleActivo = (id: number) => {
    setUsuarios(usuarios.map(usuario => 
      usuario.id === id 
        ? { ...usuario, activo: !usuario.activo }
        : usuario
    ));
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <nav className="text-sm text-gray-600 mb-4">
          Administrador / Usuarios
        </nav>
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Usuarios</h1>
          <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
            <span className="text-gray-600 text-sm">?</span>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Usuarios del Sistema</CardTitle>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button 
                  className="bg-cyan-600 hover:bg-cyan-700"
                  onClick={() => {
                    setEditingUsuario(null);
                    setFormData({
                      nombre: '',
                      apellidos: '',
                      email: '',
                      rol: 'Médico',
                      centro: 'Hospital Macpherson',
                      activo: true
                    });
                  }}
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Nuevo Usuario
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>
                    {editingUsuario ? 'Editar Usuario' : 'Nuevo Usuario'}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Nombre</label>
                    <Input
                      value={formData.nombre}
                      onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Apellidos</label>
                    <Input
                      value={formData.apellidos}
                      onChange={(e) => setFormData({...formData, apellidos: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Email</label>
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Rol</label>
                    <select
                      className="w-full p-2 border rounded-md"
                      value={formData.rol}
                      onChange={(e) => setFormData({...formData, rol: e.target.value})}
                    >
                      <option value="Médico">Médico</option>
                      <option value="Enfermero">Enfermero</option>
                      <option value="Administrador">Administrador</option>
                      <option value="Recepcionista">Recepcionista</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Centro</label>
                    <select
                      className="w-full p-2 border rounded-md"
                      value={formData.centro}
                      onChange={(e) => setFormData({...formData, centro: e.target.value})}
                    >
                      <option value="Hospital Macpherson">Hospital Macpherson</option>
                    </select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="activo"
                      checked={formData.activo}
                      onChange={(e) => setFormData({...formData, activo: e.target.checked})}
                    />
                    <label htmlFor="activo">Usuario activo</label>
                  </div>
                  <div className="flex gap-2">
                    <Button type="submit" className="bg-green-600 hover:bg-green-700">
                      {editingUsuario ? 'Actualizar' : 'Crear'}
                    </Button>
                    <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                      Cancelar
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Nombre</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Rol</TableHead>
                <TableHead>Centro</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Último Acceso</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {usuarios.map((usuario) => (
                <TableRow key={usuario.id}>
                  <TableCell>{usuario.id}</TableCell>
                  <TableCell>{usuario.nombre} {usuario.apellidos}</TableCell>
                  <TableCell>{usuario.email}</TableCell>
                  <TableCell>{usuario.rol}</TableCell>
                  <TableCell>{usuario.centro}</TableCell>
                  <TableCell>
                    <Badge variant={usuario.activo ? "default" : "secondary"}>
                      {usuario.activo ? 'Activo' : 'Inactivo'}
                    </Badge>
                  </TableCell>
                  <TableCell>{usuario.ultimoAcceso}</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(usuario)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => toggleActivo(usuario.id)}
                      >
                        {usuario.activo ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDelete(usuario.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default UsuariosManagement;
