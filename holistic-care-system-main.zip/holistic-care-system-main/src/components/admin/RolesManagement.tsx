
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Edit, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Rol {
  id: number;
  nombre: string;
  descripcion: string;
  permisos: string[];
  activo: boolean;
}

const RolesManagement = () => {
  const { toast } = useToast();
  const [roles, setRoles] = useState<Rol[]>([
    {
      id: 1,
      nombre: "Administrador",
      descripcion: "Acceso completo al sistema",
      permisos: ["todos"],
      activo: true
    },
    {
      id: 2,
      nombre: "Médico",
      descripcion: "Acceso a funciones médicas",
      permisos: ["agenda", "visitas", "pacientes"],
      activo: true
    },
    {
      id: 3,
      nombre: "Enfermero",
      descripcion: "Acceso limitado a funciones de enfermería",
      permisos: ["visitas", "pacientes"],
      activo: true
    }
  ]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingRol, setEditingRol] = useState<Rol | null>(null);
  const [formData, setFormData] = useState({
    nombre: '',
    descripcion: '',
    permisos: [] as string[],
    activo: true
  });

  const permisosDisponibles = [
    'agenda', 'visitas', 'pacientes', 'facturacion', 'estadisticas',
    'hospitalizacion', 'farmacia', 'radiologia', 'laboratorio'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingRol) {
      setRoles(roles.map(rol => 
        rol.id === editingRol.id 
          ? { ...rol, ...formData }
          : rol
      ));
      toast({
        title: "Rol actualizado",
        description: "El rol ha sido actualizado correctamente.",
      });
    } else {
      const newRol: Rol = {
        id: roles.length + 1,
        ...formData
      };
      
      setRoles([...roles, newRol]);
      toast({
        title: "Rol creado",
        description: "El nuevo rol ha sido creado correctamente.",
      });
    }
    
    setIsDialogOpen(false);
    setEditingRol(null);
    setFormData({
      nombre: '',
      descripcion: '',
      permisos: [],
      activo: true
    });
  };

  const handleEdit = (rol: Rol) => {
    setEditingRol(rol);
    setFormData(rol);
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    setRoles(roles.filter(rol => rol.id !== id));
    toast({
      title: "Rol eliminado",
      description: "El rol ha sido eliminado correctamente.",
      variant: "destructive"
    });
  };

  const handlePermisoChange = (permiso: string, checked: boolean) => {
    if (checked) {
      setFormData({
        ...formData,
        permisos: [...formData.permisos, permiso]
      });
    } else {
      setFormData({
        ...formData,
        permisos: formData.permisos.filter(p => p !== permiso)
      });
    }
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <nav className="text-sm text-gray-600 mb-4">
          Administrador / Roles
        </nav>
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Roles</h1>
          <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
            <span className="text-gray-600 text-sm">?</span>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Roles del Sistema</CardTitle>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button 
                  className="bg-cyan-600 hover:bg-cyan-700"
                  onClick={() => {
                    setEditingRol(null);
                    setFormData({
                      nombre: '',
                      descripcion: '',
                      permisos: [],
                      activo: true
                    });
                  }}
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Nuevo Rol
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>
                    {editingRol ? 'Editar Rol' : 'Nuevo Rol'}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Nombre del Rol</label>
                    <Input
                      value={formData.nombre}
                      onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Descripción</label>
                    <Input
                      value={formData.descripcion}
                      onChange={(e) => setFormData({...formData, descripcion: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Permisos</label>
                    <div className="grid grid-cols-2 gap-2">
                      {permisosDisponibles.map((permiso) => (
                        <div key={permiso} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id={permiso}
                            checked={formData.permisos.includes(permiso)}
                            onChange={(e) => handlePermisoChange(permiso, e.target.checked)}
                          />
                          <label htmlFor={permiso} className="capitalize">
                            {permiso}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="activo"
                      checked={formData.activo}
                      onChange={(e) => setFormData({...formData, activo: e.target.checked})}
                    />
                    <label htmlFor="activo">Rol activo</label>
                  </div>
                  <div className="flex gap-2">
                    <Button type="submit" className="bg-green-600 hover:bg-green-700">
                      {editingRol ? 'Actualizar' : 'Crear'}
                    </Button>
                    <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                      Cancelar
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Nombre</TableHead>
                <TableHead>Descripción</TableHead>
                <TableHead>Permisos</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {roles.map((rol) => (
                <TableRow key={rol.id}>
                  <TableCell>{rol.id}</TableCell>
                  <TableCell className="font-medium">{rol.nombre}</TableCell>
                  <TableCell>{rol.descripcion}</TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {rol.permisos.map((permiso, index) => (
                        <span 
                          key={index}
                          className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded"
                        >
                          {permiso}
                        </span>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded text-xs ${
                      rol.activo ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {rol.activo ? 'Activo' : 'Inactivo'}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(rol)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDelete(rol.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default RolesManagement;
