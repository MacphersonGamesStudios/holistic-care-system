
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

const PerfilClienteManagement = () => {
  const { toast } = useToast();
  const [perfilData, setPerfilData] = useState({
    razonSocial: "Hospital Veterinario Macpherson S.L.",
    cif: "B12345678",
    direccion: "Calle Principal 123",
    codigoPostal: "28001",
    ciudad: "Madrid",
    provincia: "Madrid",
    pais: "España",
    telefono: "912345678",
    email: "info@hospitalmacpherson.com",
    sitioWeb: "www.hospitalmacpherson.com",
    contactoPrincipal: "Dr. Juan Pérez",
    telefonoContacto: "612345678",
    emailContacto: "contacto@hospitalmacpherson.com"
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Perfil actualizado",
      description: "Los datos del perfil del cliente han sido actualizados correctamente.",
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setPerfilData({
      ...perfilData,
      [field]: value
    });
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <nav className="text-sm text-gray-600 mb-4">
          Administrador / Perfil del cliente
        </nav>
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-800">Perfil del Cliente</h1>
          <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
            <span className="text-gray-600 text-sm">?</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Información de la Empresa</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="razonSocial">Razón Social</Label>
                <Input
                  id="razonSocial"
                  value={perfilData.razonSocial}
                  onChange={(e) => handleInputChange('razonSocial', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="cif">CIF/NIF</Label>
                <Input
                  id="cif"
                  value={perfilData.cif}
                  onChange={(e) => handleInputChange('cif', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="direccion">Dirección</Label>
                <Input
                  id="direccion"
                  value={perfilData.direccion}
                  onChange={(e) => handleInputChange('direccion', e.target.value)}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="codigoPostal">Código Postal</Label>
                  <Input
                    id="codigoPostal"
                    value={perfilData.codigoPostal}
                    onChange={(e) => handleInputChange('codigoPostal', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="ciudad">Ciudad</Label>
                  <Input
                    id="ciudad"
                    value={perfilData.ciudad}
                    onChange={(e) => handleInputChange('ciudad', e.target.value)}
                  />
                </div>
              </div>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Información de Contacto</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-4">
              <div>
                <Label htmlFor="telefono">Teléfono Principal</Label>
                <Input
                  id="telefono"
                  value={perfilData.telefono}
                  onChange={(e) => handleInputChange('telefono', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="email">Email Principal</Label>
                <Input
                  id="email"
                  type="email"
                  value={perfilData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="sitioWeb">Sitio Web</Label>
                <Input
                  id="sitioWeb"
                  value={perfilData.sitioWeb}
                  onChange={(e) => handleInputChange('sitioWeb', e.target.value)}
                />
              </div>
            </form>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 flex gap-2">
        <Button 
          onClick={handleSubmit}
          className="bg-green-600 hover:bg-green-700"
        >
          Guardar Cambios
        </Button>
        <Button variant="outline">
          Cancelar
        </Button>
      </div>
    </div>
  );
};

export default PerfilClienteManagement;
