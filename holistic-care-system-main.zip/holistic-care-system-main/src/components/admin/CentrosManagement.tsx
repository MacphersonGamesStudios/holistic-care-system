
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2 } from 'lucide-react';

const CentrosManagement = () => {
  const [centros] = useState([
    {
      id: 1,
      nombre: "Hospital Macpherson Central",
      direccion: "Av. Principal 123, Barcelona",
      telefono: "+34 93 485 62 48",
      email: "hospitalmacpherson@groupmacpherson.com",
      estado: "Activo",
      fechaCreacion: "01/01/2024"
    }
  ]);

  return (
    <div className="p-6">
      <div className="mb-6">
        <nav className="text-sm text-gray-600 mb-4">
          Administrador / Centros
        </nav>
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Centros</h1>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <Plus size={16} className="mr-2" />
            Nuevo Centro
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Centros Activos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">1</div>
            <p className="text-gray-600">Total centros</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Usuarios Totales</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">25</div>
            <p className="text-gray-600">En todos los centros</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Servicios Activos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">14</div>
            <p className="text-gray-600">Módulos disponibles</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Centros</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nombre</TableHead>
                <TableHead>Dirección</TableHead>
                <TableHead>Teléfono</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Fecha Creación</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {centros.map((centro) => (
                <TableRow key={centro.id}>
                  <TableCell className="font-medium">{centro.nombre}</TableCell>
                  <TableCell>{centro.direccion}</TableCell>
                  <TableCell>{centro.telefono}</TableCell>
                  <TableCell>{centro.email}</TableCell>
                  <TableCell>
                    <Badge variant="default" className="bg-green-600">
                      {centro.estado}
                    </Badge>
                  </TableCell>
                  <TableCell>{centro.fechaCreacion}</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <Edit size={14} />
                      </Button>
                      <Button size="sm" variant="outline" className="text-red-600">
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default CentrosManagement;
