
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const LicenciasManagement = () => {
  const [licencias] = useState([
    {
      id: 1,
      modulo: "Gestión Clínica Completa",
      tipo: "Premium",
      fechaInicio: "01/01/2024",
      fechaVencimiento: "31/12/2024",
      estado: "Activa",
      usuarios: 25,
      centros: 1
    }
  ]);

  return (
    <div className="p-6">
      <div className="mb-6">
        <nav className="text-sm text-gray-600 mb-4">
          Administrador / Licencias
        </nav>
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Licencias</h1>
          <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
            <span className="text-gray-600 text-sm">?</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Licencias Activas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">1</div>
            <p className="text-gray-600">Total activas</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Usuarios Permitidos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">25</div>
            <p className="text-gray-600">Máximo usuarios</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Días Restantes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">342</div>
            <p className="text-gray-600">Hasta vencimiento</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Licencias del Sistema</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Módulo</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Fecha Inicio</TableHead>
                <TableHead>Fecha Vencimiento</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Usuarios</TableHead>
                <TableHead>Centros</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {licencias.map((licencia) => (
                <TableRow key={licencia.id}>
                  <TableCell className="font-medium">{licencia.modulo}</TableCell>
                  <TableCell>{licencia.tipo}</TableCell>
                  <TableCell>{licencia.fechaInicio}</TableCell>
                  <TableCell>{licencia.fechaVencimiento}</TableCell>
                  <TableCell>
                    <Badge variant="default" className="bg-green-600">
                      {licencia.estado}
                    </Badge>
                  </TableCell>
                  <TableCell>{licencia.usuarios}</TableCell>
                  <TableCell>{licencia.centros}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default LicenciasManagement;
