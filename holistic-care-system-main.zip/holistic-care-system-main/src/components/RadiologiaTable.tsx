
import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import RadiologiaTableRow from './RadiologiaTableRow';
import RadiologiaModals from './RadiologiaModals';

interface EstudioRadiologico {
  id: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  tipoEstudio: string;
  fechaSolicitud: string;
  fechaRealizacion?: string;
  medicoSolicitante: string;
  radiologo?: string;
  estado: 'solicitado' | 'programado' | 'realizado' | 'informado';
  prioridad: 'baja' | 'normal' | 'alta' | 'urgente';
  indicacion: string;
  hallazgos?: string;
  conclusion?: string;
  observaciones?: string;
}

interface RadiologiaTableProps {
  estudios: EstudioRadiologico[];
  onUpdate: (id: string, data: Partial<EstudioRadiologico>) => void;
}

const RadiologiaTable = ({ estudios, onUpdate }: RadiologiaTableProps) => {
  const [selectedEstudio, setSelectedEstudio] = useState<EstudioRadiologico | null>(null);
  const [modalType, setModalType] = useState<'details' | 'edit' | 'images' | 'report' | null>(null);

  const handleViewDetails = (estudio: EstudioRadiologico) => {
    setSelectedEstudio(estudio);
    setModalType('details');
  };

  const handleEdit = (estudio: EstudioRadiologico) => {
    setSelectedEstudio(estudio);
    setModalType('edit');
  };

  const handleViewImages = (estudio: EstudioRadiologico) => {
    setSelectedEstudio(estudio);
    setModalType('images');
  };

  const handleViewReport = (estudio: EstudioRadiologico) => {
    setSelectedEstudio(estudio);
    setModalType('report');
  };

  const handleSaveEdit = (data: Partial<EstudioRadiologico>) => {
    if (selectedEstudio) {
      onUpdate(selectedEstudio.id, data);
      setModalType(null);
      setSelectedEstudio(null);
    }
  };

  const handleCloseModal = () => {
    setModalType(null);
    setSelectedEstudio(null);
  };

  return (
    <>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-cyan-600 hover:bg-cyan-600">
                <TableHead className="text-white font-semibold">Paciente</TableHead>
                <TableHead className="text-white font-semibold">Estudio</TableHead>
                <TableHead className="text-white font-semibold">Solicitud</TableHead>
                <TableHead className="text-white font-semibold">Médico</TableHead>
                <TableHead className="text-white font-semibold">Estado</TableHead>
                <TableHead className="text-white font-semibold">Prioridad</TableHead>
                <TableHead className="text-white font-semibold">Indicación</TableHead>
                <TableHead className="text-white font-semibold">Opciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {estudios.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-gray-500">
                    No se encontraron estudios radiológicos
                  </TableCell>
                </TableRow>
              ) : (
                estudios.map((estudio) => (
                  <RadiologiaTableRow
                    key={estudio.id}
                    estudio={estudio}
                    onViewDetails={handleViewDetails}
                    onEdit={handleEdit}
                    onViewImages={handleViewImages}
                    onViewReport={handleViewReport}
                  />
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <RadiologiaModals
        selectedEstudio={selectedEstudio}
        modalType={modalType}
        onCloseModal={handleCloseModal}
        onSaveEdit={handleSaveEdit}
      />
    </>
  );
};

export default RadiologiaTable;
