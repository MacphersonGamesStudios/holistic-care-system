
import React from 'react';
import { useFarmaciaContext } from './FarmaciaProvider';
import { useFarmaciaManagementState } from '../hooks/useFarmaciaManagementState';
import FarmaciaModals from './FarmaciaModals';

interface FarmaciaActionsProps {
  managementState: ReturnType<typeof useFarmaciaManagementState>;
}

const FarmaciaActions = ({ managementState }: FarmaciaActionsProps) => {
  const { handleNewMedicamento, handleEditMedicamento, handleVentaMedicamento } = useFarmaciaContext();
  const {
    showNewMedicamentoDialog,
    setShowNewMedicamentoDialog,
    showEditMedicamentoDialog,
    setShowEditMedicamentoDialog,
    showViewMedicamentoDialog,
    setShowViewMedicamentoDialog,
    showVentaDialog,
    setShowVentaDialog,
    selectedMedicamento,
  } = managementState;

  const onEditMedicamento = (medicamentoData: any) => {
    if (selectedMedicamento) {
      handleEditMedicamento(selectedMedicamento, medicamentoData);
    }
  };

  const onVentaMedicamento = (cantidad: number) => {
    if (selectedMedicamento) {
      handleVentaMedicamento(selectedMedicamento, cantidad);
    }
  };

  return (
    <FarmaciaModals
      showNewMedicamentoDialog={showNewMedicamentoDialog}
      setShowNewMedicamentoDialog={setShowNewMedicamentoDialog}
      showEditMedicamentoDialog={showEditMedicamentoDialog}
      setShowEditMedicamentoDialog={setShowEditMedicamentoDialog}
      showViewMedicamentoDialog={showViewMedicamentoDialog}
      setShowViewMedicamentoDialog={setShowViewMedicamentoDialog}
      showVentaDialog={showVentaDialog}
      setShowVentaDialog={setShowVentaDialog}
      selectedMedicamento={selectedMedicamento}
      onNewMedicamento={handleNewMedicamento}
      onEditMedicamento={onEditMedicamento}
      onVentaMedicamento={onVentaMedicamento}
    />
  );
};

export default FarmaciaActions;
