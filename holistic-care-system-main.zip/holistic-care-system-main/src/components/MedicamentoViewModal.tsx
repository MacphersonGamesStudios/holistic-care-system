
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Medicamento } from '@/hooks/useFarmaciaData';

interface MedicamentoViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  medicamento: Medicamento | null;
}

const MedicamentoViewModal = ({ isOpen, onClose, medicamento }: MedicamentoViewModalProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Detalles del Medicamento</DialogTitle>
        </DialogHeader>
        {medicamento && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="font-semibold">Nombre:</Label>
                <p>{medicamento.nombre}</p>
              </div>
              <div>
                <Label className="font-semibold">Principio Activo:</Label>
                <p>{medicamento.principioActivo}</p>
              </div>
              <div>
                <Label className="font-semibold">Laboratorio:</Label>
                <p>{medicamento.laboratorio}</p>
              </div>
              <div>
                <Label className="font-semibold">Presentación:</Label>
                <p>{medicamento.presentacion}</p>
              </div>
              <div>
                <Label className="font-semibold">Stock Actual:</Label>
                <p>{medicamento.stock} unidades</p>
              </div>
              <div>
                <Label className="font-semibold">Stock Mínimo:</Label>
                <p>{medicamento.stockMinimo} unidades</p>
              </div>
              <div>
                <Label className="font-semibold">Precio:</Label>
                <p>€{medicamento.precio.toFixed(2)}</p>
              </div>
              <div>
                <Label className="font-semibold">Categoría:</Label>
                <p>{medicamento.categoria}</p>
              </div>
              <div>
                <Label className="font-semibold">Fecha de Caducidad:</Label>
                <p>{medicamento.fechaCaducidad}</p>
              </div>
              <div>
                <Label className="font-semibold">Lote:</Label>
                <p>{medicamento.lote}</p>
              </div>
            </div>
            <div>
              <Label className="font-semibold">Prescripción:</Label>
              {medicamento.prescripcion ? (
                <Badge variant="outline" className="ml-2">Con receta</Badge>
              ) : (
                <Badge variant="secondary" className="ml-2">Sin receta</Badge>
              )}
            </div>
          </div>
        )}
        <div className="flex justify-end">
          <Button onClick={onClose}>
            Cerrar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default MedicamentoViewModal;
