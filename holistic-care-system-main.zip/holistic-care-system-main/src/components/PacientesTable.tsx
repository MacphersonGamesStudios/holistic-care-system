
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Eye, Edit, BarChart3, Mail, Trash2 } from "lucide-react";

interface Paciente {
  id: string;
  numeroHistoria: string;
  nombre: string;
  apellidos: string;
  dni: string;
  fechaNacimiento: string;
  sexo: string;
  telefono: string;
  email: string;
  fechaAlta: string;
  activo: boolean;
  foto?: string;
}

interface PacientesTableProps {
  pacientes: Paciente[];
  onEdit: (paciente: Paciente) => void;
  onDelete: (paciente: Paciente) => void;
  onView: (paciente: Paciente) => void;
}

const PacientesTable = ({ pacientes, onEdit, onDelete, onView }: PacientesTableProps) => {
  return (
    <Card>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow className="bg-cyan-600 hover:bg-cyan-600">
              <TableHead className="text-white font-semibold">Historia</TableHead>
              <TableHead className="text-white font-semibold">Paciente</TableHead>
              <TableHead className="text-white font-semibold">Alta</TableHead>
              <TableHead className="text-white font-semibold">Opciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {pacientes.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8 text-gray-500">
                  No se encontraron pacientes
                </TableCell>
              </TableRow>
            ) : (
              pacientes.map((paciente) => (
                <TableRow key={paciente.id} className="hover:bg-gray-50">
                  <TableCell className="font-mono text-sm">{paciente.numeroHistoria}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      {paciente.foto && (
                        <img 
                          src={paciente.foto} 
                          alt="Paciente" 
                          className="w-8 h-8 rounded-full object-cover"
                        />
                      )}
                      <span 
                        className="text-cyan-600 font-medium cursor-pointer hover:underline"
                        onClick={() => onView(paciente)}
                      >
                        {paciente.apellidos}, {paciente.nombre}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>{paciente.fechaAlta}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-8 w-8 p-0"
                        onClick={() => onView(paciente)}
                        title="Ver paciente"
                      >
                        <Eye size={16} className="text-gray-600" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-8 w-8 p-0"
                        onClick={() => onEdit(paciente)}
                        title="Editar paciente"
                      >
                        <Edit size={16} className="text-gray-600" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Estadísticas">
                        <BarChart3 size={16} className="text-gray-600" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Enviar email">
                        <Mail size={16} className="text-gray-600" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-8 w-8 p-0"
                        onClick={() => onDelete(paciente)}
                        title="Eliminar paciente"
                      >
                        <Trash2 size={16} className="text-red-600" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default PacientesTable;
