
import React from 'react';
import { Button } from "@/components/ui/button";
import { Dialog, DialogTrigger } from "@/components/ui/dialog";
import { Plus } from "lucide-react";

interface FarmaciaHeaderProps {
  showNewMedicamentoDialog: boolean;
  setShowNewMedicamentoDialog: (show: boolean) => void;
}

const FarmaciaHeader = ({ showNewMedicamentoDialog, setShowNewMedicamentoDialog }: FarmaciaHeaderProps) => {
  return (
    <>
      {/* Breadcrumb */}
      <div className="text-sm text-gray-600 mb-4">
        <span className="text-cyan-600">Gestión médica</span> / <span>Farmacia</span>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Farmacia</h1>
          <Dialog open={showNewMedicamentoDialog} onOpenChange={setShowNewMedicamentoDialog}>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
                <Plus size={16} />
              </Button>
            </DialogTrigger>
          </Dialog>
        </div>
      </div>
    </>
  );
};

export default FarmaciaHeader;
