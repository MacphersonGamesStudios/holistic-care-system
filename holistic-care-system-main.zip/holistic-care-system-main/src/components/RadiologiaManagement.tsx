
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Image, Calendar, Clock, FileText } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import RadiologiaTable from './RadiologiaTable';
import NuevoEstudioForm from './NuevoEstudioForm';

interface EstudioRadiologico {
  id: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  tipoEstudio: string;
  fechaSolicitud: string;
  fechaRealizacion?: string;
  medicoSolicitante: string;
  radiologo?: string;
  estado: 'solicitado' | 'programado' | 'realizado' | 'informado';
  prioridad: 'baja' | 'normal' | 'alta' | 'urgente';
  indicacion: string;
  hallazgos?: string;
  conclusion?: string;
  observaciones?: string;
}

const RadiologiaManagement = () => {
  const [estudios, setEstudios] = useState<EstudioRadiologico[]>([]);
  const [filteredEstudios, setFilteredEstudios] = useState<EstudioRadiologico[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEstado, setSelectedEstado] = useState('todos');
  const [selectedTipo, setSelectedTipo] = useState('todos');
  const [showNewEstudioDialog, setShowNewEstudioDialog] = useState(false);

  useEffect(() => {
    const savedEstudios = localStorage.getItem('hospitalRadiologia');
    if (savedEstudios) {
      const data = JSON.parse(savedEstudios);
      setEstudios(data);
      setFilteredEstudios(data);
    } else {
      // Datos de ejemplo
      const ejemploData: EstudioRadiologico[] = [
        {
          id: '1',
          pacienteId: '1',
          pacienteNombre: 'García López, Juan Carlos',
          numeroHistoria: 'HST001',
          tipoEstudio: 'Radiografía de Tórax',
          fechaSolicitud: '2024-05-20',
          fechaRealizacion: '2024-05-20',
          medicoSolicitante: 'Dr. Martínez',
          radiologo: 'Dra. Rodríguez',
          estado: 'informado',
          prioridad: 'alta',
          indicacion: 'Sospecha de neumonía',
          hallazgos: 'Infiltrado en lóbulo inferior derecho',
          conclusion: 'Neumonía bacteriana'
        },
        {
          id: '2',
          pacienteId: '2',
          pacienteNombre: 'Rodríguez Pérez, María Isabel',
          numeroHistoria: 'HST002',
          tipoEstudio: 'Tomografía de Abdomen',
          fechaSolicitud: '2024-05-22',
          medicoSolicitante: 'Dr. González',
          estado: 'programado',
          prioridad: 'normal',
          indicacion: 'Dolor abdominal crónico'
        }
      ];
      setEstudios(ejemploData);
      setFilteredEstudios(ejemploData);
      localStorage.setItem('hospitalRadiologia', JSON.stringify(ejemploData));
    }
  }, []);

  useEffect(() => {
    let filtered = estudios;

    // Filtrar por estado
    if (selectedEstado !== 'todos') {
      filtered = filtered.filter(e => e.estado === selectedEstado);
    }

    // Filtrar por tipo de estudio
    if (selectedTipo !== 'todos') {
      filtered = filtered.filter(e => e.tipoEstudio === selectedTipo);
    }

    // Filtrar por búsqueda
    if (searchTerm) {
      filtered = filtered.filter(e => 
        e.pacienteNombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.numeroHistoria.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.tipoEstudio.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.medicoSolicitante.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredEstudios(filtered);
  }, [estudios, searchTerm, selectedEstado, selectedTipo]);

  const handleNewEstudio = (estudioData: any) => {
    const newEstudio: EstudioRadiologico = {
      id: Date.now().toString(),
      ...estudioData,
      fechaSolicitud: estudioData.fechaSolicitud || new Date().toISOString().split('T')[0],
      estado: 'solicitado'
    };

    const updatedEstudios = [...estudios, newEstudio];
    setEstudios(updatedEstudios);
    localStorage.setItem('hospitalRadiologia', JSON.stringify(updatedEstudios));
    
    toast({
      title: "Estudio radiológico solicitado",
      description: `Se ha solicitado ${estudioData.tipoEstudio} para ${estudioData.pacienteNombre}`,
    });
    
    setShowNewEstudioDialog(false);
  };

  const handleUpdateEstudio = (id: string, data: Partial<EstudioRadiologico>) => {
    const updatedEstudios = estudios.map(e => 
      e.id === id ? { ...e, ...data } : e
    );
    
    setEstudios(updatedEstudios);
    localStorage.setItem('hospitalRadiologia', JSON.stringify(updatedEstudios));
    
    toast({
      title: "Estudio actualizado",
      description: "Los datos se han actualizado correctamente",
    });
  };

  // Estadísticas
  const estadisticas = {
    solicitados: estudios.filter(e => e.estado === 'solicitado').length,
    programados: estudios.filter(e => e.estado === 'programado').length,
    realizados: estudios.filter(e => e.estado === 'realizado').length,
    informados: estudios.filter(e => e.estado === 'informado').length,
    urgentes: estudios.filter(e => e.prioridad === 'urgente').length,
    hoy: estudios.filter(e => e.fechaSolicitud === new Date().toISOString().split('T')[0]).length
  };

  return (
    <div className="p-6 space-y-6">
      {/* Breadcrumb */}
      <div className="text-sm text-gray-600 mb-4">
        <span className="text-cyan-600">Gestión médica</span> / <span>Radiología</span>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Radiología</h1>
          <Dialog open={showNewEstudioDialog} onOpenChange={setShowNewEstudioDialog}>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
                <Plus size={16} />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Nuevo Estudio Radiológico</DialogTitle>
              </DialogHeader>
              <NuevoEstudioForm 
                onSave={handleNewEstudio} 
                onCancel={() => setShowNewEstudioDialog(false)} 
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Solicitados</CardTitle>
            <FileText className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.solicitados}</div>
            <p className="text-xs text-muted-foreground">Pendientes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Programados</CardTitle>
            <Calendar className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.programados}</div>
            <p className="text-xs text-muted-foreground">En agenda</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Realizados</CardTitle>
            <Image className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.realizados}</div>
            <p className="text-xs text-muted-foreground">Sin informar</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Informados</CardTitle>
            <FileText className="h-4 w-4 text-cyan-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.informados}</div>
            <p className="text-xs text-muted-foreground">Completados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Urgentes</CardTitle>
            <Clock className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.urgentes}</div>
            <p className="text-xs text-muted-foreground">Alta prioridad</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Hoy</CardTitle>
            <Calendar className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.hoy}</div>
            <p className="text-xs text-muted-foreground">Solicitados hoy</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="buscar">Buscar</Label>
              <div className="relative mt-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="buscar"
                  placeholder="Buscar por paciente, historia, estudio..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="estado">Estado</Label>
              <Select value={selectedEstado} onValueChange={setSelectedEstado}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos</SelectItem>
                  <SelectItem value="solicitado">Solicitados</SelectItem>
                  <SelectItem value="programado">Programados</SelectItem>
                  <SelectItem value="realizado">Realizados</SelectItem>
                  <SelectItem value="informado">Informados</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="tipo">Tipo de Estudio</Label>
              <Select value={selectedTipo} onValueChange={setSelectedTipo}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Todos los estudios" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos</SelectItem>
                  <SelectItem value="Radiografía de Tórax">Radiografía de Tórax</SelectItem>
                  <SelectItem value="Tomografía de Abdomen">Tomografía de Abdomen</SelectItem>
                  <SelectItem value="Resonancia Magnética">Resonancia Magnética</SelectItem>
                  <SelectItem value="Ecografía">Ecografía</SelectItem>
                  <SelectItem value="Mamografía">Mamografía</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => {
                  setSearchTerm('');
                  setSelectedEstado('todos');
                  setSelectedTipo('todos');
                }}
              >
                Limpiar filtros
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Estudios Table */}
      <RadiologiaTable 
        estudios={filteredEstudios}
        onUpdate={handleUpdateEstudio}
      />
    </div>
  );
};

export default RadiologiaManagement;
