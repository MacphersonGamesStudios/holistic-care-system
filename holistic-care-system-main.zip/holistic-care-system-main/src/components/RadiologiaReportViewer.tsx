
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Save, Download, Printer } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface EstudioRadiologico {
  id: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  tipoEstudio: string;
  fechaSolicitud: string;
  fechaRealizacion?: string;
  medicoSolicitante: string;
  radiologo?: string;
  estado: 'solicitado' | 'programado' | 'realizado' | 'informado';
  prioridad: 'baja' | 'normal' | 'alta' | 'urgente';
  indicacion: string;
  hallazgos?: string;
  conclusion?: string;
  observaciones?: string;
}

interface RadiologiaReportViewerProps {
  estudio: EstudioRadiologico;
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Partial<EstudioRadiologico>) => void;
}

const RadiologiaReportViewer = ({ estudio, isOpen, onClose, onSave }: RadiologiaReportViewerProps) => {
  const [formData, setFormData] = useState({
    hallazgos: estudio.hallazgos || '',
    conclusion: estudio.conclusion || '',
    observaciones: estudio.observaciones || '',
    radiologo: estudio.radiologo || '',
    fechaRealizacion: estudio.fechaRealizacion || new Date().toISOString().split('T')[0],
    estado: estudio.estado
  });

  const handleSave = () => {
    const updatedData = {
      ...formData,
      estado: formData.hallazgos && formData.conclusion ? 'informado' as const : 'realizado' as const
    };
    
    onSave(updatedData);
    
    toast({
      title: "Informe guardado",
      description: "El informe radiológico se ha guardado correctamente",
    });
  };

  const handlePrint = () => {
    const printContent = `
      <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px;">
        <h1 style="text-align: center; color: #0891b2;">INFORME RADIOLÓGICO</h1>
        
        <div style="margin: 20px 0;">
          <h3>Datos del Paciente</h3>
          <p><strong>Nombre:</strong> ${estudio.pacienteNombre}</p>
          <p><strong>Historia Clínica:</strong> ${estudio.numeroHistoria}</p>
          <p><strong>Fecha de Solicitud:</strong> ${estudio.fechaSolicitud}</p>
          <p><strong>Fecha de Realización:</strong> ${formData.fechaRealizacion}</p>
        </div>
        
        <div style="margin: 20px 0;">
          <h3>Estudio</h3>
          <p><strong>Tipo:</strong> ${estudio.tipoEstudio}</p>
          <p><strong>Médico Solicitante:</strong> ${estudio.medicoSolicitante}</p>
          <p><strong>Radiólogo:</strong> ${formData.radiologo}</p>
          <p><strong>Indicación:</strong> ${estudio.indicacion}</p>
        </div>
        
        <div style="margin: 20px 0;">
          <h3>Hallazgos</h3>
          <p style="white-space: pre-wrap;">${formData.hallazgos}</p>
        </div>
        
        <div style="margin: 20px 0;">
          <h3>Conclusión</h3>
          <p style="white-space: pre-wrap;">${formData.conclusion}</p>
        </div>
        
        ${formData.observaciones ? `
        <div style="margin: 20px 0;">
          <h3>Observaciones</h3>
          <p style="white-space: pre-wrap;">${formData.observaciones}</p>
        </div>
        ` : ''}
        
        <div style="margin-top: 40px; text-align: right;">
          <p>_________________________</p>
          <p><strong>Dr./Dra. ${formData.radiologo}</strong></p>
          <p>Radiólogo</p>
        </div>
      </div>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Informe Radiológico - {estudio.tipoEstudio}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Información del paciente */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium mb-2">Información del Paciente</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Paciente:</span> {estudio.pacienteNombre}
              </div>
              <div>
                <span className="font-medium">Historia:</span> {estudio.numeroHistoria}
              </div>
              <div>
                <span className="font-medium">Médico Solicitante:</span> {estudio.medicoSolicitante}
              </div>
              <div>
                <span className="font-medium">Indicación:</span> {estudio.indicacion}
              </div>
            </div>
          </div>

          {/* Formulario del informe */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="radiologo">Radiólogo</Label>
              <Input
                id="radiologo"
                value={formData.radiologo}
                onChange={(e) => setFormData(prev => ({ ...prev, radiologo: e.target.value }))}
                placeholder="Nombre del radiólogo"
              />
            </div>
            <div>
              <Label htmlFor="fechaRealizacion">Fecha de Realización</Label>
              <Input
                id="fechaRealizacion"
                type="date"
                value={formData.fechaRealizacion}
                onChange={(e) => setFormData(prev => ({ ...prev, fechaRealizacion: e.target.value }))}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="hallazgos">Hallazgos</Label>
            <Textarea
              id="hallazgos"
              value={formData.hallazgos}
              onChange={(e) => setFormData(prev => ({ ...prev, hallazgos: e.target.value }))}
              placeholder="Descripción detallada de los hallazgos radiológicos..."
              className="min-h-[120px]"
            />
          </div>

          <div>
            <Label htmlFor="conclusion">Conclusión</Label>
            <Textarea
              id="conclusion"
              value={formData.conclusion}
              onChange={(e) => setFormData(prev => ({ ...prev, conclusion: e.target.value }))}
              placeholder="Conclusión diagnóstica..."
              className="min-h-[80px]"
            />
          </div>

          <div>
            <Label htmlFor="observaciones">Observaciones</Label>
            <Textarea
              id="observaciones"
              value={formData.observaciones}
              onChange={(e) => setFormData(prev => ({ ...prev, observaciones: e.target.value }))}
              placeholder="Observaciones adicionales (opcional)..."
              className="min-h-[60px]"
            />
          </div>

          {/* Botones de acción */}
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="flex items-center gap-2">
              <Button onClick={handlePrint} variant="outline" size="sm">
                <Printer size={16} className="mr-2" />
                Imprimir
              </Button>
              <Button variant="outline" size="sm">
                <Download size={16} className="mr-2" />
                Exportar PDF
              </Button>
            </div>
            <div className="flex items-center gap-2">
              <Button onClick={onClose} variant="outline">
                Cancelar
              </Button>
              <Button onClick={handleSave} className="bg-cyan-600 hover:bg-cyan-700">
                <Save size={16} className="mr-2" />
                Guardar Informe
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default RadiologiaReportViewer;
