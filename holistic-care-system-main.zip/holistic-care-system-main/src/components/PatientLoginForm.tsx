
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Eye, EyeOff, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";

const PatientLoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast({
        title: "Error de acceso",
        description: "Por favor, complete todos los campos",
        variant: "destructive",
      });
      return;
    }

    // Verificar en pacientes registrados
    const registeredPatients = JSON.parse(localStorage.getItem('hospitalPatients') || '[]');
    const patient = registeredPatients.find((p: any) => 
      p.email === email && p.password === password && p.activo
    );

    if (patient) {
      localStorage.setItem('patientUser', JSON.stringify({
        id: patient.id,
        username: `${patient.nombre} ${patient.apellidos}`,
        email: patient.email,
        role: 'patient',
        patientData: patient
      }));

      toast({
        title: "Acceso exitoso",
        description: `Bienvenido ${patient.nombre} ${patient.apellidos}`,
      });

      navigate('/patient-portal');
      return;
    }

    toast({
      title: "Error de acceso",
      description: "Email o contraseña incorrectos",
      variant: "destructive",
    });
  };

  return (
    <div className="min-h-screen hospital-gradient flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-white/95 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => navigate('/')}
              className="text-cyan-600 hover:bg-cyan-50"
            >
              <ArrowLeft size={20} />
            </Button>
            <div className="bg-cyan-600 text-white px-4 py-2 rounded-md inline-flex items-center gap-2">
              <span className="font-bold">DASI</span>
              <span className="bg-white text-cyan-600 px-2 py-1 rounded text-sm font-semibold">eCLINIC</span>
            </div>
          </div>
          <CardTitle className="text-2xl text-center text-gray-800">Portal del Paciente</CardTitle>
          <p className="text-center text-gray-600">Acceso para pacientes registrados</p>
        </CardHeader>

        <CardContent className="p-8">
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <Input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-12 text-base border-gray-300 focus:border-cyan-500"
              />
            </div>

            <div className="relative">
              <Input
                type={showPassword ? "text" : "password"}
                placeholder="Contraseña"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full h-12 text-base border-gray-300 focus:border-cyan-500 pr-12"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 bg-green-600 hover:bg-green-700 text-white font-semibold text-base"
            >
              Acceder al Portal
            </Button>
          </form>

          <div className="mt-6 text-center space-y-4">
            <div className="border-t pt-4">
              <p className="text-sm text-gray-600 mb-3">¿No tienes cuenta?</p>
              <Button
                onClick={() => navigate('/register-patient')}
                variant="outline"
                className="w-full h-12 border-green-600 text-green-600 hover:bg-green-50"
              >
                Registrarse como Paciente
              </Button>
            </div>

            <div className="text-center space-y-2 text-sm">
              <a href="#" className="text-cyan-600 hover:text-cyan-700 block">Recuperar contraseña</a>
              <Button
                type="button"
                variant="link"
                onClick={() => navigate('/')}
                className="text-cyan-600 hover:text-cyan-700"
              >
                Volver al login principal
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PatientLoginForm;
