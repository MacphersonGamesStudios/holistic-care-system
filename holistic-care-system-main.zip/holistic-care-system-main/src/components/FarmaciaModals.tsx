
import React from 'react';
import { Medicamento } from '@/hooks/useFarmaciaData';
import MedicamentoFormModal from './MedicamentoFormModal';
import MedicamentoViewModal from './MedicamentoViewModal';
import VentaModal from './VentaModal';

interface FarmaciaModalsProps {
  showNewMedicamentoDialog: boolean;
  setShowNewMedicamentoDialog: (show: boolean) => void;
  showEditMedicamentoDialog: boolean;
  setShowEditMedicamentoDialog: (show: boolean) => void;
  showViewMedicamentoDialog: boolean;
  setShowViewMedicamentoDialog: (show: boolean) => void;
  showVentaDialog: boolean;
  setShowVentaDialog: (show: boolean) => void;
  selectedMedicamento: Medicamento | null;
  onNewMedicamento: (data: any) => void;
  onEditMedicamento: (data: any) => void;
  onVentaMedicamento: (cantidad: number) => void;
}

const FarmaciaModals = ({
  showNewMedicamentoDialog,
  setShowNewMedicamentoDialog,
  showEditMedicamentoDialog,
  setShowEditMedicamentoDialog,
  showViewMedicamentoDialog,
  setShowViewMedicamentoDialog,
  showVentaDialog,
  setShowVentaDialog,
  selectedMedicamento,
  onNewMedicamento,
  onEditMedicamento,
  onVentaMedicamento
}: FarmaciaModalsProps) => {
  return (
    <>
      <MedicamentoFormModal
        isOpen={showNewMedicamentoDialog}
        onClose={() => setShowNewMedicamentoDialog(false)}
        onSubmit={onNewMedicamento}
        title="Nuevo Medicamento"
      />

      <MedicamentoFormModal
        isOpen={showEditMedicamentoDialog}
        onClose={() => setShowEditMedicamentoDialog(false)}
        onSubmit={onEditMedicamento}
        title="Editar Medicamento"
        editData={selectedMedicamento}
      />

      <MedicamentoViewModal
        isOpen={showViewMedicamentoDialog}
        onClose={() => setShowViewMedicamentoDialog(false)}
        medicamento={selectedMedicamento}
      />

      <VentaModal
        isOpen={showVentaDialog}
        onClose={() => setShowVentaDialog(false)}
        medicamento={selectedMedicamento}
        onSubmit={onVentaMedicamento}
      />
    </>
  );
};

export default FarmaciaModals;
