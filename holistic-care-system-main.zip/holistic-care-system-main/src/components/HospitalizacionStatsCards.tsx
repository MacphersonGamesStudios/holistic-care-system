
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { User, Bed, Clock } from "lucide-react";
import { Hospitalizacion } from '../types/hospitalizacion';

interface HospitalizacionStatsCardsProps {
  hospitalizaciones: Hospitalizacion[];
}

const HospitalizacionStatsCards = ({ hospitalizaciones }: HospitalizacionStatsCardsProps) => {
  const habitacionesOcupadas = hospitalizaciones
    .filter(h => h.estado === 'ingresado')
    .length;

  const habitacionesDisponibles = 50 - habitacionesOcupadas;

  const ingresosHoy = hospitalizaciones.filter(h => 
    h.fechaIngreso === new Date().toISOString().split('T')[0]
  ).length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Pacientes Ingresados</CardTitle>
          <User className="h-4 w-4 text-cyan-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{habitacionesOcupadas}</div>
          <p className="text-xs text-muted-foreground">Actualmente hospitalizados</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Habitaciones Ocupadas</CardTitle>
          <Bed className="h-4 w-4 text-orange-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{habitacionesOcupadas}</div>
          <p className="text-xs text-muted-foreground">de 50 disponibles</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Habitaciones Libres</CardTitle>
          <Bed className="h-4 w-4 text-green-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{habitacionesDisponibles}</div>
          <p className="text-xs text-muted-foreground">Disponibles ahora</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Ingresos Hoy</CardTitle>
          <Clock className="h-4 w-4 text-blue-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{ingresosHoy}</div>
          <p className="text-xs text-muted-foreground">Nuevos ingresos</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default HospitalizacionStatsCards;
