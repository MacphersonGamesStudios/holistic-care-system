
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Search } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface NuevaHospitalizacionFormProps {
  onSave: (data: any) => void;
  onCancel: () => void;
}

const NuevaHospitalizacionForm = ({ onSave, onCancel }: NuevaHospitalizacionFormProps) => {
  const [formData, setFormData] = useState({
    pacienteId: '',
    pacienteNombre: '',
    numeroHistoria: '',
    habitacion: '',
    cama: '',
    fechaIngreso: new Date().toISOString().split('T')[0],
    medicoResponsable: '',
    diagnostico: '',
    observaciones: '',
    tipoIngreso: 'programado'
  });

  const [pacientes, setPacientes] = useState<any[]>([]);
  const [searchPaciente, setSearchPaciente] = useState('');
  const [showPacientesList, setShowPacientesList] = useState(false);

  useEffect(() => {
    const savedPacientes = localStorage.getItem('hospitalPatients');
    if (savedPacientes) {
      setPacientes(JSON.parse(savedPacientes));
    }
  }, []);

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePacienteSearch = (searchTerm: string) => {
    setSearchPaciente(searchTerm);
    setShowPacientesList(searchTerm.length > 0);
  };

  const handleSelectPaciente = (paciente: any) => {
    setFormData(prev => ({
      ...prev,
      pacienteId: paciente.id,
      pacienteNombre: `${paciente.apellidos}, ${paciente.nombre}`,
      numeroHistoria: paciente.numeroHistoria
    }));
    setSearchPaciente(`${paciente.apellidos}, ${paciente.nombre}`);
    setShowPacientesList(false);
  };

  const filteredPacientes = pacientes.filter(p => 
    p.nombre.toLowerCase().includes(searchPaciente.toLowerCase()) ||
    p.apellidos.toLowerCase().includes(searchPaciente.toLowerCase()) ||
    p.numeroHistoria.toLowerCase().includes(searchPaciente.toLowerCase())
  );

  const handleSubmit = () => {
    if (!formData.pacienteId || !formData.habitacion || !formData.cama || !formData.medicoResponsable || !formData.diagnostico) {
      toast({
        title: "Error",
        description: "Por favor, complete todos los campos obligatorios",
        variant: "destructive",
      });
      return;
    }

    onSave(formData);
  };

  return (
    <div className="space-y-6 p-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Información del Paciente */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Información del Paciente</h3>
          
          <div className="relative">
            <Label htmlFor="paciente">Buscar Paciente *</Label>
            <div className="relative mt-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                id="paciente"
                placeholder="Buscar por nombre, apellidos o historia..."
                value={searchPaciente}
                onChange={(e) => handlePacienteSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            
            {showPacientesList && filteredPacientes.length > 0 && (
              <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-y-auto">
                {filteredPacientes.slice(0, 10).map((paciente) => (
                  <div
                    key={paciente.id}
                    className="p-3 hover:bg-gray-100 cursor-pointer border-b"
                    onClick={() => handleSelectPaciente(paciente)}
                  >
                    <div className="font-medium">{paciente.apellidos}, {paciente.nombre}</div>
                    <div className="text-sm text-gray-500">
                      Historia: {paciente.numeroHistoria} | DNI: {paciente.dni}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <Label htmlFor="numeroHistoria">Número de Historia</Label>
            <Input
              id="numeroHistoria"
              value={formData.numeroHistoria}
              disabled
              className="mt-1 bg-gray-100"
            />
          </div>

          <div>
            <Label htmlFor="fechaIngreso">Fecha de Ingreso *</Label>
            <Input
              id="fechaIngreso"
              type="date"
              value={formData.fechaIngreso}
              onChange={(e) => handleInputChange('fechaIngreso', e.target.value)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="tipoIngreso">Tipo de Ingreso *</Label>
            <Select value={formData.tipoIngreso} onValueChange={(value) => handleInputChange('tipoIngreso', value)}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="urgencia">Urgencia</SelectItem>
                <SelectItem value="programado">Programado</SelectItem>
                <SelectItem value="traslado">Traslado</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Información de Hospitalización */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Información de Hospitalización</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="habitacion">Habitación *</Label>
              <Select value={formData.habitacion} onValueChange={(value) => handleInputChange('habitacion', value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Seleccionar habitación" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="101">101</SelectItem>
                  <SelectItem value="102">102</SelectItem>
                  <SelectItem value="103">103</SelectItem>
                  <SelectItem value="104">104</SelectItem>
                  <SelectItem value="201">201</SelectItem>
                  <SelectItem value="202">202</SelectItem>
                  <SelectItem value="203">203</SelectItem>
                  <SelectItem value="204">204</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="cama">Cama *</Label>
              <Select value={formData.cama} onValueChange={(value) => handleInputChange('cama', value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Seleccionar cama" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A">A</SelectItem>
                  <SelectItem value="B">B</SelectItem>
                  <SelectItem value="C">C</SelectItem>
                  <SelectItem value="D">D</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="medicoResponsable">Médico Responsable *</Label>
            <Select value={formData.medicoResponsable} onValueChange={(value) => handleInputChange('medicoResponsable', value)}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Seleccionar médico" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Dr. Martínez">Dr. Martínez</SelectItem>
                <SelectItem value="Dra. González">Dra. González</SelectItem>
                <SelectItem value="Dr. López">Dr. López</SelectItem>
                <SelectItem value="Dra. Rodríguez">Dra. Rodríguez</SelectItem>
                <SelectItem value="Dr. García">Dr. García</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="diagnostico">Diagnóstico *</Label>
            <Input
              id="diagnostico"
              value={formData.diagnostico}
              onChange={(e) => handleInputChange('diagnostico', e.target.value)}
              placeholder="Diagnóstico principal"
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="observaciones">Observaciones</Label>
            <Textarea
              id="observaciones"
              value={formData.observaciones}
              onChange={(e) => handleInputChange('observaciones', e.target.value)}
              placeholder="Observaciones adicionales..."
              className="mt-1"
              rows={4}
            />
          </div>
        </div>
      </div>

      {/* Footer buttons */}
      <div className="flex justify-end gap-2 pt-4 border-t">
        <Button variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button onClick={handleSubmit} className="bg-cyan-600 hover:bg-cyan-700">
          Registrar Hospitalización
        </Button>
      </div>
    </div>
  );
};

export default NuevaHospitalizacionForm;
