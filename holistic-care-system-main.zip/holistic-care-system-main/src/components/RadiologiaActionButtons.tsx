
import React from 'react';
import { Button } from "@/components/ui/button";
import { Eye, Edit, Image, FileText } from "lucide-react";

interface EstudioRadiologico {
  id: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  tipoEstudio: string;
  fechaSolicitud: string;
  fechaRealizacion?: string;
  medicoSolicitante: string;
  radiologo?: string;
  estado: 'solicitado' | 'programado' | 'realizado' | 'informado';
  prioridad: 'baja' | 'normal' | 'alta' | 'urgente';
  indicacion: string;
  hallazgos?: string;
  conclusion?: string;
  observaciones?: string;
}

interface RadiologiaActionButtonsProps {
  estudio: EstudioRadiologico;
  onViewDetails: (estudio: EstudioRadiologico) => void;
  onEdit: (estudio: EstudioRadiologico) => void;
  onViewImages: (estudio: EstudioRadiologico) => void;
  onViewReport: (estudio: EstudioRadiologico) => void;
}

const RadiologiaActionButtons = ({
  estudio,
  onViewDetails,
  onEdit,
  onViewImages,
  onViewReport
}: RadiologiaActionButtonsProps) => {
  return (
    <div className="flex items-center gap-2">
      <Button 
        size="sm" 
        variant="ghost" 
        className="h-8 w-8 p-0"
        onClick={() => onViewDetails(estudio)}
        title="Ver detalles"
      >
        <Eye size={16} className="text-gray-600" />
      </Button>
      <Button 
        size="sm" 
        variant="ghost" 
        className="h-8 w-8 p-0"
        onClick={() => onEdit(estudio)}
        title="Editar"
      >
        <Edit size={16} className="text-gray-600" />
      </Button>
      <Button 
        size="sm" 
        variant="ghost" 
        className="h-8 w-8 p-0"
        onClick={() => onViewImages(estudio)}
        title="Ver imágenes"
      >
        <Image size={16} className="text-gray-600" />
      </Button>
      <Button 
        size="sm" 
        variant="ghost" 
        className="h-8 w-8 p-0"
        onClick={() => onViewReport(estudio)}
        title="Informe"
      >
        <FileText size={16} className="text-gray-600" />
      </Button>
    </div>
  );
};

export default RadiologiaActionButtons;
