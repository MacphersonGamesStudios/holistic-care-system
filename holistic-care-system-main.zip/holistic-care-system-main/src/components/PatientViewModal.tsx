
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import PacienteDetails from './PacienteDetails';

interface Paciente {
  id: string;
  numeroHistoria: string;
  nombre: string;
  apellidos: string;
  dni: string;
  fechaNacimiento: string;
  sexo: string;
  telefono: string;
  email: string;
  fechaAlta: string;
  activo: boolean;
  foto?: string;
  direccion?: string;
  codigoPostal?: string;
  provincia?: string;
  poblacion?: string;
  observaciones?: string;
}

interface PatientViewModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  paciente: Paciente | null;
  onEdit: () => void;
  onClose: () => void;
}

const PatientViewModal = ({
  open,
  onOpenChange,
  paciente,
  onEdit,
  onClose
}: PatientViewModalProps) => {
  const handleEdit = () => {
    onEdit();
    onOpenChange(false);
  };

  const handleClose = () => {
    onClose();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Información del paciente</DialogTitle>
        </DialogHeader>
        {paciente && (
          <PacienteDetails 
            paciente={paciente}
            onEdit={handleEdit}
            onClose={handleClose}
          />
        )}
      </DialogContent>
    </Dialog>
  );
};

export default PatientViewModal;
