
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import EstudioRadiologicoDetails from './EstudioRadiologicoDetails';
import EditarEstudioForm from './EditarEstudioForm';
import RadiologiaImageViewer from './RadiologiaImageViewer';
import RadiologiaReportViewer from './RadiologiaReportViewer';

interface EstudioRadiologico {
  id: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  tipoEstudio: string;
  fechaSolicitud: string;
  fechaRealizacion?: string;
  medicoSolicitante: string;
  radiologo?: string;
  estado: 'solicitado' | 'programado' | 'realizado' | 'informado';
  prioridad: 'baja' | 'normal' | 'alta' | 'urgente';
  indicacion: string;
  hallazgos?: string;
  conclusion?: string;
  observaciones?: string;
}

interface RadiologiaModalsProps {
  selectedEstudio: EstudioRadiologico | null;
  modalType: 'details' | 'edit' | 'images' | 'report' | null;
  onCloseModal: () => void;
  onSaveEdit: (data: Partial<EstudioRadiologico>) => void;
}

const RadiologiaModals = ({
  selectedEstudio,
  modalType,
  onCloseModal,
  onSaveEdit
}: RadiologiaModalsProps) => {
  return (
    <>
      {/* Modal principal para details y edit */}
      {(modalType === 'details' || modalType === 'edit') && (
        <Dialog open={true} onOpenChange={onCloseModal}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {modalType === 'details' && 'Detalles del Estudio Radiológico'}
                {modalType === 'edit' && 'Editar Estudio Radiológico'}
              </DialogTitle>
            </DialogHeader>
            {selectedEstudio && (
              <>
                {modalType === 'details' && (
                  <EstudioRadiologicoDetails 
                    estudio={selectedEstudio} 
                    onClose={onCloseModal}
                  />
                )}
                {modalType === 'edit' && (
                  <EditarEstudioForm 
                    estudio={selectedEstudio}
                    onSave={onSaveEdit}
                    onCancel={onCloseModal}
                  />
                )}
              </>
            )}
          </DialogContent>
        </Dialog>
      )}

      {/* Modal separado para imágenes - solo se abre cuando modalType === 'images' */}
      {selectedEstudio && modalType === 'images' && (
        <RadiologiaImageViewer
          estudioId={selectedEstudio.id}
          isOpen={true}
          onClose={onCloseModal}
        />
      )}

      {/* Modal separado para informes - solo se abre cuando modalType === 'report' */}
      {selectedEstudio && modalType === 'report' && (
        <RadiologiaReportViewer
          estudio={selectedEstudio}
          isOpen={true}
          onClose={onCloseModal}
          onSave={onSaveEdit}
        />
      )}
    </>
  );
};

export default RadiologiaModals;
