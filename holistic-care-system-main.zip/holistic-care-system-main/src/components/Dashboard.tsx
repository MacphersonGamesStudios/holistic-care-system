
import React from 'react';
import { useNavigate } from 'react-router-dom';
import ModuleCard from './ModuleCard';
import { 
  Calendar, 
  Stethoscope, 
  FileText, 
  Users, 
  Building, 
  UserCog,
  BarChart3,
  Heart,
  Pill,
  Image,
  TestTube,
  Shield,
  UserCheck,
  Briefcase
} from 'lucide-react';

const Dashboard = () => {
  const navigate = useNavigate();

  const modules = [
    {
      title: "Portal del Paciente",
      icon: UserCheck,
      color: "bg-gradient-to-br from-emerald-500 to-emerald-600",
      path: "/patient-portal"
    },
    {
      title: "Portal del Empleado",
      icon: Briefcase,
      color: "bg-gradient-to-br from-blue-500 to-blue-600",
      path: "/employee-portal"
    },
    {
      title: "Administrador",
      icon: Shield,
      color: "bg-gradient-to-br from-red-500 to-red-600",
      path: "/admin"
    },
    {
      title: "Agenda clínica",
      icon: Calendar,
      color: "bg-gradient-to-br from-green-500 to-green-600",
      path: "/agenda"
    },
    {
      title: "Gestión de la visita",
      icon: Stethoscope,
      color: "bg-gradient-to-br from-cyan-500 to-cyan-600",
      path: "/visitas"
    },
    {
      title: "Facturación",
      icon: FileText,
      color: "bg-gradient-to-br from-amber-500 to-amber-600",
      path: "/facturacion"
    },
    {
      title: "Pacientes",
      icon: Users,
      color: "bg-gradient-to-br from-orange-500 to-orange-600",
      path: "/pacientes"
    },
    {
      title: "Clientes/Tutores",
      icon: UserCog,
      color: "bg-gradient-to-br from-purple-500 to-purple-600",
      path: "/clientes"
    },
    {
      title: "Contabilidad diaria",
      icon: Building,
      color: "bg-gradient-to-br from-gray-500 to-gray-600",
      path: "/contabilidad"
    },
    {
      title: "Listados Estadísticos",
      icon: BarChart3,
      color: "bg-gradient-to-br from-indigo-500 to-indigo-600",
      path: "/estadisticas"
    },
    {
      title: "Hospitalización",
      icon: Heart,
      color: "bg-gradient-to-br from-pink-500 to-pink-600",
      path: "/hospitalizacion"
    },
    {
      title: "Farmacia",
      icon: Pill,
      color: "bg-gradient-to-br from-teal-500 to-teal-600",
      path: "/farmacia"
    },
    {
      title: "Radiología",
      icon: Image,
      color: "bg-gradient-to-br from-yellow-500 to-yellow-600",
      path: "/radiologia"
    },
    {
      title: "Laboratorio",
      icon: TestTube,
      color: "bg-gradient-to-br from-lime-500 to-lime-600",
      path: "/laboratorio"
    }
  ];

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-800">Gestión médica</h1>
        <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
          <span className="text-gray-600 text-sm">?</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {modules.map((module, index) => (
          <ModuleCard
            key={index}
            title={module.title}
            icon={module.icon}
            color={module.color}
            onClick={() => navigate(module.path)}
          />
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
