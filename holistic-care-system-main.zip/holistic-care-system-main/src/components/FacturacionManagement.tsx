
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DollarSign, FileText, CreditCard, AlertCircle, Plus, Search, Eye, Download } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";

interface Factura {
  id: string;
  numero: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  fecha: string;
  fechaVencimiento: string;
  conceptos: ConceptoFactura[];
  subtotal: number;
  impuestos: number;
  total: number;
  estado: 'pendiente' | 'pagada' | 'vencida' | 'anulada';
  metodoPago?: string;
  observaciones?: string;
}

interface ConceptoFactura {
  id: string;
  descripcion: string;
  cantidad: number;
  precioUnitario: number;
  total: number;
}

const FacturacionManagement = () => {
  const [facturas, setFacturas] = useState<Factura[]>([]);
  const [filteredFacturas, setFilteredFacturas] = useState<Factura[]>([]);
  const [selectedEstado, setSelectedEstado] = useState('todos');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFactura, setSelectedFactura] = useState<Factura | null>(null);
  const [showFacturaDialog, setShowFacturaDialog] = useState(false);
  const [showNewFacturaDialog, setShowNewFacturaDialog] = useState(false);

  useEffect(() => {
    const savedFacturas = localStorage.getItem('hospitalFacturacion');
    if (savedFacturas) {
      const data = JSON.parse(savedFacturas);
      setFacturas(data);
      setFilteredFacturas(data);
    } else {
      const ejemploFacturas: Factura[] = [
        {
          id: '1',
          numero: 'FAC-2024-001',
          pacienteId: '1',
          pacienteNombre: 'García López, Juan Carlos',
          numeroHistoria: 'HST001',
          fecha: '2024-05-20',
          fechaVencimiento: '2024-06-20',
          conceptos: [
            {
              id: '1',
              descripcion: 'Consulta Cardiología',
              cantidad: 1,
              precioUnitario: 150000,
              total: 150000
            },
            {
              id: '2',
              descripcion: 'Electrocardiograma',
              cantidad: 1,
              precioUnitario: 80000,
              total: 80000
            }
          ],
          subtotal: 230000,
          impuestos: 43700,
          total: 273700,
          estado: 'pagada',
          metodoPago: 'Tarjeta de Crédito'
        },
        {
          id: '2',
          numero: 'FAC-2024-002',
          pacienteId: '2',
          pacienteNombre: 'Rodríguez Pérez, María Isabel',
          numeroHistoria: 'HST002',
          fecha: '2024-05-22',
          fechaVencimiento: '2024-06-22',
          conceptos: [
            {
              id: '3',
              descripcion: 'Tomografía de Abdomen',
              cantidad: 1,
              precioUnitario: 350000,
              total: 350000
            }
          ],
          subtotal: 350000,
          impuestos: 66500,
          total: 416500,
          estado: 'pendiente'
        }
      ];
      setFacturas(ejemploFacturas);
      setFilteredFacturas(ejemploFacturas);
      localStorage.setItem('hospitalFacturacion', JSON.stringify(ejemploFacturas));
    }
  }, []);

  useEffect(() => {
    let filtered = facturas;

    if (selectedEstado !== 'todos') {
      filtered = filtered.filter(f => f.estado === selectedEstado);
    }

    if (searchTerm) {
      filtered = filtered.filter(f => 
        f.pacienteNombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
        f.numero.toLowerCase().includes(searchTerm.toLowerCase()) ||
        f.numeroHistoria.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredFacturas(filtered);
  }, [facturas, selectedEstado, searchTerm]);

  const getEstadoBadge = (estado: string) => {
    switch (estado) {
      case 'pendiente':
        return <Badge variant="outline" className="bg-orange-100 text-orange-800">Pendiente</Badge>;
      case 'pagada':
        return <Badge variant="default" className="bg-green-100 text-green-800">Pagada</Badge>;
      case 'vencida':
        return <Badge variant="destructive" className="bg-red-100 text-red-800">Vencida</Badge>;
      case 'anulada':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-800">Anulada</Badge>;
      default:
        return <Badge variant="secondary">{estado}</Badge>;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const handleUpdateEstado = (facturaId: string, nuevoEstado: string) => {
    const updatedFacturas = facturas.map(f => 
      f.id === facturaId ? { ...f, estado: nuevoEstado as any } : f
    );
    
    setFacturas(updatedFacturas);
    localStorage.setItem('hospitalFacturacion', JSON.stringify(updatedFacturas));
    
    toast({
      title: "Estado actualizado",
      description: `La factura ha sido marcada como ${nuevoEstado}`,
    });
  };

  const handleViewFactura = (factura: Factura) => {
    setSelectedFactura(factura);
    setShowFacturaDialog(true);
  };

  const estadisticas = {
    pendientes: facturas.filter(f => f.estado === 'pendiente').length,
    pagadas: facturas.filter(f => f.estado === 'pagada').length,
    vencidas: facturas.filter(f => f.estado === 'vencida').length,
    anuladas: facturas.filter(f => f.estado === 'anulada').length,
    totalPendiente: facturas
      .filter(f => f.estado === 'pendiente')
      .reduce((sum, f) => sum + f.total, 0),
    totalMes: facturas
      .filter(f => f.fecha.startsWith(new Date().toISOString().slice(0, 7)))
      .reduce((sum, f) => sum + f.total, 0)
  };

  return (
    <div className="p-6 space-y-6">
      <div className="text-sm text-gray-600 mb-4">
        <span className="text-cyan-600">Gestión médica</span> / <span>Facturación</span>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Facturación</h1>
          <Dialog open={showNewFacturaDialog} onOpenChange={setShowNewFacturaDialog}>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
                <Plus size={16} />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl">
              <DialogHeader>
                <DialogTitle>Nueva Factura</DialogTitle>
              </DialogHeader>
              <div className="text-center py-8 text-gray-500">
                Formulario de nueva factura (pendiente de implementar)
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pendientes</CardTitle>
            <AlertCircle className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.pendientes}</div>
            <p className="text-xs text-muted-foreground">Por cobrar</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pagadas</CardTitle>
            <CreditCard className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.pagadas}</div>
            <p className="text-xs text-muted-foreground">Cobradas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vencidas</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.vencidas}</div>
            <p className="text-xs text-muted-foreground">Vencidas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Anuladas</CardTitle>
            <FileText className="h-4 w-4 text-gray-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.anuladas}</div>
            <p className="text-xs text-muted-foreground">Anuladas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Pendiente</CardTitle>
            <DollarSign className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">{formatCurrency(estadisticas.totalPendiente)}</div>
            <p className="text-xs text-muted-foreground">Por cobrar</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Facturado este mes</CardTitle>
            <DollarSign className="h-4 w-4 text-cyan-600" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">{formatCurrency(estadisticas.totalMes)}</div>
            <p className="text-xs text-muted-foreground">Mes actual</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="estado">Estado</Label>
              <Select value={selectedEstado} onValueChange={setSelectedEstado}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos los estados</SelectItem>
                  <SelectItem value="pendiente">Pendientes</SelectItem>
                  <SelectItem value="pagada">Pagadas</SelectItem>
                  <SelectItem value="vencida">Vencidas</SelectItem>
                  <SelectItem value="anulada">Anuladas</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="buscar">Buscar</Label>
              <div className="relative mt-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="buscar"
                  placeholder="Buscar por paciente, número..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="flex items-end">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => {
                  setSearchTerm('');
                  setSelectedEstado('todos');
                }}
              >
                Limpiar filtros
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabla de facturas */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-cyan-600 hover:bg-cyan-600">
                <TableHead className="text-white font-semibold">Número</TableHead>
                <TableHead className="text-white font-semibold">Paciente</TableHead>
                <TableHead className="text-white font-semibold">Fecha</TableHead>
                <TableHead className="text-white font-semibold">Vencimiento</TableHead>
                <TableHead className="text-white font-semibold">Total</TableHead>
                <TableHead className="text-white font-semibold">Estado</TableHead>
                <TableHead className="text-white font-semibold">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredFacturas.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                    No se encontraron facturas
                  </TableCell>
                </TableRow>
              ) : (
                filteredFacturas.map((factura) => (
                  <TableRow key={factura.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div className="font-medium text-cyan-600">
                        {factura.numero}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{factura.pacienteNombre}</div>
                        <div className="text-sm text-gray-500">
                          Historia: {factura.numeroHistoria}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{factura.fecha}</TableCell>
                    <TableCell>{factura.fechaVencimiento}</TableCell>
                    <TableCell>
                      <div className="font-medium">{formatCurrency(factura.total)}</div>
                    </TableCell>
                    <TableCell>
                      {getEstadoBadge(factura.estado)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 w-8 p-0"
                          onClick={() => handleViewFactura(factura)}
                          title="Ver factura"
                        >
                          <Eye size={16} className="text-gray-600" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 w-8 p-0"
                          title="Descargar PDF"
                        >
                          <Download size={16} className="text-gray-600" />
                        </Button>
                        <Select 
                          value={factura.estado} 
                          onValueChange={(value) => handleUpdateEstado(factura.id, value)}
                        >
                          <SelectTrigger className="w-28">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pendiente">Pendiente</SelectItem>
                            <SelectItem value="pagada">Pagada</SelectItem>
                            <SelectItem value="vencida">Vencida</SelectItem>
                            <SelectItem value="anulada">Anulada</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Modal de detalle de factura */}
      <Dialog open={showFacturaDialog} onOpenChange={setShowFacturaDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalle de Factura - {selectedFactura?.numero}</DialogTitle>
          </DialogHeader>
          {selectedFactura && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <strong>Paciente:</strong> {selectedFactura.pacienteNombre}
                </div>
                <div>
                  <strong>Historia:</strong> {selectedFactura.numeroHistoria}
                </div>
                <div>
                  <strong>Fecha:</strong> {selectedFactura.fecha}
                </div>
                <div>
                  <strong>Vencimiento:</strong> {selectedFactura.fechaVencimiento}
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Conceptos</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Descripción</TableHead>
                      <TableHead>Cantidad</TableHead>
                      <TableHead>Precio Unit.</TableHead>
                      <TableHead>Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedFactura.conceptos.map((concepto) => (
                      <TableRow key={concepto.id}>
                        <TableCell>{concepto.descripcion}</TableCell>
                        <TableCell>{concepto.cantidad}</TableCell>
                        <TableCell>{formatCurrency(concepto.precioUnitario)}</TableCell>
                        <TableCell>{formatCurrency(concepto.total)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="border-t pt-4">
                <div className="text-right space-y-2">
                  <div>Subtotal: {formatCurrency(selectedFactura.subtotal)}</div>
                  <div>Impuestos: {formatCurrency(selectedFactura.impuestos)}</div>
                  <div className="text-lg font-bold">
                    Total: {formatCurrency(selectedFactura.total)}
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default FacturacionManagement;
