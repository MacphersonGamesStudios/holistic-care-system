
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, X, Play, Pause, Download } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface RadiologiaImageViewerProps {
  estudioId: string;
  isOpen: boolean;
  onClose: () => void;
}

interface ArchivoEstudio {
  id: string;
  nombre: string;
  tipo: 'imagen' | 'video';
  url: string;
  fechaSubida: string;
  tamaño: string;
}

const RadiologiaImageViewer = ({ estudioId, isOpen, onClose }: RadiologiaImageViewerProps) => {
  const [archivos, setArchivos] = useState<ArchivoEstudio[]>([]);
  const [archivoSeleccionado, setArchivoSeleccionado] = useState<ArchivoEstudio | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const nuevoArchivo: ArchivoEstudio = {
          id: Date.now().toString() + Math.random(),
          nombre: file.name,
          tipo: file.type.startsWith('video/') ? 'video' : 'imagen',
          url: e.target?.result as string,
          fechaSubida: new Date().toISOString().split('T')[0],
          tamaño: (file.size / 1024 / 1024).toFixed(2) + ' MB'
        };
        
        setArchivos(prev => [...prev, nuevoArchivo]);
        
        // Guardar en localStorage
        const key = `radiologia_archivos_${estudioId}`;
        const archivosExistentes = JSON.parse(localStorage.getItem(key) || '[]');
        localStorage.setItem(key, JSON.stringify([...archivosExistentes, nuevoArchivo]));
      };
      reader.readAsDataURL(file);
    });
    
    toast({
      title: "Archivos cargados",
      description: `Se han cargado ${files.length} archivo(s) correctamente`,
    });
  };

  React.useEffect(() => {
    if (isOpen) {
      const key = `radiologia_archivos_${estudioId}`;
      const archivosGuardados = JSON.parse(localStorage.getItem(key) || '[]');
      setArchivos(archivosGuardados);
    }
  }, [isOpen, estudioId]);

  const eliminarArchivo = (archivoId: string) => {
    const nuevosArchivos = archivos.filter(a => a.id !== archivoId);
    setArchivos(nuevosArchivos);
    
    const key = `radiologia_archivos_${estudioId}`;
    localStorage.setItem(key, JSON.stringify(nuevosArchivos));
    
    if (archivoSeleccionado?.id === archivoId) {
      setArchivoSeleccionado(null);
    }
    
    toast({
      title: "Archivo eliminado",
      description: "El archivo se ha eliminado correctamente",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Visor de Imágenes y Videos - Estudio {estudioId}</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Panel de carga y lista de archivos */}
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
              <Label htmlFor="file-upload" className="cursor-pointer">
                <div className="text-center">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <div className="mt-2">
                    <span className="text-sm font-medium text-gray-900">
                      Cargar archivos
                    </span>
                    <p className="text-xs text-gray-500">
                      PNG, JPG, MP4, AVI hasta 10MB
                    </p>
                  </div>
                </div>
              </Label>
              <Input
                id="file-upload"
                type="file"
                multiple
                accept="image/*,video/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>
            
            <div className="space-y-2">
              <h3 className="font-medium">Archivos ({archivos.length})</h3>
              <div className="max-h-60 overflow-y-auto space-y-2">
                {archivos.map(archivo => (
                  <div 
                    key={archivo.id}
                    className={`p-2 border rounded cursor-pointer transition-colors ${
                      archivoSeleccionado?.id === archivo.id 
                        ? 'bg-cyan-50 border-cyan-200' 
                        : 'hover:bg-gray-50'
                    }`}
                    onClick={() => setArchivoSeleccionado(archivo)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{archivo.nombre}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {archivo.tipo}
                          </Badge>
                          <span className="text-xs text-gray-500">{archivo.tamaño}</span>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          eliminarArchivo(archivo.id);
                        }}
                        className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                      >
                        <X size={12} />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Visor principal */}
          <div className="lg:col-span-2">
            {archivoSeleccionado ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium">{archivoSeleccionado.nombre}</h3>
                  <div className="flex items-center gap-2">
                    <Badge>{archivoSeleccionado.tipo}</Badge>
                    <Button size="sm" variant="outline">
                      <Download size={16} />
                    </Button>
                  </div>
                </div>
                
                <div className="border rounded-lg overflow-hidden bg-black">
                  {archivoSeleccionado.tipo === 'imagen' ? (
                    <img 
                      src={archivoSeleccionado.url} 
                      alt={archivoSeleccionado.nombre}
                      className="w-full h-auto max-h-96 object-contain"
                    />
                  ) : (
                    <div className="relative">
                      <video 
                        src={archivoSeleccionado.url}
                        className="w-full h-auto max-h-96"
                        controls
                        onPlay={() => setIsPlaying(true)}
                        onPause={() => setIsPlaying(false)}
                      />
                    </div>
                  )}
                </div>
                
                <div className="text-sm text-gray-600">
                  <p>Fecha de subida: {archivoSeleccionado.fechaSubida}</p>
                  <p>Tamaño: {archivoSeleccionado.tamaño}</p>
                </div>
              </div>
            ) : (
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <div className="text-gray-500">
                  <p>Selecciona un archivo para visualizar</p>
                  <p className="text-sm mt-1">o carga nuevos archivos</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default RadiologiaImageViewer;
