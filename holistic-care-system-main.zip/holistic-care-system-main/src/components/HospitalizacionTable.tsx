import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Eye, Edit, UserCheck, FileText } from "lucide-react";
import HospitalizacionDetails from './HospitalizacionDetails';
import EditarHospitalizacionForm from './EditarHospitalizacionForm';
import HistoriaClinicaModal from './HistoriaClinicaModal';
import { Hospitalizacion } from '../types/hospitalizacion';

interface HospitalizacionTableProps {
  hospitalizaciones: Hospitalizacion[];
  onDarAlta: (hospitalizacion: Hospitalizacion) => void;
  onUpdate: (id: string, data: Partial<Hospitalizacion>) => void;
}

const HospitalizacionTable = ({ hospitalizaciones, onDarAlta, onUpdate }: HospitalizacionTableProps) => {
  const [selectedHospitalizacion, setSelectedHospitalizacion] = useState<Hospitalizacion | null>(null);
  const [modalType, setModalType] = useState<'details' | 'edit' | 'historia' | null>(null);

  const getEstadoBadge = (estado: string) => {
    switch (estado) {
      case 'ingresado':
        return <Badge variant="default" className="bg-green-100 text-green-800">Ingresado</Badge>;
      case 'alta':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-800">Alta</Badge>;
      case 'transferido':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Transferido</Badge>;
      default:
        return <Badge variant="secondary">{estado}</Badge>;
    }
  };

  const getTipoIngresoBadge = (tipo: string) => {
    switch (tipo) {
      case 'urgencia':
        return <Badge variant="destructive" className="bg-red-100 text-red-800">Urgencia</Badge>;
      case 'programado':
        return <Badge variant="default" className="bg-blue-100 text-blue-800">Programado</Badge>;
      case 'traslado':
        return <Badge variant="outline" className="bg-orange-100 text-orange-800">Traslado</Badge>;
      default:
        return <Badge variant="secondary">{tipo}</Badge>;
    }
  };

  const handleViewDetails = (hospitalizacion: Hospitalizacion) => {
    setSelectedHospitalizacion(hospitalizacion);
    setModalType('details');
  };

  const handleEdit = (hospitalizacion: Hospitalizacion) => {
    setSelectedHospitalizacion(hospitalizacion);
    setModalType('edit');
  };

  const handleViewHistoria = (hospitalizacion: Hospitalizacion) => {
    setSelectedHospitalizacion(hospitalizacion);
    setModalType('historia');
  };

  const handleSaveEdit = (data: Partial<Hospitalizacion>) => {
    if (selectedHospitalizacion) {
      onUpdate(selectedHospitalizacion.id, data);
      setModalType(null);
      setSelectedHospitalizacion(null);
    }
  };

  const handleCloseModal = () => {
    setModalType(null);
    setSelectedHospitalizacion(null);
  };

  return (
    <>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-cyan-600 hover:bg-cyan-600">
                <TableHead className="text-white font-semibold">Paciente</TableHead>
                <TableHead className="text-white font-semibold">Habitación</TableHead>
                <TableHead className="text-white font-semibold">Ingreso</TableHead>
                <TableHead className="text-white font-semibold">Médico</TableHead>
                <TableHead className="text-white font-semibold">Estado</TableHead>
                <TableHead className="text-white font-semibold">Tipo</TableHead>
                <TableHead className="text-white font-semibold">Diagnóstico</TableHead>
                <TableHead className="text-white font-semibold">Opciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {hospitalizaciones.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-gray-500">
                    No se encontraron hospitalizaciones
                  </TableCell>
                </TableRow>
              ) : (
                hospitalizaciones.map((hospitalizacion) => (
                  <TableRow key={hospitalizacion.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div>
                        <div className="font-medium text-cyan-600">
                          {hospitalizacion.pacienteNombre}
                        </div>
                        <div className="text-sm text-gray-500">
                          Historia: {hospitalizacion.numeroHistoria}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-mono">
                        <div>{hospitalizacion.habitacion}</div>
                        <div className="text-sm text-gray-500">Cama {hospitalizacion.cama}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div>{hospitalizacion.fechaIngreso}</div>
                        {hospitalizacion.fechaAlta && (
                          <div className="text-sm text-gray-500">
                            Alta: {hospitalizacion.fechaAlta}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">{hospitalizacion.medicoResponsable}</div>
                    </TableCell>
                    <TableCell>
                      {getEstadoBadge(hospitalizacion.estado)}
                    </TableCell>
                    <TableCell>
                      {getTipoIngresoBadge(hospitalizacion.tipoIngreso)}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">{hospitalizacion.diagnostico}</div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="h-8 w-8 p-0"
                          onClick={() => handleViewDetails(hospitalizacion)}
                          title="Ver detalles"
                        >
                          <Eye size={16} className="text-gray-600" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="h-8 w-8 p-0"
                          onClick={() => handleEdit(hospitalizacion)}
                          title="Editar"
                        >
                          <Edit size={16} className="text-gray-600" />
                        </Button>
                        {hospitalizacion.estado === 'ingresado' && (
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-8 w-8 p-0"
                            onClick={() => onDarAlta(hospitalizacion)}
                            title="Dar de alta"
                          >
                            <UserCheck size={16} className="text-green-600" />
                          </Button>
                        )}
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="h-8 w-8 p-0"
                          onClick={() => handleViewHistoria(hospitalizacion)}
                          title="Historia clínica"
                        >
                          <FileText size={16} className="text-gray-600" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={modalType !== null} onOpenChange={(open) => !open && handleCloseModal()}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {modalType === 'details' && 'Detalles de Hospitalización'}
              {modalType === 'edit' && 'Editar Hospitalización'}
              {modalType === 'historia' && 'Historia Clínica'}
            </DialogTitle>
          </DialogHeader>
          {selectedHospitalizacion && (
            <>
              {modalType === 'details' && (
                <HospitalizacionDetails 
                  hospitalizacion={selectedHospitalizacion} 
                  onClose={handleCloseModal}
                />
              )}
              {modalType === 'edit' && (
                <EditarHospitalizacionForm 
                  hospitalizacion={selectedHospitalizacion}
                  onSave={handleSaveEdit}
                  onCancel={handleCloseModal}
                />
              )}
              {modalType === 'historia' && (
                <HistoriaClinicaModal 
                  hospitalizacion={selectedHospitalizacion}
                  onClose={handleCloseModal}
                />
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default HospitalizacionTable;
