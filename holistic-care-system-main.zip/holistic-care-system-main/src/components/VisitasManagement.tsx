
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Users, Clock, CheckCircle, XCircle, Plus, Search } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";

interface Visita {
  id: string;
  pacienteId: string;
  pacienteNombre: string;
  numeroHistoria: string;
  visitante: string;
  parentesco: string;
  fechaVisita: string;
  horaInicio: string;
  horaFin?: string;
  estado: 'programada' | 'en_curso' | 'finalizada' | 'cancelada';
  habitacion: string;
  observaciones?: string;
  telefono: string;
  documento: string;
}

const VisitasManagement = () => {
  const [visitas, setVisitas] = useState<Visita[]>([]);
  const [filteredVisitas, setFilteredVisitas] = useState<Visita[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedEstado, setSelectedEstado] = useState('todos');
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewVisitaDialog, setShowNewVisitaDialog] = useState(false);

  useEffect(() => {
    const savedVisitas = localStorage.getItem('hospitalVisitas');
    if (savedVisitas) {
      const data = JSON.parse(savedVisitas);
      setVisitas(data);
      setFilteredVisitas(data);
    } else {
      const ejemploVisitas: Visita[] = [
        {
          id: '1',
          pacienteId: '1',
          pacienteNombre: 'García López, Juan Carlos',
          numeroHistoria: 'HST001',
          visitante: 'María García',
          parentesco: 'Esposa',
          fechaVisita: new Date().toISOString().split('T')[0],
          horaInicio: '14:00',
          horaFin: '15:30',
          estado: 'finalizada',
          habitacion: '201-A',
          telefono: '555-0123',
          documento: '12345678'
        },
        {
          id: '2',
          pacienteId: '2',
          pacienteNombre: 'Rodríguez Pérez, María Isabel',
          numeroHistoria: 'HST002',
          visitante: 'Carlos Rodríguez',
          parentesco: 'Hijo',
          fechaVisita: new Date().toISOString().split('T')[0],
          horaInicio: '16:00',
          estado: 'en_curso',
          habitacion: '305-B',
          telefono: '555-0456',
          documento: '87654321'
        }
      ];
      setVisitas(ejemploVisitas);
      setFilteredVisitas(ejemploVisitas);
      localStorage.setItem('hospitalVisitas', JSON.stringify(ejemploVisitas));
    }
  }, []);

  useEffect(() => {
    let filtered = visitas;

    if (selectedDate) {
      filtered = filtered.filter(v => v.fechaVisita === selectedDate);
    }

    if (selectedEstado !== 'todos') {
      filtered = filtered.filter(v => v.estado === selectedEstado);
    }

    if (searchTerm) {
      filtered = filtered.filter(v => 
        v.pacienteNombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
        v.visitante.toLowerCase().includes(searchTerm.toLowerCase()) ||
        v.numeroHistoria.toLowerCase().includes(searchTerm.toLowerCase()) ||
        v.habitacion.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredVisitas(filtered);
  }, [visitas, selectedDate, selectedEstado, searchTerm]);

  const getEstadoBadge = (estado: string) => {
    switch (estado) {
      case 'programada':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Programada</Badge>;
      case 'en_curso':
        return <Badge variant="default" className="bg-green-100 text-green-800">En curso</Badge>;
      case 'finalizada':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-800">Finalizada</Badge>;
      case 'cancelada':
        return <Badge variant="destructive" className="bg-red-100 text-red-800">Cancelada</Badge>;
      default:
        return <Badge variant="secondary">{estado}</Badge>;
    }
  };

  const handleUpdateEstado = (visitaId: string, nuevoEstado: string) => {
    const updatedVisitas = visitas.map(v => {
      if (v.id === visitaId) {
        const updated = { ...v, estado: nuevoEstado as any };
        if (nuevoEstado === 'finalizada' && !v.horaFin) {
          updated.horaFin = new Date().toLocaleTimeString('es-ES', { 
            hour: '2-digit', 
            minute: '2-digit' 
          });
        }
        return updated;
      }
      return v;
    });
    
    setVisitas(updatedVisitas);
    localStorage.setItem('hospitalVisitas', JSON.stringify(updatedVisitas));
    
    toast({
      title: "Estado actualizado",
      description: `La visita ha sido marcada como ${nuevoEstado}`,
    });
  };

  const estadisticas = {
    programadas: visitas.filter(v => v.estado === 'programada').length,
    enCurso: visitas.filter(v => v.estado === 'en_curso').length,
    finalizadas: visitas.filter(v => v.estado === 'finalizada').length,
    canceladas: visitas.filter(v => v.estado === 'cancelada').length,
    hoy: visitas.filter(v => v.fechaVisita === new Date().toISOString().split('T')[0]).length
  };

  return (
    <div className="p-6 space-y-6">
      <div className="text-sm text-gray-600 mb-4">
        <span className="text-cyan-600">Gestión médica</span> / <span>Visitas</span>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Visitas</h1>
          <Dialog open={showNewVisitaDialog} onOpenChange={setShowNewVisitaDialog}>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700">
                <Plus size={16} />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Registrar Nueva Visita</DialogTitle>
              </DialogHeader>
              <div className="text-center py-8 text-gray-500">
                Formulario de nueva visita (pendiente de implementar)
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Programadas</CardTitle>
            <Clock className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.programadas}</div>
            <p className="text-xs text-muted-foreground">Pendientes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">En Curso</CardTitle>
            <Users className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.enCurso}</div>
            <p className="text-xs text-muted-foreground">Activas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Finalizadas</CardTitle>
            <CheckCircle className="h-4 w-4 text-gray-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.finalizadas}</div>
            <p className="text-xs text-muted-foreground">Completadas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Canceladas</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.canceladas}</div>
            <p className="text-xs text-muted-foreground">Canceladas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Hoy</CardTitle>
            <Users className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estadisticas.hoy}</div>
            <p className="text-xs text-muted-foreground">Visitas de hoy</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="fecha">Fecha</Label>
              <Input
                id="fecha"
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="estado">Estado</Label>
              <Select value={selectedEstado} onValueChange={setSelectedEstado}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos los estados</SelectItem>
                  <SelectItem value="programada">Programadas</SelectItem>
                  <SelectItem value="en_curso">En curso</SelectItem>
                  <SelectItem value="finalizada">Finalizadas</SelectItem>
                  <SelectItem value="cancelada">Canceladas</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="buscar">Buscar</Label>
              <div className="relative mt-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="buscar"
                  placeholder="Buscar paciente, visitante..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="flex items-end">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => {
                  setSearchTerm('');
                  setSelectedEstado('todos');
                  setSelectedDate(new Date().toISOString().split('T')[0]);
                }}
              >
                Limpiar filtros
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabla de visitas */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-cyan-600 hover:bg-cyan-600">
                <TableHead className="text-white font-semibold">Paciente</TableHead>
                <TableHead className="text-white font-semibold">Visitante</TableHead>
                <TableHead className="text-white font-semibold">Horario</TableHead>
                <TableHead className="text-white font-semibold">Habitación</TableHead>
                <TableHead className="text-white font-semibold">Estado</TableHead>
                <TableHead className="text-white font-semibold">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredVisitas.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                    No se encontraron visitas
                  </TableCell>
                </TableRow>
              ) : (
                filteredVisitas.map((visita) => (
                  <TableRow key={visita.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div>
                        <div className="font-medium text-cyan-600">
                          {visita.pacienteNombre}
                        </div>
                        <div className="text-sm text-gray-500">
                          Historia: {visita.numeroHistoria}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{visita.visitante}</div>
                        <div className="text-sm text-gray-500">
                          {visita.parentesco} • {visita.documento}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{visita.horaInicio}</div>
                        {visita.horaFin && (
                          <div className="text-sm text-gray-500">
                            Fin: {visita.horaFin}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{visita.habitacion}</Badge>
                    </TableCell>
                    <TableCell>
                      {getEstadoBadge(visita.estado)}
                    </TableCell>
                    <TableCell>
                      <Select 
                        value={visita.estado} 
                        onValueChange={(value) => handleUpdateEstado(visita.id, value)}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="programada">Programada</SelectItem>
                          <SelectItem value="en_curso">En curso</SelectItem>
                          <SelectItem value="finalizada">Finalizada</SelectItem>
                          <SelectItem value="cancelada">Cancelada</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default VisitasManagement;
