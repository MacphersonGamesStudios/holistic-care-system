
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { ArrowLeft, UserPlus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";

const RegisterForm = () => {
  const [formData, setFormData] = useState({
    nombre: '',
    apellidos: '',
    email: '',
    telefono: '',
    password: '',
    confirmPassword: '',
    tipoUsuario: '',
    especialidad: '',
    numeroLicencia: ''
  });
  
  const navigate = useNavigate();

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validaciones básicas
    if (!formData.nombre || !formData.apellidos || !formData.email || !formData.password || !formData.tipoUsuario) {
      toast({
        title: "Error de registro",
        description: "Por favor, complete todos los campos obligatorios",
        variant: "destructive",
      });
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Error de registro",
        description: "Las contraseñas no coinciden",
        variant: "destructive",
      });
      return;
    }

    if (formData.password.length < 6) {
      toast({
        title: "Error de registro",
        description: "La contraseña debe tener al menos 6 caracteres",
        variant: "destructive",
      });
      return;
    }

    // Verificar si el email ya existe
    const existingUsers = JSON.parse(localStorage.getItem('hospitalUsers') || '[]');
    if (existingUsers.find((user: any) => user.email === formData.email)) {
      toast({
        title: "Error de registro",
        description: "Ya existe un usuario con este email",
        variant: "destructive",
      });
      return;
    }

    // Crear nuevo usuario
    const newUser = {
      id: Date.now().toString(),
      nombre: formData.nombre,
      apellidos: formData.apellidos,
      email: formData.email,
      telefono: formData.telefono,
      tipoUsuario: formData.tipoUsuario,
      especialidad: formData.especialidad,
      numeroLicencia: formData.numeroLicencia,
      fechaRegistro: new Date().toISOString(),
      activo: true
    };

    // Guardar en localStorage
    const updatedUsers = [...existingUsers, newUser];
    localStorage.setItem('hospitalUsers', JSON.stringify(updatedUsers));

    toast({
      title: "Registro exitoso",
      description: `Usuario ${formData.nombre} ${formData.apellidos} registrado correctamente`,
    });

    // Redirigir al login
    navigate('/');
  };

  return (
    <div className="min-h-screen hospital-gradient flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-white/95 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => navigate('/')}
              className="text-cyan-600 hover:bg-cyan-50"
            >
              <ArrowLeft size={20} />
            </Button>
            <div className="bg-cyan-600 text-white px-4 py-2 rounded-md inline-flex items-center gap-2">
              <span className="font-bold">DASI</span>
              <span className="bg-white text-cyan-600 px-2 py-1 rounded text-sm font-semibold">eCLINIC</span>
            </div>
          </div>
          <CardTitle className="text-2xl text-center text-gray-800 flex items-center justify-center gap-2">
            <UserPlus className="text-cyan-600" />
            Registro de Usuario
          </CardTitle>
        </CardHeader>

        <CardContent className="p-8">
          <form onSubmit={handleRegister} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="nombre">Nombre *</Label>
                <Input
                  id="nombre"
                  type="text"
                  value={formData.nombre}
                  onChange={(e) => handleInputChange('nombre', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="apellidos">Apellidos *</Label>
                <Input
                  id="apellidos"
                  type="text"
                  value={formData.apellidos}
                  onChange={(e) => handleInputChange('apellidos', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="telefono">Teléfono</Label>
                <Input
                  id="telefono"
                  type="tel"
                  value={formData.telefono}
                  onChange={(e) => handleInputChange('telefono', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="tipoUsuario">Tipo de Usuario *</Label>
              <Select value={formData.tipoUsuario} onValueChange={(value) => handleInputChange('tipoUsuario', value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Seleccione el tipo de usuario" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="medico">Médico</SelectItem>
                  <SelectItem value="enfermero">Enfermero/a</SelectItem>
                  <SelectItem value="administrativo">Administrativo</SelectItem>
                  <SelectItem value="farmaceutico">Farmacéutico</SelectItem>
                  <SelectItem value="radiologo">Radiólogo</SelectItem>
                  <SelectItem value="laboratorista">Laboratorista</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {(formData.tipoUsuario === 'medico' || formData.tipoUsuario === 'enfermero') && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="especialidad">Especialidad</Label>
                  <Input
                    id="especialidad"
                    type="text"
                    value={formData.especialidad}
                    onChange={(e) => handleInputChange('especialidad', e.target.value)}
                    className="mt-1"
                    placeholder="Ej: Cardiología, Pediatría..."
                  />
                </div>

                <div>
                  <Label htmlFor="numeroLicencia">Número de Licencia</Label>
                  <Input
                    id="numeroLicencia"
                    type="text"
                    value={formData.numeroLicencia}
                    onChange={(e) => handleInputChange('numeroLicencia', e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="password">Contraseña *</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="confirmPassword">Confirmar Contraseña *</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 bg-cyan-600 hover:bg-cyan-700 text-white font-semibold text-base"
            >
              Registrarse
            </Button>

            <div className="text-center">
              <Button
                type="button"
                variant="link"
                onClick={() => navigate('/')}
                className="text-cyan-600 hover:text-cyan-700"
              >
                ¿Ya tienes cuenta? Inicia sesión
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default RegisterForm;
