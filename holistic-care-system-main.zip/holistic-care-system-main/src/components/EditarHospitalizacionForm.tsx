import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Hospitalizacion } from '../types/hospitalizacion';

interface EditarHospitalizacionFormProps {
  hospitalizacion: Hospitalizacion;
  onSave: (data: Partial<Hospitalizacion>) => void;
  onCancel: () => void;
}

const EditarHospitalizacionForm = ({ hospitalizacion, onSave, onCancel }: EditarHospitalizacionFormProps) => {
  const [formData, setFormData] = useState({
    habitacion: hospitalizacion.habitacion,
    cama: hospitalizacion.cama,
    medicoResponsable: hospitalizacion.medicoResponsable,
    diagnostico: hospitalizacion.diagnostico,
    observaciones: hospitalizacion.observaciones || '',
    tipoIngreso: hospitalizacion.tipoIngreso,
    estado: hospitalizacion.estado
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Editar Hospitalización - {hospitalizacion.pacienteNombre}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="habitacion">Habitación</Label>
              <Input
                id="habitacion"
                value={formData.habitacion}
                onChange={(e) => setFormData({ ...formData, habitacion: e.target.value })}
                required
              />
            </div>

            <div>
              <Label htmlFor="cama">Cama</Label>
              <Input
                id="cama"
                value={formData.cama}
                onChange={(e) => setFormData({ ...formData, cama: e.target.value })}
                required
              />
            </div>

            <div>
              <Label htmlFor="medicoResponsable">Médico Responsable</Label>
              <Input
                id="medicoResponsable"
                value={formData.medicoResponsable}
                onChange={(e) => setFormData({ ...formData, medicoResponsable: e.target.value })}
                required
              />
            </div>

            <div>
              <Label htmlFor="tipoIngreso">Tipo de Ingreso</Label>
              <Select value={formData.tipoIngreso} onValueChange={(value: 'urgencia' | 'programado' | 'traslado') => setFormData({ ...formData, tipoIngreso: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="urgencia">Urgencia</SelectItem>
                  <SelectItem value="programado">Programado</SelectItem>
                  <SelectItem value="traslado">Traslado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="estado">Estado</Label>
              <Select value={formData.estado} onValueChange={(value: 'ingresado' | 'alta' | 'transferido') => setFormData({ ...formData, estado: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ingresado">Ingresado</SelectItem>
                  <SelectItem value="alta">Alta</SelectItem>
                  <SelectItem value="transferido">Transferido</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="diagnostico">Diagnóstico</Label>
            <Input
              id="diagnostico"
              value={formData.diagnostico}
              onChange={(e) => setFormData({ ...formData, diagnostico: e.target.value })}
              required
            />
          </div>

          <div>
            <Label htmlFor="observaciones">Observaciones</Label>
            <Textarea
              id="observaciones"
              value={formData.observaciones}
              onChange={(e) => setFormData({ ...formData, observaciones: e.target.value })}
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-cyan-600 hover:bg-cyan-700">
              Guardar Cambios
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default EditarHospitalizacionForm;
