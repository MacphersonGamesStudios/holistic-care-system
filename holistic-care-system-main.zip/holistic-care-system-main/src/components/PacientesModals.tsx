
import React from 'react';
import PatientFormModal from './PatientFormModal';
import PatientViewModal from './PatientViewModal';
import PatientDeleteModal from './PatientDeleteModal';

interface Paciente {
  id: string;
  numeroHistoria: string;
  nombre: string;
  apellidos: string;
  dni: string;
  fechaNacimiento: string;
  sexo: string;
  telefono: string;
  email: string;
  fechaAlta: string;
  activo: boolean;
  foto?: string;
  direccion?: string;
  codigoPostal?: string;
  provincia?: string;
  poblacion?: string;
  observaciones?: string;
}

interface PacientesModalsProps {
  showNewPatientDialog: boolean;
  setShowNewPatientDialog: (show: boolean) => void;
  showEditPatientDialog: boolean;
  setShowEditPatientDialog: (show: boolean) => void;
  showViewPatientDialog: boolean;
  setShowViewPatientDialog: (show: boolean) => void;
  showDeleteAlert: boolean;
  setShowDeleteAlert: (show: boolean) => void;
  selectedPaciente: Paciente | null;
  setSelectedPaciente: (paciente: Paciente | null) => void;
  onNewPatient: (data: any) => void;
  onEditPatient: (data: any) => void;
  onDeletePatient: () => void;
}

const PacientesModals = ({
  showNewPatientDialog,
  setShowNewPatientDialog,
  showEditPatientDialog,
  setShowEditPatientDialog,
  showViewPatientDialog,
  setShowViewPatientDialog,
  showDeleteAlert,
  setShowDeleteAlert,
  selectedPaciente,
  setSelectedPaciente,
  onNewPatient,
  onEditPatient,
  onDeletePatient
}: PacientesModalsProps) => {
  const handleNewPatient = (data: any) => {
    onNewPatient(data);
    setSelectedPaciente(null);
  };

  const handleEditPatient = (data: any) => {
    onEditPatient(data);
    setSelectedPaciente(null);
  };

  const handleDeletePatient = () => {
    onDeletePatient();
    setSelectedPaciente(null);
  };

  const handleViewEdit = () => {
    setShowViewPatientDialog(false);
    setShowEditPatientDialog(true);
  };

  return (
    <>
      <PatientFormModal
        open={showNewPatientDialog}
        onOpenChange={setShowNewPatientDialog}
        onSave={handleNewPatient}
        onCancel={() => setShowNewPatientDialog(false)}
        title="Alta nuevo paciente"
      />

      <PatientFormModal
        open={showEditPatientDialog}
        onOpenChange={setShowEditPatientDialog}
        onSave={handleEditPatient}
        onCancel={() => setShowEditPatientDialog(false)}
        editData={selectedPaciente}
        title="Editar paciente"
      />

      <PatientViewModal
        open={showViewPatientDialog}
        onOpenChange={setShowViewPatientDialog}
        paciente={selectedPaciente}
        onEdit={handleViewEdit}
        onClose={() => setShowViewPatientDialog(false)}
      />

      <PatientDeleteModal
        open={showDeleteAlert}
        onOpenChange={setShowDeleteAlert}
        paciente={selectedPaciente}
        onConfirm={handleDeletePatient}
      />
    </>
  );
};

export default PacientesModals;
