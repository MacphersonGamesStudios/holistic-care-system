
import React from 'react';
import { FarmaciaProvider, useFarmaciaContext } from './FarmaciaProvider';
import { useFarmaciaManagementState } from '../hooks/useFarmaciaManagementState';
import FarmaciaHeader from './FarmaciaHeader';
import FarmaciaStatsCards from './FarmaciaStatsCards';
import FarmaciaFilters from './FarmaciaFilters';
import FarmaciaTable from './FarmaciaTable';
import FarmaciaActions from './FarmaciaActions';

const FarmaciaManagementContent = () => {
  const {
    medicamentos,
    filteredMedicamentos,
    searchTerm,
    setSearchTerm,
    categoriaFilter,
    setCategoriaFilter,
    stockFilter,
    setStockFilter,
  } = useFarmaciaContext();

  const managementState = useFarmaciaManagementState();
  const {
    showNewMedicamentoDialog,
    setShowNewMedicamentoDialog,
    handleViewMedicamento,
    handleEditClick,
    handleVentaClick,
    handleNuevaVenta,
  } = managementState;

  return (
    <div className="p-6 space-y-6">
      <FarmaciaHeader 
        showNewMedicamentoDialog={showNewMedicamentoDialog}
        setShowNewMedicamentoDialog={setShowNewMedicamentoDialog}
      />

      <FarmaciaStatsCards medicamentos={medicamentos} />

      <FarmaciaFilters
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        categoriaFilter={categoriaFilter}
        setCategoriaFilter={setCategoriaFilter}
        stockFilter={stockFilter}
        setStockFilter={setStockFilter}
        onNuevaVenta={handleNuevaVenta}
      />

      <FarmaciaTable 
        medicamentos={filteredMedicamentos}
        onView={handleViewMedicamento}
        onEdit={handleEditClick}
        onVenta={handleVentaClick}
      />

      <FarmaciaActions managementState={managementState} />
    </div>
  );
};

const FarmaciaManagement = () => {
  return (
    <FarmaciaProvider>
      <FarmaciaManagementContent />
    </FarmaciaProvider>
  );
};

export default FarmaciaManagement;
