
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoginForm from "./components/LoginForm";
import RegisterForm from "./components/RegisterForm";
import PatientRegisterForm from "./components/PatientRegisterForm";
import PatientLoginForm from "./components/PatientLoginForm";
import DashboardPage from "./pages/DashboardPage";
import AdminPage from "./pages/AdminPage";
import PatientPortalPage from "./pages/PatientPortalPage";
import EmployeePortalPage from "./pages/EmployeePortalPage";
import ModulePage from "./pages/ModulePage";
import NotFound from "./pages/NotFound";
import LicenciasManagement from "./components/admin/LicenciasManagement";
import PerfilClienteManagement from "./components/admin/PerfilClienteManagement";
import CentrosManagement from "./components/admin/CentrosManagement";
import PacientesManagement from "./components/PacientesManagement";
import HospitalizacionManagement from "./components/HospitalizacionManagement";
import RadiologiaManagement from "./components/RadiologiaManagement";
import AgendaMedicaManagement from "./components/AgendaMedicaManagement";
import VisitasManagement from "./components/VisitasManagement";
import FacturacionManagement from "./components/FacturacionManagement";
import ClientesManagement from "./components/ClientesManagement";
import ContabilidadManagement from "./components/ContabilidadManagement";
import EstadisticasManagement from "./components/EstadisticasManagement";
import FarmaciaManagement from "./components/FarmaciaManagement";
import LaboratorioManagement from "./components/LaboratorioManagement";
import Layout from "./components/Layout";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginForm />} />
          <Route path="/register" element={<RegisterForm />} />
          <Route path="/register-patient" element={<PatientRegisterForm />} />
          <Route path="/patient-login" element={<PatientLoginForm />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/patient-portal" element={<PatientPortalPage />} />
          <Route path="/employee-portal" element={<EmployeePortalPage />} />
          
          {/* Rutas de administración */}
          <Route path="/admin/licencias" element={<Layout><LicenciasManagement /></Layout>} />
          <Route path="/admin/perfil-cliente" element={<Layout><PerfilClienteManagement /></Layout>} />
          <Route path="/admin/perfil-usuario" element={<Layout><PerfilClienteManagement /></Layout>} />
          <Route path="/admin/centros" element={<Layout><CentrosManagement /></Layout>} />
          <Route path="/admin/usuarios" element={<Layout><LicenciasManagement /></Layout>} />
          <Route path="/admin/roles" element={<Layout><LicenciasManagement /></Layout>} />
          <Route path="/admin/mis-facturas" element={<Layout><LicenciasManagement /></Layout>} />
          <Route path="/admin/backup-general" element={<Layout><LicenciasManagement /></Layout>} />
          <Route path="/admin/backup-personal" element={<Layout><LicenciasManagement /></Layout>} />
          <Route path="/admin/auditoria" element={<Layout><LicenciasManagement /></Layout>} />
          
          {/* Rutas principales del sistema */}
          <Route path="/pacientes" element={<Layout><PacientesManagement /></Layout>} />
          <Route path="/clientes" element={<Layout><ClientesManagement /></Layout>} />
          <Route path="/contabilidad" element={<Layout><ContabilidadManagement /></Layout>} />
          <Route path="/estadisticas" element={<Layout><EstadisticasManagement /></Layout>} />
          <Route path="/farmacia" element={<Layout><FarmaciaManagement /></Layout>} />
          <Route path="/laboratorio" element={<Layout><LaboratorioManagement /></Layout>} />
          <Route path="/hospitalizacion" element={<Layout><HospitalizacionManagement /></Layout>} />
          <Route path="/radiologia" element={<Layout><RadiologiaManagement /></Layout>} />
          <Route path="/agenda" element={<Layout><AgendaMedicaManagement /></Layout>} />
          <Route path="/visitas" element={<Layout><VisitasManagement /></Layout>} />
          <Route path="/facturacion" element={<Layout><FacturacionManagement /></Layout>} />
          
          {/* Rutas del portal del paciente */}
          <Route path="/patient/*" element={<Layout><div className="p-6"><h1 className="text-2xl font-bold">Módulo en desarrollo</h1></div></Layout>} />
          
          {/* Rutas del portal del empleado */}
          <Route path="/employee/*" element={<Layout><div className="p-6"><h1 className="text-2xl font-bold">Módulo en desarrollo</h1></div></Layout>} />
          
          <Route path="/:module" element={<ModulePage />} />
          <Route path="/admin/:module" element={<ModulePage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
